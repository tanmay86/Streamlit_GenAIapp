# DASH-01 — Overview | Detailed implementation specification

Navigation: Dashboard → Overview. Suggested route `/dashboard/overview`; reuse existing route.

## Coding-agent contract

Product: JadeOrbit DeployPactAI. Build production functionality, not mock dashboards. Read PROJECT_REQUIREMENTS.md, PROJECT_ARCHITECTURE.md and all existing module specifications. Inspect actual routes, React/TypeScript components, FastAPI services, Lakebase PostgreSQL schema, Alembic migrations, RBAC, audit, provider reconciliation and deployment workers before coding. Reuse the existing design system and services. Preserve current Databricks connectivity. The four project types are Direct Deployment, Git-Enabled Deployment, Release Promotion (including ML model promotion), and Workspace Synchronization. Terraform is an execution option, not a project type.

Use React/TypeScript, FastAPI/Python, Lakebase PostgreSQL, Databricks SDK/REST, existing durable Jobs/workers, GitHub Actions integration and approved artifact storage. Dashboard queries read operational metadata, not customer table data. Do not call every target workspace or GitHub API on each page load; use existing reconciled state and health snapshots. Do not introduce a separate execution engine or duplicate run ledger. All DDL is reference PostgreSQL: inspect actual schemas and use additive Alembic migrations, tenant-consistent FKs, least-privilege database roles and existing naming conventions. Do not execute DDL blindly. No actual repository or live database was inspected for these specifications.

All reads enforce tenant AND project/workspace permissions server-side before aggregation, including counts, exports, drill-downs, caches and event subscriptions. For multi-target groups, show only authorized targets and label partial visibility; never leak hidden totals. Never expose tokens, secret values, raw Terraform state, sensitive source or unredacted logs. Use UTC storage, user-selected IANA timezone for display, half-open date intervals [start,end), explicit freshness timestamps, accessible charts/tables, keyboard navigation, loading/empty/error/partial/stale states. No invented metrics, sample data in production, or treating missing data as zero. Audit sensitive exports and mutating actions via existing services. Deliver frontend, typed API contracts, migrations where needed, tests, operational documentation and telemetry.

## Shared reporting semantics (mandatory across all three pages)

- Canonical unit: one deployment execution attempt against one target workspace from the existing deployment run ledger. Grouped launches are separate entities; never sum groups and target runs together. Provider jobs, stages, resource steps and webhook deliveries are not extra deployments. Link provider attempts to canonical run attempts; deduplicate by stable IDs. Report rollback/recovery separately by default; provide an explicit include-recovery filter.
- Canonical outcomes: queued, awaiting approval, running, verifying, succeeded, partial, failed, cancelling, cancelled, timed out, unknown. Map actual existing enums centrally. Success means verified success, not dispatch or provider success alone. Terminal execution outcomes are succeeded/partial/failed/cancelled/timed out; unknown is not terminal. Approval rejection before execution is not a failed deployment.
- For outcome metrics use terminal completion time; for starts use actual execution start time; for backlog use current state as of response time. Do not mix cohorts. Define eligible completed outcomes as succeeded + partial + failed + timed out; cancelled excluded and displayed separately. Success rate = succeeded / eligible completed; failure rate = (failed + timed out) / eligible completed; partial rate = partial / eligible completed. Return null with reason when denominator is zero. Duration = terminal timestamp minus actual start for valid pairs; report queue and approval wait separately. Invalid timestamps excluded and counted as data-quality issues.
- Every response includes effective filters, metric definition version, generated_at, source watermark, coverage/quality flags and freshness. Default period 30 days for overview/analytics and 24 hours for activity; configurable. Current-state cards explicitly ignore historical date filter where appropriate and say so. Drill-down preserves scope, cohort, timezone and exclusions. Use consistent colors and text labels across pages.
## 1. Objective and layout

Provide a role-aware landing page answering: what is deployed, what is running, what needs attention, and whether the deployment platform is healthy. This is a summary, not a replacement for Deployment History, Pipeline Runs or Analytics.

### Global controls
Tenant context from authenticated session; project multi-select; workspace/environment filter; project type; execution mode; period (7/30/90 days/custom); refresh; last updated; reset filters. Persist only non-sensitive preferences. Default all authorized scopes. Date filter affects historical panels only. Show current-state labels on backlog/health.

### KPI cards
| Card | Definition | Drill-down |
|---|---|---|
| Active projects | Authorized projects in active lifecycle state now | All Projects |
| Connected workspaces | Verified/enabled connections now; separate degraded count | Workspace Connections |
| Deployments | Eligible completed attempts plus cancelled, with explicit total label | Deployment History |
| Verified success rate | Shared definition, with denominator and prior-period delta in percentage points | Deployment Analytics |
| In progress | Queued/running/verifying/cancelling now; separate approval backlog | Deployment Activity |
| Pending approvals | Open actionable requests, distinct request IDs, scoped to user | Approvals |
| Failed/partial deployments | Failed, timed out and partial counts separately | Deployment History |
| Open recovery cases | Nonclosed cases with current status | Rollback & Recovery |

### Panels and interactions
- Deployment trend: stacked daily outcome counts, selectable granularity, previous equal-duration period comparison; clicking segment opens filtered history.
- Environment health: DEV/QA/UAT/STAGING/PROD/custom rows; verified/degraded/unknown connections, active runs, recent outcomes, last check; do not equate connection health with workload health.
- Project status: breakdown by four project types, lifecycle and recent outcome; click through to project details. Terraform and ML are facets, not project types.
- Recent deployments: latest ten authorized target attempts, project, environment, source version, status, start/end, actor, provider, verification and details link.
- Attention center: failed/partial runs, stale plans, pending approvals assigned to user, blocked policies, degraded connections, missing provider reconciliation, drift and recovery cases. Each item shows reason, age, severity, owner if known, next action and source link. Deduplicate by source entity + issue type; prioritize critical/high then age; show dismissed/acknowledged state only if existing alert workflow supports it.
- Release snapshot: recent promotions and environment progression, ML model promotions included; show partial/blocked state and release links. No independent release mutation.
- Platform health: app/backend availability, Lakebase connectivity, worker heartbeat, provider reconciliation freshness, artifact storage and GitHub integration status. Display UNKNOWN if not measured. Never expose host secrets or infrastructure internals to ordinary viewers.
- Quick actions: Create Project, Deploy Now, Workspace Connections, Review Approvals, Compare & Sync; visible only when authorized, navigate to existing workflows rather than executing changes directly.

## 2. Backend implementation

Create/reuse `dashboard_overview_service`, `reporting_scope_resolver`, `deployment_metrics_service`, `attention_query_service`, `platform_health_reader`. Fetch scoped aggregates in bounded parallel queries; return independent panel status so one failure does not blank the page. Suggested read endpoints: GET `/api/dashboard/overview`, `/api/dashboard/attention`, `/api/dashboard/health`; align with current conventions. Response sections: kpis (value, unit, denominator, previous_value, delta, status), trend (bucket, counts), environments, recent_runs, attention, release_summary, health, metadata. Use parameterized SQL and bounded page sizes. Cache only with tenant + permission-scope fingerprint + filter + metric version; invalidate on authorization changes. Suggested TTL 30–60 seconds, configurable; manual refresh rate-limited. Never cache global totals for restricted users.

## 3. Reference DDL (only if existing preferences/health records cannot be reused)

```sql
CREATE TABLE IF NOT EXISTS dashboard_user_preferences (
 tenant_id uuid NOT NULL REFERENCES tenants(id),
 user_id uuid NOT NULL REFERENCES app_users(id),
 page_key text NOT NULL CHECK(page_key IN ('OVERVIEW','ACTIVITY','ANALYTICS')),
 preferences jsonb NOT NULL DEFAULT '{}'::jsonb,
 updated_at timestamptz NOT NULL DEFAULT now(),
 PRIMARY KEY(tenant_id,user_id,page_key)
);
CREATE TABLE IF NOT EXISTS dashboard_component_health (
 tenant_id uuid NOT NULL REFERENCES tenants(id),
 component_key text NOT NULL,
 status text NOT NULL CHECK(status IN ('HEALTHY','DEGRADED','UNAVAILABLE','UNKNOWN')),
 checked_at timestamptz NOT NULL,
 expires_at timestamptz NOT NULL,
 safe_summary text,
 PRIMARY KEY(tenant_id,component_key),
 CHECK(expires_at >= checked_at)
);
```
Use composite tenant/user FK if supported by actual user schema. Health rows are written by trusted monitoring workers, never browser. Expired checks render UNKNOWN/stale. No new KPI tables required; query canonical sources. Validate preference JSON schema and size; reauthorize saved filters on load.

## 4. Permissions and quality gates
`dashboard.view`, `dashboard.health.view`, plus existing project/workspace/approval permissions. Platform-wide health details restricted to admins. Never show unauthorized attention items. AI insights optional: summarize only scoped aggregate evidence with links and timestamps; no autonomous actions or unsupported predictions.

## 5. Acceptance tests
- KPI values reconcile exactly with filtered history, including cancelled/partial and multi-target attempts.
- Empty tenant shows useful onboarding and null rates, not fake zeros for missing sources.
- Restricted user cannot infer hidden project totals through cards, deltas, health or cache.
- Current backlog unaffected by historical period and clearly labeled; prior-period delta handles zero baseline.
- Degraded workspace, stale health, pending approval and failed provider reconciliation appear with correct source links.
- Partial API failure preserves working panels; refresh does not trigger live scans of all workspaces.
- Quick actions respect permissions and do not bypass existing deployment/approval flow.
- Test responsive layout, keyboard use, timezone boundaries and query plans on realistic history volume.
