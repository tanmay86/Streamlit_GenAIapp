# DASH-02 — Deployment Activity | Detailed implementation specification

Navigation: Dashboard → Deployment Activity. Suggested route `/dashboard/activity`.

## Coding-agent contract

Product: JadeOrbit DeployPactAI. Build production functionality, not mock dashboards. Read PROJECT_REQUIREMENTS.md, PROJECT_ARCHITECTURE.md and all existing module specifications. Inspect actual routes, React/TypeScript components, FastAPI services, Lakebase PostgreSQL schema, Alembic migrations, RBAC, audit, provider reconciliation and deployment workers before coding. Reuse the existing design system and services. Preserve current Databricks connectivity. The four project types are Direct Deployment, Git-Enabled Deployment, Release Promotion (including ML model promotion), and Workspace Synchronization. Terraform is an execution option, not a project type.

Use React/TypeScript, FastAPI/Python, Lakebase PostgreSQL, Databricks SDK/REST, existing durable Jobs/workers, GitHub Actions integration and approved artifact storage. Dashboard queries read operational metadata, not customer table data. Do not call every target workspace or GitHub API on each page load; use existing reconciled state and health snapshots. Do not introduce a separate execution engine or duplicate run ledger. All DDL is reference PostgreSQL: inspect actual schemas and use additive Alembic migrations, tenant-consistent FKs, least-privilege database roles and existing naming conventions. Do not execute DDL blindly. No actual repository or live database was inspected for these specifications.

All reads enforce tenant AND project/workspace permissions server-side before aggregation, including counts, exports, drill-downs, caches and event subscriptions. For multi-target groups, show only authorized targets and label partial visibility; never leak hidden totals. Never expose tokens, secret values, raw Terraform state, sensitive source or unredacted logs. Use UTC storage, user-selected IANA timezone for display, half-open date intervals [start,end), explicit freshness timestamps, accessible charts/tables, keyboard navigation, loading/empty/error/partial/stale states. No invented metrics, sample data in production, or treating missing data as zero. Audit sensitive exports and mutating actions via existing services. Deliver frontend, typed API contracts, migrations where needed, tests, operational documentation and telemetry.

## Shared reporting semantics (mandatory across all three pages)

- Canonical unit: one deployment execution attempt against one target workspace from the existing deployment run ledger. Grouped launches are separate entities; never sum groups and target runs together. Provider jobs, stages, resource steps and webhook deliveries are not extra deployments. Link provider attempts to canonical run attempts; deduplicate by stable IDs. Report rollback/recovery separately by default; provide an explicit include-recovery filter.
- Canonical outcomes: queued, awaiting approval, running, verifying, succeeded, partial, failed, cancelling, cancelled, timed out, unknown. Map actual existing enums centrally. Success means verified success, not dispatch or provider success alone. Terminal execution outcomes are succeeded/partial/failed/cancelled/timed out; unknown is not terminal. Approval rejection before execution is not a failed deployment.
- For outcome metrics use terminal completion time; for starts use actual execution start time; for backlog use current state as of response time. Do not mix cohorts. Define eligible completed outcomes as succeeded + partial + failed + timed out; cancelled excluded and displayed separately. Success rate = succeeded / eligible completed; failure rate = (failed + timed out) / eligible completed; partial rate = partial / eligible completed. Return null with reason when denominator is zero. Duration = terminal timestamp minus actual start for valid pairs; report queue and approval wait separately. Invalid timestamps excluded and counted as data-quality issues.
- Every response includes effective filters, metric definition version, generated_at, source watermark, coverage/quality flags and freshness. Default period 30 days for overview/analytics and 24 hours for activity; configurable. Current-state cards explicitly ignore historical date filter where appropriate and say so. Drill-down preserves scope, cohort, timezone and exclusions. Use consistent colors and text labels across pages.
## 1. Objective

Build a near-real-time operational console for active and recent deployment events across all project types and execution modes. Deployment History remains the authoritative historical detail page; Pipeline Runs remains the provider-level CI/CD detail page. Activity is a unified live projection, not another execution ledger.

## 2. Page design and interactions
- Global filters: authorized project, workspace, environment, type, mode, status, severity, actor, trigger, correlation ID, time range; search by run ID/resource key. Live/pause toggle, refresh, last event time and connection status.
- Current-state cards: queued, running, verifying, waiting approval, cancelling, stalled/unknown; current counts independent of historical feed filter, clearly labeled.
- Active deployments table: run ID, project, target, mode, initiator, current stage, completed/total known steps, elapsed time, last heartbeat, provider status, approval status, correlation ID. Progress is completed known steps / known total, not invented percentage; indeterminate if total unknown. Expand target group only for authorized targets.
- Event feed: timestamp, severity, event type, project/run/target, safe summary, source (SDK worker/GitHub/Terraform/release/sync/approval), correlation ID. Event families: queued, plan validated, approval requested/decided, dispatched, provider correlated, step started/completed/failed, verification, cancellation, retry, recovery, drift, health warning. Filter noisy informational events; paginate older events.
- Run detail drawer: lifecycle timeline, target, immutable plan link, stage/step status, safe error code and summary, provider run link, verification, recovery eligibility, latest reconciliation timestamp. Link to full Deployment History and Pipeline Runs; no raw sensitive logs in feed.
- Operational alerts: stalled heartbeat, unknown provider status, approval overdue, target connectivity degraded, repeated failure, lock contention, policy block. Show threshold, observed value, source, first/last seen and severity. Distinguish alert from confirmed failure.
- Actions: refresh, view plan, review approval, view logs, cancel, retry/recover, acknowledge alert. Mutating actions call existing authorized endpoints with confirmation and idempotency; never directly edit run status. Cancel remains CANCELLING until reconciled; retry may require fresh plan/approval. Acknowledgment does not resolve underlying condition.

## 3. Backend and live update design

Reuse deployment_run_events, deployment_runs, deployment steps, pipeline provider links, approvals and audit records. Implement `activity_query_service`, `activity_projection_worker`, `activity_stream_service`, `operational_alert_evaluator`. Prefer existing transactional outbox; project events idempotently. If SSE is supported by Databricks Apps/proxy, use authenticated same-origin SSE with heartbeat and resumable cursor; otherwise use bounded polling (suggested 10–15 seconds active, 30–60 idle, configurable). Never place bearer tokens in URLs. Reauthorize on reconnect and periodically; terminate subscription after permission revocation. Use backoff/jitter, pause hidden tabs, cap clients and batch events. Live UI should deduplicate by stable event ID and merge out-of-order updates using canonical run version. Do not assume global sequence from provider timestamps.

Suggested endpoints: GET `/api/dashboard/activity/runs`, `/events?cursor=...`, `/alerts`, `/stream` if supported. Return opaque scope-bound cursor, event ID, occurred_at, received_at, run version, source, safe summary, next cursor, watermark. Initial snapshot and subsequent updates must overlap safely or use a consistent cursor boundary; detect gaps and resnapshot. For SSE use committed outbox cursor or overlap/reconciliation; sequence allocation alone is not commit order. Filter before delivery, not client-side. Cap historical lookback and paginate.

## 4. Alert rules and failure handling

Thresholds configurable via existing Application Settings/Deployment Policies: queue age, worker heartbeat age, provider reconciliation age, approval due date, repeated failures, lock wait. Defaults are suggestions, not SLAs: stale heartbeat 5 minutes only for workers expected to heartbeat; provider stale 10 minutes only for active monitored runs. Do not declare a long-running GitHub job stalled merely because no log arrived. Alerts open/update/resolve on observed condition, deduplicate by tenant + entity + rule, throttle notifications and use existing notification service. Show source unavailable separately from zero events. On provider outage retain last known status with stale badge; on database outage show retry and last successful snapshot only if still authorized.

## 5. Reference DDL (optional projection; do not duplicate existing outbox or alert tables)

```sql
CREATE TABLE IF NOT EXISTS dashboard_activity_projection (
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
 tenant_id uuid NOT NULL REFERENCES tenants(id),
 source_system text NOT NULL,
 source_event_key text NOT NULL,
 deployment_run_id uuid,
 project_id uuid,
 workspace_id uuid,
 event_type text NOT NULL,
 severity text NOT NULL CHECK(severity IN ('INFO','WARNING','ERROR','CRITICAL')),
 safe_summary text NOT NULL,
 correlation_id text,
 occurred_at timestamptz NOT NULL,
 received_at timestamptz NOT NULL DEFAULT now(),
 UNIQUE(tenant_id,source_system,source_event_key)
);
CREATE INDEX IF NOT EXISTS ix_activity_feed ON dashboard_activity_projection(tenant_id,occurred_at DESC,id DESC);
CREATE INDEX IF NOT EXISTS ix_activity_run ON dashboard_activity_projection(tenant_id,deployment_run_id,occurred_at DESC);
CREATE TABLE IF NOT EXISTS dashboard_operational_alerts (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 tenant_id uuid NOT NULL REFERENCES tenants(id),
 entity_kind text NOT NULL,
 entity_ref text NOT NULL,
 rule_key text NOT NULL,
 severity text NOT NULL CHECK(severity IN ('WARNING','ERROR','CRITICAL')),
 status text NOT NULL CHECK(status IN ('OPEN','ACKNOWLEDGED','RESOLVED')),
 safe_summary text NOT NULL,
 first_seen_at timestamptz NOT NULL DEFAULT now(),
 last_seen_at timestamptz NOT NULL DEFAULT now(),
 acknowledged_by uuid REFERENCES app_users(id),
 acknowledged_at timestamptz,
 resolved_at timestamptz
);
CREATE UNIQUE INDEX IF NOT EXISTS ux_dashboard_active_alert ON dashboard_operational_alerts(tenant_id,entity_kind,entity_ref,rule_key) WHERE status IN ('OPEN','ACKNOWLEDGED');
```
Add tenant-consistent FKs to canonical entities; alert polymorphic references must resolve to authorized entities before display. If no authorized entity can be resolved, restrict to appropriate platform admin. Use existing retention policies; projection can be rebuilt, canonical history remains intact. Confirm UUID generation available. No secrets in summaries.

## 6. Acceptance tests
- Direct SDK, GitHub, Terraform, release, sync and recovery events appear without duplicate deployment counts.
- Duplicate/out-of-order webhook and worker events do not regress run state; reconnect catches missed events.
- Active progress indeterminate for unknown totals; provider success does not imply verified success.
- Paused feed resumes correctly; stale/offline states and polling fallback work.
- Restricted subscriptions, exports and alert actions deny cross-tenant/project access, including after permission revocation.
- Cancel/retry route through existing policies; production approval cannot be bypassed.
- Alert dedup, acknowledgement, resolution, threshold changes and notification throttling work.
- Load-test event bursts, pagination and reconnect; verify no per-browser provider polling fanout.
