# DASH-03 — Deployment Analytics | Detailed implementation specification

Navigation: Dashboard → Deployment Analytics. Suggested route `/dashboard/analytics`.

## Coding-agent contract

Product: JadeOrbit DeployPactAI. Build production functionality, not mock dashboards. Read PROJECT_REQUIREMENTS.md, PROJECT_ARCHITECTURE.md and all existing module specifications. Inspect actual routes, React/TypeScript components, FastAPI services, Lakebase PostgreSQL schema, Alembic migrations, RBAC, audit, provider reconciliation and deployment workers before coding. Reuse the existing design system and services. Preserve current Databricks connectivity. The four project types are Direct Deployment, Git-Enabled Deployment, Release Promotion (including ML model promotion), and Workspace Synchronization. Terraform is an execution option, not a project type.

Use React/TypeScript, FastAPI/Python, Lakebase PostgreSQL, Databricks SDK/REST, existing durable Jobs/workers, GitHub Actions integration and approved artifact storage. Dashboard queries read operational metadata, not customer table data. Do not call every target workspace or GitHub API on each page load; use existing reconciled state and health snapshots. Do not introduce a separate execution engine or duplicate run ledger. All DDL is reference PostgreSQL: inspect actual schemas and use additive Alembic migrations, tenant-consistent FKs, least-privilege database roles and existing naming conventions. Do not execute DDL blindly. No actual repository or live database was inspected for these specifications.

All reads enforce tenant AND project/workspace permissions server-side before aggregation, including counts, exports, drill-downs, caches and event subscriptions. For multi-target groups, show only authorized targets and label partial visibility; never leak hidden totals. Never expose tokens, secret values, raw Terraform state, sensitive source or unredacted logs. Use UTC storage, user-selected IANA timezone for display, half-open date intervals [start,end), explicit freshness timestamps, accessible charts/tables, keyboard navigation, loading/empty/error/partial/stale states. No invented metrics, sample data in production, or treating missing data as zero. Audit sensitive exports and mutating actions via existing services. Deliver frontend, typed API contracts, migrations where needed, tests, operational documentation and telemetry.

## Shared reporting semantics (mandatory across all three pages)

- Canonical unit: one deployment execution attempt against one target workspace from the existing deployment run ledger. Grouped launches are separate entities; never sum groups and target runs together. Provider jobs, stages, resource steps and webhook deliveries are not extra deployments. Link provider attempts to canonical run attempts; deduplicate by stable IDs. Report rollback/recovery separately by default; provide an explicit include-recovery filter.
- Canonical outcomes: queued, awaiting approval, running, verifying, succeeded, partial, failed, cancelling, cancelled, timed out, unknown. Map actual existing enums centrally. Success means verified success, not dispatch or provider success alone. Terminal execution outcomes are succeeded/partial/failed/cancelled/timed out; unknown is not terminal. Approval rejection before execution is not a failed deployment.
- For outcome metrics use terminal completion time; for starts use actual execution start time; for backlog use current state as of response time. Do not mix cohorts. Define eligible completed outcomes as succeeded + partial + failed + timed out; cancelled excluded and displayed separately. Success rate = succeeded / eligible completed; failure rate = (failed + timed out) / eligible completed; partial rate = partial / eligible completed. Return null with reason when denominator is zero. Duration = terminal timestamp minus actual start for valid pairs; report queue and approval wait separately. Invalid timestamps excluded and counted as data-quality issues.
- Every response includes effective filters, metric definition version, generated_at, source watermark, coverage/quality flags and freshness. Default period 30 days for overview/analytics and 24 hours for activity; configurable. Current-state cards explicitly ignore historical date filter where appropriate and say so. Drill-down preserves scope, cohort, timezone and exclusions. Use consistent colors and text labels across pages.
## 1. Objective

Provide historical analysis of deployment throughput, reliability, speed, governance and recovery across authorized projects/environments. Enable evidence-based improvements without claiming unmeasured cost savings, incident rates or DORA metrics. Operational deployment failure rate is not automatically DORA change failure rate.

## 2. Page layout
- Filter bar: date range, comparison period, granularity (day/week/month), timezone, project, project type, workspace, environment, execution mode, trigger, asset family, include recovery. Asset-family filter uses EXISTS on resource changes, not a join that duplicates runs. Default 30 days, daily buckets; cap custom range based on query budget. Week starts Monday; month calendar-based.
- KPI row: completed attempts, verified success rate, failure/partial rate, median and p95 execution duration, median approval wait, deployment frequency; each shows definition, sample size, prior period and coverage.
- Throughput: stacked outcome time series, deployment frequency by environment, project and execution mode; distinguish starts and completions.
- Reliability: success/failure/partial trend, top failure categories, affected resource families, retry rate, verification failures, provider vs application failures. Unknown/unclassified category visible.
- Performance: p50/p95 execution duration trend, queue wait, approval wait, stage duration, target/mode comparisons. Do not average percentiles across groups.
- Governance: approval request counts, approval/rejection/expiry rates, wait duration, policy blocks by rule, production deployments with required approval evidence; missing evidence flagged, not silently counted compliant.
- Recovery: recovery cases, rollback attempts, verified recovery rate, median recovery duration, manual/nonreversible cases; distinguish deployment recovery from service incident recovery.
- Release/ML: promotion success and duration by environment, release lead time, model promotion and serving verification outcomes; separate model and release counts.
- Drift/sync: comparison runs, detected differences, sync outcomes, unresolved drift where tracked; no claim of data replication.
- DORA panel: production deployment frequency, change lead time, change failure rate, failed deployment recovery time, deployment rework rate when evidence supports it. Show missing prerequisites and coverage. No fabricated industry ranking or benchmark.
- Export: scoped CSV for metric series and underlying authorized records; asynchronous large exports, expiry, audit, formula injection protection. Chart tooltips, table alternatives, click-through to filtered history/approvals/recovery. No write operations.

## 3. Metric dictionary and computation

| Metric | Formula / cohort | Required data |
|---|---|---|
| Deployment frequency | Verified successful forward production target deployments / observed calendar days; also show count and explicit target-based counting | run outcome, environment classification snapshot, completion |
| Success/failure/partial | Shared definitions | canonical terminal run outcome |
| Execution duration | p50/p95 of valid completed execution durations; PostgreSQL percentile_cont or equivalent | actual start/end |
| Queue wait | actual start minus queued timestamp, excluding invalid pairs | queue/start events |
| Approval wait | decision timestamp minus request timestamp, per decided request; pending age separate | approval records |
| Approval rejection rate | rejected / (approved + rejected), expiry separate | approval outcomes |
| Retry rate | forward intents with >1 attempt / forward intents with at least one attempt; only if stable intent ID exists | intent and attempt IDs |
| Verification failure rate | runs failing verification / runs with completed verification | verification result |
| Recovery success | verified recovered cases / completed recovery cases (recovered, partial, failed); manual cases separate | recovery case outcome |
| Recovery duration | verified recovery completion minus recovery start, not incident MTTR | recovery timestamps |
| Change lead time (DORA) | median commit-to-successful-production elapsed time for attributable changes; define commit timestamp convention, dedup commit/service scope | commit provenance, production deployment mapping |
| Change failure rate (DORA) | production deployments requiring remediation due to attributable production failure / production deployments with adequate incident attribution coverage | linked incidents/remediation, production scope |
| Failed deployment recovery time (DORA) | median time from attributable production deployment failure to verified service restoration | incident failure/restoration timestamps |
| Deployment rework rate (DORA) | unplanned production deployments attributable to production incidents / production deployments in covered scope | incident linkage, planned/unplanned classification |
| Release promotion duration | verified promotion end minus promotion start | promotion records |
| Drift resolution rate | resolved monitored differences / eligible tracked differences, only with stable difference lifecycle IDs | comparison/sync evidence |

DORA panel is explicitly scoped to monitored Databricks deployments, not necessarily entire software delivery performance. If incident/service restoration data is absent, display N/A and explain required instrumentation. Do not substitute rollback duration or failed job count. Show coverage numerator/denominator, exclude incomplete observations transparently. For commit lead time, do not use release creation as commit timestamp; separate release lead time if available. Production classification must use historical snapshot; unknown classification excluded and reported. Prior-period rate delta in percentage points; count delta percentage only if prior >0. Bucket missing observations as null when ingestion coverage unknown, zero only when complete and no events.

## 4. Backend architecture and query strategy

`analytics_scope_resolver`, `metric_registry`, `analytics_query_service`, `analytics_rollup_worker`, `data_quality_service`, `analytics_export_service`. Reuse canonical run, event, approval, release, recovery, comparison and provider records. Suggested endpoints GET `/api/dashboard/analytics/summary`, `/series`, `/breakdowns`, `/quality`; POST `/exports` with authorized scope and validated filters. Return metric ID/version, unit, value, sample size, numerator/denominator, coverage, cohort, bucket start/end, watermark and drill-down parameters. Use parameterized queries, server-side aggregation, query timeout, bounded filters and pagination. For arbitrary timezone buckets and percentiles query authorized facts or merge valid distributions; do not average daily rates/percentiles. Use weighted numerator/denominator sums. Cache scoped results only; no broad tenant aggregate exposed to restricted roles.

Illustrative query (adapt canonical table/columns and permission predicate):
```sql
WITH scoped AS (
 SELECT r.id, r.status, r.started_at, r.completed_at
 FROM deployment_runs r
 WHERE r.tenant_id = :tenant_id
   AND r.completed_at >= :start_utc AND r.completed_at < :end_utc
   AND r.status IN ('SUCCEEDED','PARTIAL','FAILED','TIMED_OUT','CANCELLED')
   -- REQUIRED: apply authorized project/workspace scope and selected filters here
   -- REQUIRED: exclude recovery by default using canonical run intent
)
SELECT count(*) AS completed,
 count(*) FILTER (WHERE status='SUCCEEDED') AS succeeded,
 count(*) FILTER (WHERE status IN ('FAILED','TIMED_OUT')) AS failed,
 count(*) FILTER (WHERE status='PARTIAL') AS partial,
 count(*) FILTER (WHERE status='CANCELLED') AS cancelled,
 count(*) FILTER (WHERE status='SUCCEEDED')::numeric /
 NULLIF(count(*) FILTER (WHERE status <> 'CANCELLED'),0) AS success_ratio,
 percentile_cont(0.5) WITHIN GROUP (ORDER BY extract(epoch FROM completed_at-started_at))
 FILTER (WHERE started_at IS NOT NULL AND completed_at >= started_at) AS median_seconds
FROM scoped;
```
This is a reference query, not safe to expose until authorization predicates are implemented. Validate all metrics against fixtures and canonical history.

## 5. Reference DDL (optional performance optimization and missing incident evidence)

Start with indexed canonical queries. Introduce rollups only after measuring latency. Use per-project/workspace/day dimensions to preserve access scope; UTC rollups cannot answer arbitrary local-day boundaries without raw facts. Rebuild affected buckets on late events; upsert transactionally; record watermark and definition version. Do not store precomputed percentile as mergeable statistic.

```sql
CREATE TABLE IF NOT EXISTS dashboard_deployment_daily_rollups (
 tenant_id uuid NOT NULL REFERENCES tenants(id),
 project_id uuid NOT NULL,
 workspace_id uuid NOT NULL,
 bucket_date_utc date NOT NULL,
 environment_key text NOT NULL,
 project_type text NOT NULL,
 execution_mode text NOT NULL,
 is_recovery boolean NOT NULL,
 metric_version integer NOT NULL,
 succeeded bigint NOT NULL DEFAULT 0 CHECK(succeeded>=0),
 failed bigint NOT NULL DEFAULT 0 CHECK(failed>=0),
 partial bigint NOT NULL DEFAULT 0 CHECK(partial>=0),
 cancelled bigint NOT NULL DEFAULT 0 CHECK(cancelled>=0),
 timed_out bigint NOT NULL DEFAULT 0 CHECK(timed_out>=0),
 duration_sum_seconds numeric NOT NULL DEFAULT 0,
 duration_sample_count bigint NOT NULL DEFAULT 0,
 source_watermark timestamptz NOT NULL,
 refreshed_at timestamptz NOT NULL DEFAULT now(),
 PRIMARY KEY(tenant_id,project_id,workspace_id,bucket_date_utc,environment_key,project_type,execution_mode,is_recovery,metric_version)
);
CREATE INDEX IF NOT EXISTS ix_dashboard_rollup_period ON dashboard_deployment_daily_rollups(tenant_id,bucket_date_utc);
-- Optional: only if no existing incident/remediation linkage is available.
CREATE TABLE IF NOT EXISTS deployment_incident_attributions (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 tenant_id uuid NOT NULL REFERENCES tenants(id),
 deployment_run_id uuid NOT NULL,
 incident_ref text NOT NULL,
 attribution_status text NOT NULL CHECK(attribution_status IN ('PENDING','CONFIRMED','REJECTED')),
 failure_at timestamptz,
 service_restored_at timestamptz,
 evidence_ref text,
 reviewed_by uuid REFERENCES app_users(id),
 reviewed_at timestamptz,
 UNIQUE(tenant_id,deployment_run_id,incident_ref),
 CHECK(service_restored_at IS NULL OR (failure_at IS NOT NULL AND service_restored_at >= failure_at))
);
```
Add tenant-consistent FKs to actual projects/workspaces/runs/users. Incident attribution must come from approved incident workflow or verified integration; do not infer it from failed deployment alone. Rollup cannot support arbitrary actor/asset/trigger filters unless dimensions included; fall back to facts. Retention and late-event correction must follow existing audit policies. No extra SQL warehouse required for operational analytics unless separately justified by measured scale.

## 6. Security, performance and acceptance

Permissions: `dashboard.analytics.view`, `dashboard.analytics.export` plus canonical scope. Audit export request/download, protect artifact links, expire reports. Suggested performance target p95 under 2 seconds for standard 30-day scoped summary on agreed representative data volume; measure and tune, not guaranteed. Use background rollups for expensive queries, partial panel responses, explain plans and load tests. No direct calls to production workspaces for chart refresh.

Acceptance tests: fixture with 6 successes, 2 failures, 1 partial, 1 timeout, 2 cancelled gives 12 completed, denominator 10, success 60%, failure 30%, partial 10%; zero denominator returns null. Multi-target and provider attempts deduplicate correctly. Timezone/DST boundaries and previous periods correct. Percentiles computed from underlying samples, not averages of percentiles. Late event refresh changes correct bucket. Missing incident attribution yields N/A DORA metric. Unauthorized data excluded before aggregation and export. Filtered drill-down matches chart cohort. Rollups match raw queries for supported filters. Verify CSV formula injection defense, large export expiry, empty/stale/partial states, accessible chart alternatives and performance.
