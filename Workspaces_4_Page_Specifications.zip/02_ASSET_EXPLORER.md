# WORKSPACE-02 — Asset Explorer | Full Implementation Specification

**Navigation:** Workspaces → Asset Explorer

## Coding-agent implementation contract

- **Product:** JadeOrbit DeployPactAI; **module:** Workspaces; **scope:** full production feature, not MVP.
- Inspect `PROJECT_REQUIREMENTS.md`, `PROJECT_ARCHITECTURE.md`, existing Administration specifications, routes, database models, migrations, identity middleware and Databricks adapters **before modifying code**. Extend existing conventions; do not create parallel authentication, database, or SDK frameworks.
- Existing application is operational and connected to a Databricks workspace. Preserve it. Implement additive Alembic migrations, feature flags where appropriate, and backward-compatible behavior.
- Stack: React + TypeScript frontend; Python FastAPI backend; Databricks SDK/REST APIs; Lakebase PostgreSQL metadata; Databricks Jobs for durable work; Unity Catalog Volumes/object storage for large artifacts; GitHub Actions and Terraform integrations when relevant.
- All operations are **tenant-scoped**, permission-checked on the server, audited, observable and idempotent. Never rely on disabled UI buttons as authorization.
- Do not store OAuth tokens, PATs, private keys or secret values in Lakebase; store secret references in an approved secret manager. Never expose tokens or sensitive response payloads to browser/logs.
- DDL below is **reference DDL**; reconcile names and relationships with existing schema and create migrations rather than blindly executing it. Assume `tenants(id)`, `app_users(id)` and `workspaces(id)` may already exist; verify before migration.
- Do not implement cross-account capabilities by assuming common Unity Catalog metastores, common identities, or automatic target access. Check capabilities and privileges for each target independently.
- Prefer deterministic rules and Databricks-native APIs; any AI suggestions must be optional, explainable and never authorize or execute a change.
- Deliver frontend pages, backend services, typed contracts, database migrations, automated tests, user-visible errors, loading/empty states, documentation and operational metrics. Avoid placeholder-only functionality.

## 1. Objective

Provide a unified, read-first catalog of discoverable Databricks workspace assets, their definitions, dependencies, ownership, deployability and target portability. Asset Explorer is the source selection surface for **all four project types** and supports dependency-aware packaging and deployment planning. It is **not** a data browser that copies table rows or reveals secrets.

## 2. Page sections and user journeys

- **Workspace selector:** choose one authorized source workspace; show account/cloud, environment, connection status and inventory freshness.
- **Explorer:** left navigation tree by resource family and workspace folder; main list/table with asset name, logical path, type, ID, owner (if available), modified timestamp, tags, deployment support, dependency count and sync/drift indicator when known.
- **Search & filters:** keyword, type, folder/catalog/schema, owner, tag, last modified, capability, deployability, discovered vs cached, selection state.
- **Asset details drawer:** metadata, definition preview (redacted), version/fingerprint, dependency graph, references, source location, target compatibility, permissions summary, history, warnings and source link.
- **Selection tray:** multi-select across supported asset families, include/exclude dependencies, package selection, create project from selection, export sanitized manifest.
- **Discovery controls:** refresh all/selected type, progress and partial failures, last indexed timestamp, unsupported types, inventory TTL.
- **Optional AI assist:** propose dependency candidates, summarize changes and describe portability risks from approved metadata only. AI output is untrusted advice; no automatic selection, permission changes or deployment.

## 3. Supported asset families and portability rules

| Family | Discover/preview | Deployment considerations |
|---|---|---|
| Workspace notebooks and files | Paths, language, source metadata | Import/export; preserve language and folder structure; avoid exporting sensitive contents to AI |
| Jobs/workflows | Settings, tasks, job clusters, schedules | Rewrite task references, run-as, compute IDs, notebooks, pipeline IDs, schedules; preserve paused schedule by policy |
| Lakeflow Declarative Pipelines | Pipeline definition/config, libraries, storage/UC references | API/feature availability, library paths, target catalogs, identities, pipeline ownership |
| SQL queries and AI/BI dashboards | Supported metadata/definitions | API-dependent; credential, warehouse and sharing differences; no guarantee every dashboard format is portable |
| SQL warehouses, compute policies | Configuration metadata | Capacity, policy constraints, cloud/region compatibility; generally map/recreate, not copy active compute state |
| Unity Catalog | Catalog/schema/table/view/function/volume metadata, grants where authorized | Distinguish shared metastore from cross-metastore; table data and external storage are **not** migrated by definition deployment |
| MLflow models | Registered models, versions, aliases, tags, lineage where available | ML promotion handled within Release Promotion; artifacts and dependencies need separate verified transfer/access plan |
| Serving endpoints | Config and model references | Credentials, quotas, network, scaling and model availability must be remapped |
| Databricks Apps | App metadata/config where supported | Source/packaging and secrets require explicit handling; no implicit extraction of proprietary source |
| Secret scopes | Names and ACL metadata only if authorized | **Never** retrieve/display/export secret values; require independent target secret provisioning |

Each adapter exposes `discover`, `describe`, `fingerprint`, `dependencies`, `portability`, `export_manifest`, `verify`; `deploy` lives in execution adapters. If a Databricks SDK/API does not support a resource operation, show `UNSUPPORTED` rather than a fake deploy action.

## 4. Discovery and indexing behavior

1. Discovery runs through source workspace-scoped SDK clients and least-privilege identities; list resources with pagination and bounded concurrency.
2. Index metadata into Lakebase; put large source artifacts in approved UC Volume/object storage with access controls, encryption and TTL only when explicitly exported.
3. Track `last_seen_at`, `last_discovered_at`, canonical source resource ID, resource type, logical key, sanitized metadata, fingerprint/hash, capability status and deletion tombstones.
4. Distinguish `NOT_DISCOVERED`, `DISCOVERED`, `STALE`, `INACCESSIBLE`, `DELETED`, `UNSUPPORTED`, `ERROR`. Do not equate “not returned by API” with deleted when permissions/pagination fail.
5. Make refresh asynchronous/durable; show progress per asset family and partial errors; retry transient failures with backoff; respect rate limits.
6. Stable logical keys should be type + workspace + canonical path/name as applicable; maintain original resource ID for reconciliation and resource bindings.
7. Dependency extraction: explicit references from Jobs and pipelines; notebooks via static analysis only where reliable; dynamic code references are `INFERRED` and require review. Detect cycles and unresolved external references.
8. Treat secrets, PII, tokens, embedded credentials and notebook source as sensitive; redact before previews, logs, AI prompts and exports.
9. Export a **manifest** containing references/fingerprints/dependencies, not an unconditional full-data export. Use immutable package snapshots when creating deployment plans.
10. Asset explorer is read-only for source resources. Any destination modification occurs through approved deployment/sync flows.

## 5. Functional behavior

- Hierarchical tree, breadcrumbs, deep links, bulk selection, keyboard accessibility, lazy loading and pagination.
- Show compatibility badges for each target when target chosen: ready, requires mapping, blocked, unsupported, unknown.
- Compare definitions across snapshots and target resources only via authorized comparison; surface changes with safe diffs.
- Package selection must prevent unsupported assets from silently entering a deployable package; explicit warnings and exclusions required.
- Allow saved filters/views and recent workspace preference (non-sensitive) where supported by application settings.
- Source links must use canonical allowlisted workspace hosts; prevent open redirects.

## 6. Backend components

`asset_discovery_orchestrator`, `asset_adapter_registry`, `inventory_repository`, `dependency_analyzer`, `fingerprint_service`, `manifest_builder`, `sensitive_content_redactor`, `inventory_reconciler`.

Flow: UI refresh → authorization → durable discovery job → SDK adapters → normalize/sanitize → metadata DB → progress/event stream → explorer. Selection → dependency closure → immutable manifest → project/package builder.

## 7. Reference Lakebase PostgreSQL DDL

```sql
CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE TABLE IF NOT EXISTS workspace_asset_inventory (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES tenants(id),
  workspace_id uuid NOT NULL REFERENCES workspaces(id),
  asset_type text NOT NULL,
  external_asset_id text NOT NULL,
  logical_key text NOT NULL,
  display_name text NOT NULL,
  parent_path text,
  owner_display text,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  fingerprint_sha256 char(64),
  discoverability text NOT NULL DEFAULT 'DISCOVERED'
    CHECK(discoverability IN ('DISCOVERED','STALE','INACCESSIBLE','DELETED','UNSUPPORTED','ERROR')),
  deployability text NOT NULL DEFAULT 'UNKNOWN'
    CHECK(deployability IN ('SUPPORTED','MAPPING_REQUIRED','UNSUPPORTED','UNKNOWN')),
  last_seen_at timestamptz, last_discovered_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(tenant_id,workspace_id,asset_type,external_asset_id),
  UNIQUE(id,tenant_id)
);
CREATE INDEX IF NOT EXISTS ix_inventory_browse
  ON workspace_asset_inventory(tenant_id,workspace_id,asset_type,parent_path);
CREATE INDEX IF NOT EXISTS ix_inventory_freshness
  ON workspace_asset_inventory(tenant_id,workspace_id,last_discovered_at DESC);
CREATE TABLE IF NOT EXISTS workspace_inventory_runs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES tenants(id),
  workspace_id uuid NOT NULL REFERENCES workspaces(id),
  requested_by uuid REFERENCES app_users(id),
  status text NOT NULL CHECK(status IN ('QUEUED','RUNNING','PARTIAL','SUCCEEDED','FAILED','CANCELLED')),
  asset_types jsonb NOT NULL DEFAULT '[]'::jsonb,
  counters jsonb NOT NULL DEFAULT '{}'::jsonb,
  diagnostics jsonb NOT NULL DEFAULT '[]'::jsonb,
  started_at timestamptz, completed_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS workspace_asset_dependencies (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES tenants(id),
  source_asset_id uuid NOT NULL,
  target_asset_id uuid,
  unresolved_reference text,
  dependency_kind text NOT NULL,
  confidence text NOT NULL CHECK(confidence IN ('EXPLICIT','INFERRED','MANUAL')),
  required boolean NOT NULL DEFAULT true,
  evidence jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  FOREIGN KEY(source_asset_id,tenant_id) REFERENCES workspace_asset_inventory(id,tenant_id),
  FOREIGN KEY(target_asset_id,tenant_id) REFERENCES workspace_asset_inventory(id,tenant_id),
  CHECK (target_asset_id IS NOT NULL OR unresolved_reference IS NOT NULL)
);
CREATE TABLE IF NOT EXISTS asset_manifest_snapshots (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES tenants(id),
  workspace_id uuid NOT NULL REFERENCES workspaces(id),
  manifest jsonb NOT NULL,
  content_digest char(64) NOT NULL,
  artifact_location_ref text,
  created_by uuid REFERENCES app_users(id),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(tenant_id,content_digest)
);
```

**Schema integration:** if `assets` and `asset_dependencies` already exist, extend them rather than duplicating; keep tenant-consistent FKs. JSONB metadata is sanitized and size-limited.

## 8. Authorization, errors, audit and telemetry

- Permissions: `asset.view`, `asset.discover`, `asset.view_definition`, `asset.export_manifest`, `asset.view_dependencies`; use source workspace privileges too.
- No raw notebook/source text in standard list responses; definition preview is separate privileged endpoint with redaction and response-size limits.
- Handle inaccessible folders, stale index, partial API pagination, asset renamed/deleted, unsupported resource family and dependency cycles.
- Audit discovery requests, privileged definition views, manifest exports and selections that create project/package changes.
- Metrics: discovery duration, assets indexed/type, API errors/rate limiting, stale inventory count, unresolved dependencies.

## 9. Acceptance tests

- Discover at least notebooks, Jobs and pipelines with correct IDs and metadata; unsupported families are clearly marked.
- Source inventory remains read-only; no secret values or tokens in UI, logs, exports or AI prompts.
- Dependency graph handles missing/cyclic/dynamic references and distinguishes confidence.
- Pagination, refresh progress and partial failures work without falsely marking inaccessible assets deleted.
- Manifest fingerprints are stable and reproducible; unauthorized tenant/workspace data is inaccessible.
- Creating a project from selection preserves selected assets and reviewed dependency closure.
