# WORKSPACE-03 — Compare & Sync | Full Implementation Specification

**Navigation:** Workspaces → Compare & Sync

## Coding-agent implementation contract

- **Product:** JadeOrbit DeployPactAI; **module:** Workspaces; **scope:** full production feature, not MVP.
- Inspect `PROJECT_REQUIREMENTS.md`, `PROJECT_ARCHITECTURE.md`, existing Administration specifications, routes, database models, migrations, identity middleware and Databricks adapters **before modifying code**. Extend existing conventions; do not create parallel authentication, database, or SDK frameworks.
- Existing application is operational and connected to a Databricks workspace. Preserve it. Implement additive Alembic migrations, feature flags where appropriate, and backward-compatible behavior.
- Stack: React + TypeScript frontend; Python FastAPI backend; Databricks SDK/REST APIs; Lakebase PostgreSQL metadata; Databricks Jobs for durable work; Unity Catalog Volumes/object storage for large artifacts; GitHub Actions and Terraform integrations when relevant.
- All operations are **tenant-scoped**, permission-checked on the server, audited, observable and idempotent. Never rely on disabled UI buttons as authorization.
- Do not store OAuth tokens, PATs, private keys or secret values in Lakebase; store secret references in an approved secret manager. Never expose tokens or sensitive response payloads to browser/logs.
- DDL below is **reference DDL**; reconcile names and relationships with existing schema and create migrations rather than blindly executing it. Assume `tenants(id)`, `app_users(id)` and `workspaces(id)` may already exist; verify before migration.
- Do not implement cross-account capabilities by assuming common Unity Catalog metastores, common identities, or automatic target access. Check capabilities and privileges for each target independently.
- Prefer deterministic rules and Databricks-native APIs; any AI suggestions must be optional, explainable and never authorize or execute a change.
- Deliver frontend pages, backend services, typed contracts, database migrations, automated tests, user-visible errors, loading/empty states, documentation and operational metrics. Avoid placeholder-only functionality.

## 1. Objective

Compare two authorized Databricks workspaces (or immutable asset snapshots), identify configuration differences and drift, and **safely synchronize selected resources** using the same planner, mapping, approval and deployment engine as Direct Deployment. Support both ad-hoc comparison and saved **Workspace Synchronization** projects with optional schedules. This is **not** a bidirectional database replication tool or automatic data-copy facility.

## 2. Page sections

- **Compare setup:** source workspace, destination workspace, optional project/snapshot, asset families, scope (folder/catalog/schema/project), mapping profile, snapshot timestamp, compare mode (definitions, existence, configuration, permissions where authorized).
- **Comparison summary:** counts: identical, missing on target, changed, target-only, mapping-required, conflicts, unsupported, inaccessible, unknown.
- **Differences explorer:** grouped list/tree with resource type, logical key, source/target fingerprints, severity, ownership, dependency status, selected action; safe side-by-side JSON/definition diff with redaction.
- **Sync selection:** choose individual assets/dependencies and direction **source → target**; create/update/skip/adopt/blocked actions, preview mapping transformations, exclusion notes.
- **Plan & approval:** immutable comparison snapshot, policy evaluation, risk classification, target-specific plan, impact report, approval chain, expiration/revalidation status.
- **Execution & monitoring:** launch approved sync; step status, retries, partial success, verify, rollback eligibility and linked deployment history.
- **Saved sync jobs:** schedule (if enabled), change-only runs, pause/resume, last outcome, next planned run, drift alerts and owner notifications.

## 3. Comparison semantics and correctness

1. Normalize resources by type-specific canonical representation, excluding volatile fields (timestamps, generated IDs, status counters) while preserving meaningful behavior.
2. Compare mapped logical identities, not raw workspace-specific IDs. Resolve via `resource_bindings` first; explicit adoption is required for unmanaged target resources.
3. Classify `IN_SYNC`, `SOURCE_ONLY`, `TARGET_ONLY`, `DIFFERENT`, `CONFLICT`, `MAPPING_REQUIRED`, `UNSUPPORTED`, `INACCESSIBLE`, `UNKNOWN`. Show why each classification was assigned.
4. Do not assume Unity Catalog objects in same metastore are independent. Warn/block unsafe attempts to copy shared UC resources into the same namespace.
5. Never compare or synchronize secret values. Secret scope metadata can be compared where supported; target secret provisioning is separate.
6. Underlying table data, model training datasets, external object storage contents and live compute state are out of scope unless a separate explicitly supported migration feature is designed.
7. Source is read-only. Target changes require a fresh plan, server policy, approvals and authorized identity. Never silently enable reverse sync.
8. Compare can be run without deploying; reports can be exported with redaction and retention controls.
9. For large inventories, compare asynchronously in durable jobs; store progress, snapshots and resumable cursor/checkpoints.
10. If source/target change after comparison, mark plan stale. Recompute or require explicit reapproval based on plan digest and policy.
11. Target-only assets are **not deleted by default**. Deletion, if ever supported, is an explicitly separate high-risk action with protected-resource rules and multi-party approval; do not implement silent pruning.
12. Permissions/grants comparison must respect identity mappings and Databricks privilege scope. Do not infer effective access solely from a raw ACL list.
13. Drift detection is scoped to resources owned or explicitly monitored by a project. Git-owned and Terraform-owned resources must not be modified through SDK sync unless ownership is transferred with explicit approval.

## 4. Sync planning and execution

Flow: select pair/scope → capture inventory snapshots → resolve mapping profile → normalize/fingerprint → compute diff → resolve dependency graph → propose per-resource actions → evaluate policies → review/approve immutable plan → enqueue execution → verify actual target → store bindings/history/evidence.

- Supported operations: create, update managed, skip, explicit adopt, block; retries for transient errors, idempotency keys, per-target locks, checkpoints and compensation where supported.
- Resource ordering follows dependency graph. Use type-specific adapters; support partial success with exact step outcomes, not one misleading global success.
- Manual sync and scheduled sync use identical policy enforcement. Scheduled changes that require approval remain pending, never auto-bypass.
- For rollback, use recorded pre-change snapshots and adapter capabilities; label resources with irreversible changes as non-rollbackable. Terraform/Git-owned resources defer to their native pipelines and source of truth.
- Synchronization can be one-to-many by creating multiple **independent target comparisons/plans**, never a single shared mutable plan across targets.

## 5. User permissions and policy

Permissions: `compare.run`, `compare.view`, `sync.plan`, `sync.execute`, `sync.schedule`, `sync.manage`, `sync.adopt`, `sync.export`. Require source read, destination write and project-level authorization. Enforce production approvals, maintenance windows, blocked asset types, concurrency limits and risk thresholds through Administration policies.

## 6. Backend components

`comparison_orchestrator`, `snapshot_store`, `canonicalization_registry`, `resource_binding_resolver`, `drift_detector`, `sync_planner`, `policy_engine`, `approval_service`, `deployment_executor`, `verification_service`, `sync_scheduler`.

Reuse existing deployment plan/run/step models; avoid second execution engine. Comparison and sync jobs are durable, observable and recoverable.

## 7. Reference Lakebase PostgreSQL DDL

```sql
CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE TABLE IF NOT EXISTS workspace_comparisons (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES tenants(id),
  source_workspace_id uuid NOT NULL REFERENCES workspaces(id),
  target_workspace_id uuid NOT NULL REFERENCES workspaces(id),
  mapping_profile_id uuid,
  requested_by uuid REFERENCES app_users(id),
  scope_filter jsonb NOT NULL DEFAULT '{}'::jsonb,
  source_snapshot_ref text, target_snapshot_ref text,
  status text NOT NULL CHECK(status IN ('QUEUED','RUNNING','SUCCEEDED','PARTIAL','FAILED','CANCELLED')),
  summary jsonb NOT NULL DEFAULT '{}'::jsonb,
  snapshot_digest char(64),
  started_at timestamptz, completed_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  CHECK(source_workspace_id <> target_workspace_id),
  UNIQUE(id,tenant_id)
);
CREATE INDEX IF NOT EXISTS ix_workspace_comparisons_recent
  ON workspace_comparisons(tenant_id,created_at DESC);
CREATE TABLE IF NOT EXISTS workspace_comparison_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES tenants(id),
  comparison_id uuid NOT NULL,
  asset_type text NOT NULL,
  logical_key text NOT NULL,
  source_asset_id uuid, target_asset_id uuid,
  source_fingerprint char(64), target_fingerprint char(64),
  classification text NOT NULL CHECK(classification IN
    ('IN_SYNC','SOURCE_ONLY','TARGET_ONLY','DIFFERENT','CONFLICT',
     'MAPPING_REQUIRED','UNSUPPORTED','INACCESSIBLE','UNKNOWN')),
  diff_summary jsonb NOT NULL DEFAULT '{}'::jsonb,
  recommended_action text NOT NULL DEFAULT 'REVIEW',
  FOREIGN KEY(comparison_id,tenant_id) REFERENCES workspace_comparisons(id,tenant_id),
  UNIQUE(comparison_id,asset_type,logical_key)
);
CREATE TABLE IF NOT EXISTS workspace_sync_schedules (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES tenants(id),
  project_id uuid NOT NULL, -- reference existing projects with tenant-consistent FK
  source_workspace_id uuid NOT NULL REFERENCES workspaces(id),
  target_workspace_id uuid NOT NULL REFERENCES workspaces(id),
  schedule_expression text NOT NULL,
  timezone_name text NOT NULL DEFAULT 'UTC',
  enabled boolean NOT NULL DEFAULT false,
  auto_execute_low_risk boolean NOT NULL DEFAULT false,
  last_run_at timestamptz, next_run_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(id,tenant_id),
  CHECK(source_workspace_id <> target_workspace_id)
);
CREATE TABLE IF NOT EXISTS workspace_sync_run_links (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES tenants(id),
  comparison_id uuid NOT NULL,
  deployment_plan_id uuid NOT NULL, -- FK to existing deployment_plans
  deployment_run_id uuid,           -- FK to existing deployment_runs
  created_at timestamptz NOT NULL DEFAULT now(),
  FOREIGN KEY(comparison_id,tenant_id) REFERENCES workspace_comparisons(id,tenant_id)
);
```

**Migration hardening:** add composite tenant-consistent FKs to projects, mapping profiles, plan and run records using existing schemas; ensure source and target workspaces belong to the same authorized application tenant even when Databricks accounts differ. Use immutable plan snapshots and digest constraints in the existing planner.

## 8. UI states, errors and evidence

- Explicit stale snapshots, unsupported resources, permission errors, unresolved mappings, conflicts, cross-metastore warnings, concurrent edit, plan expired, approval pending and partial success.
- Export comparison report (JSON/CSV if allowed) with source/target identifiers, hashes, actions, policy decisions and timestamps, excluding secrets and sensitive source contents.
- Audits: compare initiated, sync plan generated, mapping changed, adoption requested, approval granted/denied, sync started/failed/succeeded, rollback attempted, schedule modified.
- Metrics: compare duration, drift counts, false conflicts, plan staleness, successful sync rate, partial failures, blocked changes.

## 9. Acceptance tests

- Identical resources compare equal after normalization of volatile fields; real configuration change is detected.
- Source-only, target-only, unmanaged conflict and unsupported cases classify correctly.
- Plan becomes stale if target changes; cannot execute without revalidation and required approval.
- Production sync obeys policy; scheduled sync cannot bypass approval.
- No default target deletion; no secret value transfer; no table data migration claim.
- Existing Git/Terraform-owned resource is protected from direct sync.
- Partial execution produces per-step results, retry safety and truthful rollback eligibility.
