# WORKSPACE-04 — Environment Mapping | Full Implementation Specification

**Navigation:** Workspaces → Environment Mappings

## Coding-agent implementation contract

- **Product:** JadeOrbit DeployPactAI; **module:** Workspaces; **scope:** full production feature, not MVP.
- Inspect `PROJECT_REQUIREMENTS.md`, `PROJECT_ARCHITECTURE.md`, existing Administration specifications, routes, database models, migrations, identity middleware and Databricks adapters **before modifying code**. Extend existing conventions; do not create parallel authentication, database, or SDK frameworks.
- Existing application is operational and connected to a Databricks workspace. Preserve it. Implement additive Alembic migrations, feature flags where appropriate, and backward-compatible behavior.
- Stack: React + TypeScript frontend; Python FastAPI backend; Databricks SDK/REST APIs; Lakebase PostgreSQL metadata; Databricks Jobs for durable work; Unity Catalog Volumes/object storage for large artifacts; GitHub Actions and Terraform integrations when relevant.
- All operations are **tenant-scoped**, permission-checked on the server, audited, observable and idempotent. Never rely on disabled UI buttons as authorization.
- Do not store OAuth tokens, PATs, private keys or secret values in Lakebase; store secret references in an approved secret manager. Never expose tokens or sensitive response payloads to browser/logs.
- DDL below is **reference DDL**; reconcile names and relationships with existing schema and create migrations rather than blindly executing it. Assume `tenants(id)`, `app_users(id)` and `workspaces(id)` may already exist; verify before migration.
- Do not implement cross-account capabilities by assuming common Unity Catalog metastores, common identities, or automatic target access. Check capabilities and privileges for each target independently.
- Prefer deterministic rules and Databricks-native APIs; any AI suggestions must be optional, explainable and never authorize or execute a change.
- Deliver frontend pages, backend services, typed contracts, database migrations, automated tests, user-visible errors, loading/empty states, documentation and operational metrics. Avoid placeholder-only functionality.

## 1. Objective

Define, validate, version and reuse **target-specific resource mappings** that translate source Databricks asset references to destination workspace resources. Mappings are used by Direct Deployment, Git-Enabled Deployment, Release Promotion (including ML model promotion), Workspace Synchronization, and Terraform variable/input orchestration where appropriate. They must be deterministic, reviewable and safe.

## 2. Page layout and workflows

- **Profiles list:** name, owner, scope (tenant/project), source environment, target environment/workspace, status, revision, last validation, used-by projects, last modified; actions Create, Clone, Edit, Validate, Compare Versions, Archive.
- **Profile editor:** General; Catalog & Schema; Workspace Paths & Volumes; Compute & SQL; Jobs & Pipelines; Identities & Permissions; ML & Serving; Git/Terraform Variables; Validation & Preview; Version History.
- **Mapping rules table:** source type/key, target type/key, transformation mode, priority, required/optional, validation result, provenance (manual/discovered/suggested), description, last verified.
- **Bulk tools:** import/export sanitized JSON/YAML mapping definitions; duplicate from DEV→QA to DEV→PROD, review all changes before save; avoid importing secrets.
- **Preview:** choose source asset/package and destination, show before/after resource references, unresolved variables, expected target objects and affected dependent assets.
- **Validation results:** exists/accessible, missing, permission denied, incompatible, unsupported, ambiguous, stale, conflicts with resource ownership.

## 3. Mapping domains and rules

| Domain | Examples | Requirements |
|---|---|---|
| Unity Catalog | `dev_catalog.sales` → `prod_catalog.sales` | Check metastore identity, catalog/schema existence, grants, external locations and shared metastore caveats |
| Workspace paths | `/Shared/dev` → `/Shared/prod` | Normalize path, block traversal and unsafe overwrite, preserve relative hierarchy |
| UC Volumes/storage | `/Volumes/dev/...` → `/Volumes/prod/...` | Validate volumes and permissions; no automatic data copy |
| SQL warehouses | source warehouse ID → target warehouse ID | Resolve by explicit target ID; check access and capabilities |
| Compute and policies | job cluster/cluster policy refs | Validate target policy, runtime and cloud compatibility |
| Jobs/pipelines | notebook paths, pipeline IDs, schedules, task references | Dependency-aware rewrite, paused schedules by policy |
| Identities/grants | source service principal/group → target identity | Exact explicit mapping; never assume principal equality across accounts |
| Secrets | source secret scope/key **reference** → target reference | Never read, export or copy secret values |
| MLflow | model full name, version/alias, registry namespace | Promote selected version/artifacts via supported workflow; verify artifact availability and compatibility |
| Serving | endpoint name, model reference, scale/config | Target endpoint must satisfy quotas, permissions and model availability |
| Git/Bundle | bundle target variables and workspace host | Git-owned resources must remain Git-managed |
| Terraform | approved `tfvars`/workspace/provider input bindings | Map only approved inputs; do not rewrite existing Terraform state or silently import resources |

## 4. Functional rules

1. Profiles can be reusable templates, but a deployment plan always pins **one immutable profile revision per target**.
2. Allow explicit exact mappings first; optionally support safe deterministic prefix/path mappings with precedence and conflict detection. Avoid arbitrary Python/SQL expression execution in rules.
3. Validate mapping rule types, normalized source/target values, uniqueness, overlap, cycles, ambiguous matches and missing required references.
4. Target IDs are discovered/verified using target workspace SDK client; never trust arbitrary frontend-provided IDs as authorization.
5. Map identities separately from workspace connection credentials. Changing `run_as` identity or grants is a privileged operation requiring policy evaluation.
6. For cross-account environments, validate that principals, metastore resources, credentials, regions and storage paths may differ; require explicit mapping where needed.
7. Preview should be side-effect-free. Mapping validation reads target state but does not create resources.
8. Profiles used by running/approved plans are immutable at that revision. Editing creates new revision and invalidates pending plans when appropriate.
9. Default mapping fallback is **block unresolved required references**, not guess. Allow optional warnings only when adapter explicitly declares optionality.
10. AI may suggest candidate mappings using non-sensitive metadata and documented heuristics, with confidence/explanation; human must accept and deterministic validator must confirm. Never auto-map secret values or privileged identities.
11. For ML promotion, distinguish model version, model alias, target registered model and serving endpoint. Alias reassignment and endpoint update require separate approval/verification and rollback metadata.
12. For Terraform existing-pipeline mode, mapping produces approved pipeline input variables and environment references, not direct mutations of `.tf` files or state. For managed Terraform mode, inject approved variables into isolated runner and validate plan.
13. For shared UC metastores, block destructive or redundant mappings when source/target point to the same physical catalog/schema unless explicitly intended and permitted.
14. Prevent collision where two source resources resolve to one target identity unless explicit reviewed merge/adoption semantics exist.

## 5. Backend architecture and flow

`mapping_profile_service` → `mapping_rule_engine` → `target_resource_resolver` → `mapping_validator` → `preview_transformer` → `mapping_version_store` → audit.

- Deterministic ordered transforms; type-specific adapters for notebook paths, Job JSON, pipeline settings, UC refs, ML model refs, bundle variables and Terraform inputs.
- Validation status records source/target snapshot times and target identity, plus a digest of rules and resolved references.
- Deployment planner resolves profile revision, applies transformations to immutable asset manifest, records plan hash and blocks missing/unsafe mappings.
- Optional AI suggestion service cannot save or deploy; it returns proposals only.

## 6. Reference Lakebase PostgreSQL DDL

```sql
CREATE EXTENSION IF NOT EXISTS pgcrypto;
-- If mapping_profiles/mapping_rules exist, ALTER them rather than duplicating.
CREATE TABLE IF NOT EXISTS environment_mapping_profiles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES tenants(id),
  name text NOT NULL,
  description text,
  source_workspace_id uuid REFERENCES workspaces(id),
  target_workspace_id uuid NOT NULL REFERENCES workspaces(id),
  project_id uuid, -- optional FK to existing projects
  status text NOT NULL DEFAULT 'DRAFT'
    CHECK(status IN ('DRAFT','ACTIVE','ARCHIVED')),
  current_revision integer NOT NULL DEFAULT 1 CHECK(current_revision > 0),
  created_by uuid REFERENCES app_users(id),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(id,tenant_id), UNIQUE(tenant_id,name,target_workspace_id)
);
CREATE TABLE IF NOT EXISTS environment_mapping_revisions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES tenants(id),
  profile_id uuid NOT NULL,
  revision integer NOT NULL CHECK(revision > 0),
  rules_digest char(64) NOT NULL,
  notes text,
  created_by uuid REFERENCES app_users(id),
  created_at timestamptz NOT NULL DEFAULT now(),
  FOREIGN KEY(profile_id,tenant_id) REFERENCES environment_mapping_profiles(id,tenant_id),
  UNIQUE(profile_id,revision), UNIQUE(id,tenant_id)
);
CREATE TABLE IF NOT EXISTS environment_mapping_rules (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES tenants(id),
  revision_id uuid NOT NULL,
  domain text NOT NULL,
  source_selector text NOT NULL,
  target_value text NOT NULL,
  match_mode text NOT NULL DEFAULT 'EXACT' CHECK(match_mode IN ('EXACT','PREFIX')),
  priority integer NOT NULL DEFAULT 100,
  required boolean NOT NULL DEFAULT true,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  FOREIGN KEY(revision_id,tenant_id) REFERENCES environment_mapping_revisions(id,tenant_id),
  UNIQUE(revision_id,domain,source_selector,match_mode,priority)
);
CREATE INDEX IF NOT EXISTS ix_environment_mapping_rules
  ON environment_mapping_rules(tenant_id,revision_id,domain);
CREATE TABLE IF NOT EXISTS environment_mapping_validations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES tenants(id),
  revision_id uuid NOT NULL,
  target_workspace_id uuid NOT NULL REFERENCES workspaces(id),
  status text NOT NULL CHECK(status IN ('QUEUED','RUNNING','PASSED','WARNINGS','FAILED')),
  findings jsonb NOT NULL DEFAULT '[]'::jsonb,
  target_snapshot_digest char(64),
  validated_by uuid REFERENCES app_users(id),
  validated_at timestamptz,
  FOREIGN KEY(revision_id,tenant_id) REFERENCES environment_mapping_revisions(id,tenant_id)
);
```

**Migration hardening:** reconcile with `mapping_profiles`/`mapping_rules` already used by projects; add tenant-consistent composite FKs to workspace/project references; version rules atomically in one transaction; prevent edits to published revision.

## 7. Security, audit and failure handling

- Permissions: `mapping.view`, `mapping.create`, `mapping.edit`, `mapping.validate`, `mapping.publish`, `mapping.archive`, `mapping.manage_identity_rules`.
- Protect target credentials and secret references; redact sensitive values; audit privileged identity mapping changes and profile publishing.
- Show unresolved target, permission denied, incompatible type, ambiguous prefix, duplicate target collision, stale validation, shared-metastore conflict and target ownership conflict.
- Map preview and exported mapping files must be sanitized and size-limited. Validate imported YAML/JSON against strict schema; no executable templates.
- Metrics: validation duration, unresolved rules, collisions, stale profiles, failed deploy plans due to mappings.

## 8. Acceptance tests

- DEV→QA and DEV→PROD have distinct mappings and immutable revisions.
- Cross-account identity mapping requires explicit target principal; secret values never appear.
- Two source assets mapping to same target is blocked without explicit conflict handling.
- Invalid target warehouse/catalog/path blocks plan; preview never mutates target.
- Existing approved plan remains pinned to original revision; new edit creates a new revision.
- ML model and serving references map separately; Terraform pipeline variables are constrained to allowlist.
- Role restrictions and tenant isolation enforced in backend and UI.
