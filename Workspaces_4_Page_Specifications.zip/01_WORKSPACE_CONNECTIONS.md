# WORKSPACE-01 — Workspace Connections | Full Implementation Specification

**Navigation:** Workspaces → Workspace Connections

## Coding-agent implementation contract

- **Product:** JadeOrbit DeployPactAI; **module:** Workspaces; **scope:** full production feature, not MVP.
- Inspect `PROJECT_REQUIREMENTS.md`, `PROJECT_ARCHITECTURE.md`, existing Administration specifications, routes, database models, migrations, identity middleware and Databricks adapters **before modifying code**. Extend existing conventions; do not create parallel authentication, database, or SDK frameworks.
- Existing application is operational and connected to a Databricks workspace. Preserve it. Implement additive Alembic migrations, feature flags where appropriate, and backward-compatible behavior.
- Stack: React + TypeScript frontend; Python FastAPI backend; Databricks SDK/REST APIs; Lakebase PostgreSQL metadata; Databricks Jobs for durable work; Unity Catalog Volumes/object storage for large artifacts; GitHub Actions and Terraform integrations when relevant.
- All operations are **tenant-scoped**, permission-checked on the server, audited, observable and idempotent. Never rely on disabled UI buttons as authorization.
- Do not store OAuth tokens, PATs, private keys or secret values in Lakebase; store secret references in an approved secret manager. Never expose tokens or sensitive response payloads to browser/logs.
- DDL below is **reference DDL**; reconcile names and relationships with existing schema and create migrations rather than blindly executing it. Assume `tenants(id)`, `app_users(id)` and `workspaces(id)` may already exist; verify before migration.
- Do not implement cross-account capabilities by assuming common Unity Catalog metastores, common identities, or automatic target access. Check capabilities and privileges for each target independently.
- Prefer deterministic rules and Databricks-native APIs; any AI suggestions must be optional, explainable and never authorize or execute a change.
- Deliver frontend pages, backend services, typed contracts, database migrations, automated tests, user-visible errors, loading/empty states, documentation and operational metrics. Avoid placeholder-only functionality.

## 1. Objective and scope

Build the authoritative, reusable registry of Databricks workspace connections used by **Direct Deployment, Git-Enabled Deployment, Release Promotion, Workspace Synchronization, Terraform orchestration and ML promotion**. Support multiple workspaces within the same Databricks account and across different accounts/clouds when network reachability, credentials and feature compatibility permit. A registered connection is not a deployment permission grant.

## 2. Page layout and navigation

- **Connections:** searchable, sortable table/cards; workspace alias, URL/host, cloud, account reference, region, environment label (DEV/QA/UAT/PROD/custom), tenant, connection owner, authentication mode, connectivity/authorization health, last discovery, last check, capability status, last deployment; actions Add, Edit, Test, Discover, Disable, Archive, View.
- **Connection detail:** Overview; Authentication & Identity; Capabilities & Permissions; Network Diagnostics; Usage/Dependencies; Activity/Health.
- **Create/Edit wizard:** identity and host → authentication selection → permissions/connectivity test → capability inventory → environment classification and allowed usage → review/save. Allow Save Draft with incomplete verification, but block usage until healthy and authorized.
- **Bulk operations:** test selected connections, refresh capabilities, export sanitized registry metadata; do not bulk-delete active connections.
- **Contextual navigation:** View Assets opens Asset Explorer scoped to workspace; Compare opens Compare & Sync with workspace preselected; View Mappings opens Environment Mapping; dependent projects and pipelines link to their records.

## 3. Functional requirements

1. Register Databricks workspace by canonical HTTPS workspace host, friendly alias, cloud, region, optional account ID and environment classification. Normalize URL; reject embedded credentials, fragments, localhost, loopback, link-local, metadata service, private IPs and unapproved domains unless explicit platform-admin allowlisting and safe egress policy exist. Prevent SSRF and unsafe redirects.
2. Support application/service-principal OAuth M2M as the recommended automation mode; support OIDC/workload identity federation where available and properly configured. Support user-delegated OAuth for interactive read/discovery where supported; do **not** silently reuse user identity for unattended deployment. PATs only if explicitly permitted by organizational policy, with expiry and secure secret reference.
3. Credential profile is distinct from workspace registry. Record auth mode, principal identity, secret locator, allowed operations, expiry/rotation metadata and verification status. Never return secret contents to UI.
4. Source vs target permissions are independent: inventory/read access on source; create/update/configure and any `run_as`/UC grants on target. Show granular missing permission diagnostics and per-resource capability availability, not one misleading “connected” boolean.
5. Test DNS/TLS/reachability, workspace identity, auth, API access, Unity Catalog presence/metastore (if visible), relevant SQL warehouse/job/pipeline/ML capabilities, feature flags and cross-account restrictions. Mark unsupported/unverified features rather than assuming universal availability.
6. Support one workspace registered once per tenant with aliases; enforce uniqueness by normalized workspace host + tenant. Explicitly handle same host linked to distinct tenants only if tenant isolation permits it.
7. Run health checks on demand and scheduled; throttle calls, handle Databricks rate limits, token expiration, permission revocation, network failures, regional outages and partial API availability.
8. Preserve connection history and capability snapshots. Disable or archive rather than delete if referenced by projects, mapping profiles, active deployments, approval evidence, release manifests or audits.
9. Environment classification is metadata; `PROD` classification triggers server-side policy, approvals and least-privilege safeguards. Changes to classification are privileged and audited.
10. Support outbound networking constraints of Databricks Apps. If a destination is unreachable, report that a trusted execution agent/runner may be required; do not pretend direct connectivity.
11. Distinguish app's hosting workspace from registered source/target workspaces. Allow hosting workspace as source or target only when policy and identity permit.
12. Discover supported asset families: workspace notebooks/files, Jobs, Lakeflow pipelines, SQL objects/dashboards, compute policies/warehouses, Unity Catalog metadata/grants, MLflow registered models/versions/aliases, serving endpoints, Databricks Apps, secret scope metadata; feature availability varies by API/cloud. Secret values, underlying data and credentials are not implicitly exportable.

## 4. Business rules and permissions

- Roles: platform admin manages trust/credentials; workspace admin manages authorized connections; viewer reads sanitized metadata; deployment operator can use only explicitly assigned connections.
- Per-workspace actions: `workspace.view`, `workspace.register`, `workspace.edit`, `workspace.test`, `workspace.disable`, `workspace.use_as_source`, `workspace.use_as_target`, `workspace.manage_credentials`.
- Disallow selecting disabled/unverified connections for new deployment plans. A passed health check does not bypass project-specific authorization.
- Editing a host or credential requires re-verification and invalidation of dependent cached capabilities; active deployment uses immutable connection snapshot and controlled credential resolution.
- Prevent deletion of the last usable admin connection if this would orphan platform administration, subject to current tenancy model.

## 5. Backend architecture and flow

`workspace_registry_service` → `credential_broker` → `databricks_client_factory` → `workspace_capability_probe` → `connection_health_worker` → `workspace_usage_index` → audit.

- Client factory creates isolated Databricks SDK clients for each workspace; never mutate a shared global SDK host/token.
- Credential broker resolves secret references only server-side, caches short-lived tokens securely and rotates/revokes as needed.
- Long-running probes are queued durably; UI polls or subscribes to progress. Store structured diagnostics with safe redaction.
- Maintain capability/version snapshots with probe timestamp and evidence; recheck immediately before an operation that depends on them.
- Keep environment/account classification separate from capability detection and permission validation.

## 6. Reference Lakebase PostgreSQL DDL

```sql
CREATE EXTENSION IF NOT EXISTS pgcrypto;
-- Existing workspaces table: ADD missing columns through Alembic, do not recreate.
CREATE TABLE IF NOT EXISTS workspace_credential_profiles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES tenants(id),
  name text NOT NULL,
  auth_mode text NOT NULL CHECK (auth_mode IN ('OAUTH_M2M','WORKLOAD_IDENTITY','OAUTH_USER','PAT')),
  principal_external_id text,
  secret_ref text,
  allowed_usage jsonb NOT NULL DEFAULT '[]'::jsonb,
  status text NOT NULL DEFAULT 'PENDING' CHECK (status IN ('PENDING','ACTIVE','EXPIRED','REVOKED','ERROR')),
  verified_at timestamptz, expires_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (id, tenant_id), UNIQUE (tenant_id, name)
);
CREATE TABLE IF NOT EXISTS workspace_connection_details (
  workspace_id uuid PRIMARY KEY,
  tenant_id uuid NOT NULL REFERENCES tenants(id),
  normalized_host text NOT NULL,
  display_name text NOT NULL,
  cloud text CHECK (cloud IN ('AWS','AZURE','GCP','UNKNOWN')),
  region text, account_external_id text,
  environment_class text NOT NULL DEFAULT 'OTHER'
    CHECK (environment_class IN ('DEV','QA','UAT','STAGING','PROD','OTHER')),
  credential_profile_id uuid,
  connection_status text NOT NULL DEFAULT 'DRAFT'
    CHECK (connection_status IN ('DRAFT','VERIFIED','DEGRADED','DISABLED','ARCHIVED')),
  last_checked_at timestamptz, last_success_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  FOREIGN KEY (workspace_id) REFERENCES workspaces(id),
  FOREIGN KEY (credential_profile_id,tenant_id)
    REFERENCES workspace_credential_profiles(id,tenant_id),
  UNIQUE (tenant_id,normalized_host), UNIQUE (workspace_id,tenant_id)
);
CREATE TABLE IF NOT EXISTS workspace_capability_snapshots (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES tenants(id),
  workspace_id uuid NOT NULL,
  capabilities jsonb NOT NULL DEFAULT '{}'::jsonb,
  permissions jsonb NOT NULL DEFAULT '{}'::jsonb,
  probe_version text NOT NULL,
  status text NOT NULL CHECK (status IN ('SUCCESS','PARTIAL','FAILED')),
  checked_at timestamptz NOT NULL DEFAULT now(),
  error_summary text,
  FOREIGN KEY (workspace_id,tenant_id)
    REFERENCES workspace_connection_details(workspace_id,tenant_id)
);
CREATE INDEX IF NOT EXISTS ix_workspace_capability_latest
  ON workspace_capability_snapshots(tenant_id,workspace_id,checked_at DESC);
CREATE TABLE IF NOT EXISTS workspace_health_checks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES tenants(id),
  workspace_id uuid NOT NULL,
  status text NOT NULL CHECK (status IN ('QUEUED','RUNNING','PASSED','PARTIAL','FAILED')),
  diagnostics jsonb NOT NULL DEFAULT '{}'::jsonb,
  started_at timestamptz, finished_at timestamptz,
  FOREIGN KEY (workspace_id,tenant_id)
    REFERENCES workspace_connection_details(workspace_id,tenant_id)
);
```

**Migration hardening:** confirm `workspaces` has tenant-consistent FK/unique key; ensure workspace detail tenant matches parent using composite FK or trigger; add partial indexes for active records and retention of health history.

## 7. Interfaces and events (conceptual, not prescriptive URLs)

Commands: register, update, verify, test, disable/archive, rotate credential reference, refresh capabilities. Queries: list, detail, capabilities, permission diagnostics, usage impact, health history. Events: `workspace.registered`, `workspace.verified`, `workspace.credentials_expired`, `workspace.disabled`, `workspace.capabilities_changed`.

## 8. UX, failure handling and audit

- Show actionable status: reachable/authenticated/authorized/capable separately; explain failures without leaking secrets.
- Confirmation for disable/credential replacement with affected projects listed.
- Accessible responsive grid, pagination, server-side search/filter, no browser-stored credentials, retry buttons and meaningful empty states.
- Audit before/after sanitized changes, actor, tenant, target workspace, result and correlation ID. Credential changes log reference metadata only.

## 9. Acceptance tests

- Register and verify source in Account A, target in Account A and target in Account B with independent identities.
- Expired/revoked credential prevents deployment, shows clear diagnostic and does not expose token.
- Duplicate host rejected per tenant; SSRF host blocked; one tenant cannot access another tenant's connection.
- Read-only source identity cannot be used as write-capable target.
- Disabling workspace blocks new plans while preserving historical runs.
- Capability probe accurately reports unsupported APIs/partial permissions.
- UI loads health and dependency impact; all changes generate audit events.
