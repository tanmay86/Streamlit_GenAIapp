# JadeOrbit DeployPactAI — Product Requirements

> **Status:** Full-product baseline · **Version:** 1.0 · **Updated:** 2026-11-23  
> **Audience:** Coding agents, product owners, architects, engineers, QA, and security reviewers.  
> **Companion:** [`PROJECT_ARCHITECTURE.md`](PROJECT_ARCHITECTURE.md).  
> **Product naming:** The application is **JadeOrbit DeployPactAI**. A historical document header used “JadeOrbit : GovPactAI”; that is a different product name and **must not** be used as this application's brand without an explicit future decision.

## 1. Purpose and product vision

JadeOrbit DeployPactAI is an enterprise, browser-based, **no-code/low-code Databricks deployment and release orchestration control plane**. It discovers Databricks assets, resolves dependencies, maps environment-specific configuration, previews changes, and orchestrates safe, auditable deployment between one or many Databricks workspaces, including cross-account scenarios. It integrates with GitHub and Databricks Asset/Declarative Automation Bundles, supports staged release promotion (including ML models), detects workspace drift, reuses existing Terraform infrastructure and pipelines, and provides resource-aware rollback and recovery.

The application is centrally hosted in a designated Databricks workspace (Workspace A) as a Databricks App; authorized destination workspaces may be in the same or other Databricks accounts. Installation in every destination workspace is **not** required unless network/security constraints mandate a destination-side runner. DeployPactAI is an orchestration platform, not a replacement for Databricks, Terraform, GitHub, or a full data-migration service.

**Scope commitment:** Build the complete product described here; do not silently remove capabilities under an “MVP” interpretation. Delivery can be phased by dependencies, but every requirement remains in the target backlog and must have an implementation and test status.

## 2. Goals, outcomes and users

**Goals:** Reduce manual and inconsistent deployments; centralize workspace connectivity and asset inventory; standardize repeatable releases; improve visibility, governance, approvals and auditability; support both direct API-driven and GitOps workflows; reuse existing customer Terraform investments; provide safe recovery; reduce operational effort through *bounded* AI assistance.

**Primary personas:**
- **Platform Administrator:** workspace onboarding, identity, RBAC, security policies, integration and runner setup.
- **Databricks Engineer / Data Engineer:** asset discovery, package assembly, dependencies, environment mapping, direct deployments and sync.
- **DevOps / Release Engineer:** GitHub integration, bundle generation, pipelines, environment promotion, Terraform runs, rollback and release governance.
- **ML Engineer / MLOps Engineer:** registered model/version selection, evaluation gates, stage/environment promotion and serving deployment.
- **Solution / Data Architect:** cross-workspace patterns, mapping templates, risk assessment, change plans and compliance.
- **Approver / Change Manager:** review deployment plans, evidence, policy checks, release gates and approvals.
- **Auditor / Security Reviewer:** read-only access to change lineage, permissions, decisions, logs and evidence.

## 3. Exactly four project types

A user creates a **reusable project configuration**; creation does **not** automatically execute a deployment. Each execution produces a fresh, immutable plan, approval decisions, a run record and verification evidence. A project can be executed repeatedly.

### P1. Direct Deployment

Select one source workspace and one or more targets; browse and select Databricks assets; discover and confirm dependencies; configure target mappings; calculate a deterministic plan; resolve collisions/adoption; seek approval if required; deploy through Databricks SDK/REST or supported Databricks-native operations; verify and record per-target results. Support on-demand and scheduled runs where permitted. This mode requires no Git repository.

### P2. Git-Enabled Deployment

Connect an authorized GitHub organization/repository via GitHub App; import or export supported assets; generate/maintain Databricks bundle definitions and source-controlled deployment configuration; create branches/PRs; validate changes; trigger and monitor GitHub Actions; promote immutable commits/artifacts through approved environments; preserve Git as the source of truth for Git-owned assets. Support existing customer repository/workflow conventions as well as generated workflows. Do not overwrite user-maintained files without a reviewed change.

### P3. Release Promotion

Promote a defined release through configurable stages such as **Development → QA/Staging/UAT → Production**, using direct or Git-backed execution as appropriate. Provide release versioning, snapshots/manifests, approvals, quality gates, target-specific mappings, change windows, release notes, deployment verification and rollback. **ML model promotion is a capability inside this project type, not a fifth project type.** For ML, select a registered model and immutable version, evaluate required quality and policy checks, update environment-specific Unity Catalog model aliases or approved serving references, deploy/update serving endpoints as supported, perform smoke tests, record lineage and support controlled restoration of the prior model/serving configuration. Do not assume deprecated MLflow stages are available; model aliases and environment-specific controls are preferred.

### P4. Workspace Synchronization

Compare selected source and destination workspaces or snapshots; discover drift and differences; choose scope and direction; generate a preview with create/update/no-change/conflict/delete candidates; support one-time or policy-approved scheduled synchronization; apply only approved supported changes and verify results. **Deletion is opt-in, separately permissioned and never implicit.** Prevent sync loops, unintended overwrite and unmanaged-resource takeover.

**Project type invariant:** The frontend and domain model expose **exactly these four project types**. Terraform and ML are integrated capabilities/workflows, **not** additional project types.

## 4. Complete application navigation (horizontal top bar)

The product uses a responsive **horizontal navigation bar with six parent menus**. Page names below are baseline information architecture; individual page design and form fields will be defined iteratively. The top-right global area includes notifications, approval inbox shortcut, help/user guide, profile and current tenant/environment context.

| Parent menu | Submenu pages | Responsibilities |
|---|---|---|
| **Dashboard** | Overview; Deployment Activity; Deployment Analytics | KPIs, project/run status, failures, throughput, trends and attention items |
| **Projects** | All Projects; Create Project; Project Templates | List/filter/manage projects; choose among exactly four types; reusable templates; project detail pages |
| **Deployments** | Deploy Now; Deployment Plans; Deployment History; Rollback & Recovery | Plan/approve/execute, track per-target operations, inspect evidence, restore prior releases where supported |
| **CI/CD** | Pipelines; GitHub Repositories; Release & Promotions; Pipeline Runs | Git integration, workflow orchestration, immutable release promotions, CI/CD run history |
| **Workspaces** | Workspace Connections; Asset Explorer; Compare & Sync; Environment Mappings | Register/test workspaces, inventory, capability discovery, drift, mapping templates |
| **Administration** | Users & Roles; Approvals; GitHub Integrations; Deployment Policies; Audit Logs; Application Settings | Access, security, identity, integrations, Terraform runners/state settings, AI configuration and governance |

**Project detail secondary tabs:** Overview; Assets; Targets & Mappings; Deployment Plans; History; Settings. Project-specific tabs may include Release Stages, Git & Pipelines, Terraform, Sync Rules, or ML Models where applicable. **Terraform** must be discoverable via a dedicated section in project settings and via Administration integration/runner settings; optionally surface a contextual Terraform tab on projects using it. **ML promotion** appears inside Release & Promotions, not in Create Project as a fifth option. **Approval inbox** may be linked from the global notification area as well as Administration → Approvals.

Suggested route groups (nonbinding): `/dashboard/*`, `/projects/*`, `/deployments/*`, `/cicd/*`, `/workspaces/*`, `/admin/*`. Preserve stable, accessible, bookmarkable URLs.

## 5. End-to-end project and deployment lifecycle

1. Create/edit a draft with autosave and validation; select one of the four project types.
2. Choose registered, authorized source and target workspaces; verify connectivity and resource capabilities.
3. Discover and select supported assets, including individual assets and folder/group selection where supported.
4. Build a dependency graph; distinguish confirmed, inferred, external, unsupported and unresolved dependencies.
5. Configure per-target environment mapping, credentials, identity, resource ownership, conflicts and deployment strategy.
6. Save the reusable project, with a versioned configuration snapshot.
7. On **Deploy Now**, discover current state and generate a **fresh read-only plan** showing create/update/no-op/adopt/conflict/blocked/delete and potential impact.
8. Apply server-side policy checks, approvals, plan freshness checks, and execution controls; never deploy from a stale or tampered plan.
9. Execute via the selected adapter/runner; track steps, checkpoints, retries, target-specific status and logs.
10. Verify post-deployment state, record resource bindings and immutable evidence, publish results and notifications.
11. Support subsequent releases, drift comparison, diagnostics, approved rollback and partial-failure recovery.

## 6. Functional requirements catalog

### F01 — Workspace registry and connectivity

- Register and manage multiple workspaces, including same-account and cross-account targets, cloud-specific endpoints and environment labels.
- Test network reachability, authentication, effective permissions and supported API/resource capabilities; show precise failure reasons.
- Support service-principal/OAuth identities, controlled credential rotation and per-workspace credential profiles; never expose tokens in the browser.
- Allow restricted or optional destination-side runners where centralized connectivity is not possible.
- Protect against arbitrary workspace-host URLs and cross-tenant connection leakage.

### F02 — Asset discovery and inventory

- Browse/search/filter authorized source assets; show type, owner, location, identifiers, tags, last-modified and compatibility where available.
- Support notebooks/workspace files, Jobs/Workflows, Lakeflow pipelines, SQL queries, AI/BI dashboards, SQL warehouses, compute/cluster policies, relevant compute configurations, Unity Catalog securables/definitions/grants, volumes/external-location references where supported, MLflow/Unity Catalog registered models and versions, serving endpoints, and Databricks Apps when APIs/permissions support them.
- Provide a capability matrix by asset type/cloud/workspace/API and mark unsupported or manual-only operations honestly.
- Inventory secret **references/scopes** where permitted; never export or display secret values. Data-plane migration of table contents is out of scope unless explicitly added later.

### F03 — Dependency and impact analysis

- Model explicit dependencies (job tasks, notebook paths, pipeline references, compute, warehouse, catalog/schema, model/serving references) and best-effort inferred dependencies (code/SQL parsing).
- Display dependency graph, ordering, cycle detection, missing dependencies, external references and confidence/verification status.
- Let users include dependencies, exclude optional ones or mark externally managed resources; block unresolved required dependencies.
- Analyze affected downstream assets and target prerequisites before execution.

### F04 — Environment mapping and configuration transformation

- Support per-target mappings for catalog/schema, workspace paths, SQL warehouses, clusters/policies, pools, service principals/run-as identities, grants, secret references, storage paths, network endpoints, model aliases and serving endpoints.
- Offer reusable mapping profiles, variable substitution, dry-run validation and explicit review of suggested mappings.
- Do not silently rewrite arbitrary code or transfer production credentials.

### F05 — Deployment planning and conflict management

- Produce an immutable, deterministic, diff-oriented plan per target: create/update/no-op/adopt/conflict/blocked/delete (delete only for explicitly permitted sync/cleanup).
- Detect ownership conflicts between Direct SDK, Git/bundles and Terraform; require explicit resource adoption and binding.
- Show required permissions, missing prerequisites, unsupported resources, impact/risk, planned execution order and rollback readiness.
- Hash plans and associate with source versions, destination observations, mappings, policies and approvals; expire plans on meaningful changes.

### F06 — Direct execution and orchestration

- Deploy supported assets through typed adapters and Databricks SDK/REST; use bundle-based execution only when explicitly selected or necessary for supported declarative assets.
- Support create/update/skip/fail-on-conflict, idempotency, retries with backoff, bounded concurrency, resource locks, cancellation, checkpoints and durable restart recovery.
- Track independent target results; do not represent a partial multi-target success as an all-target success.
- Perform post-deploy verification and optional policy-approved smoke tests; avoid irreversible operations without explicit confirmation.

### F07 — GitHub and Databricks bundle integration

- GitHub App installation/authorization, repository and branch selection, webhooks, PR creation, status checks and commit-SHA provenance.
- Generate/update Databricks bundle layout, resource YAML, source files and environment configuration; support existing bundles and workflows.
- Validate generated artifacts, respect branch protections and require reviews; execute via GitHub Actions with federated identity where supported.
- Track GitHub workflow status, logs/links, artifacts, failure reasons and release-to-commit mapping.

### F08 — CI/CD pipelines and automation

- Configure pipeline templates and existing pipelines, validation/tests, gated deployment, scheduled/manual triggers, promotion order, environment secrets references and notifications.
- Preserve ownership: Git-owned resources are promoted from version-controlled artifacts, not edited behind Git's back.
- Record pipeline runs and reconcile external run status with internal deployment history.

### F09 — Release management and ML model promotion

- Create immutable release manifests with asset versions, source commit/artifact digest, target mapping version and deployment provenance.
- Support configurable Development → QA/Staging/UAT → Production stage gates, approvers, change windows, release notes and quality evidence.
- Support registered ML model version promotion, validation metrics/thresholds, model signatures/compatibility checks, approved alias updates and serving endpoint changes, smoke tests, model lineage and previous-version restoration.
- Distinguish **model registry aliases** from environment-specific workspace deployment; support both within the same Release Promotion project.

### F10 — Workspace compare, sync and drift

- Compare source/target current state and previous approved snapshots; show drift and resource-level differences.
- Allow selected scope, approved direction, schedule and synchronization policy; preview changes before each run.
- Respect source-of-truth and Terraform/Git ownership, avoid sync loops, and require elevated approval for destructive operations.

### F11 — Terraform reuse and orchestration

- **Terraform is a capability, not a fifth project type.** Connect an existing Terraform repository/module/configuration and associate it with a deployment project or release environment.
- Support **two execution modes**: (1) **Existing pipeline (preferred)**: trigger approved customer GitHub Actions or another explicitly supported CI/CD pipeline and monitor results; (2) **DeployPactAI-managed execution**: invoke `terraform init`, `validate`, `plan` and, after approval, `apply` using a secure isolated runner.
- Select existing module/root configuration, workspace/environment, variable sets, approved provider versions and backend references; preserve the existing remote state backend, state locking and ownership.
- Display sanitized plan summaries and drift/impact; require approval and policy checks before apply; track run logs, outputs and provenance with secrets redacted.
- Support Terraform import/adoption only via explicit operator workflow with review of resource addresses, existing state and risk. Do not automatically import arbitrary live resources or rewrite customer modules.
- Support infrastructure provisioning **before** dependent asset deployment where a release requires it, with explicit DAG ordering and failure handling.
- **Terraform owns Terraform-managed infrastructure**; Direct SDK/bundle operations must not mutate those resources unless an approved ownership handoff is completed. Never automatically execute `terraform destroy` or delete state.
- Terraform rollback is **not** a universal undo; use reviewed prior configuration plus new plan/apply, with stateful-resource caveats.

### F12 — Release rollback and recovery

- Maintain previous release manifests, immutable artifact references, deployment bindings and per-resource pre-change snapshots when feasible.
- Provide **Rollback Plan** preview: supported reverse operations, target scope, required approvals, prerequisites and non-reversible steps.
- Restore previous versions/configurations of supported notebooks, jobs, pipelines, bundles, model aliases/serving settings and other adapter-supported resources; verify results.
- Offer resume/retry/compensating actions for partial failures, and clearly flag manual recovery for data changes, external side effects, deleted resources and unsupported Terraform reversals.
- Do not claim atomic cross-workspace rollback or automatic data restoration.

### F13 — Approval, RBAC, governance and audit

- Role-based access by tenant, workspace, project, environment and action; enforce separation of duties and optional four-eyes approval.
- Policies for production, cross-account access, destructive changes, unmanaged adoption, Terraform apply, model promotion and rollback.
- Immutable audit trail of who requested/approved/executed/changed what, with timestamps, source version, plan hash and results.
- Integrate notifications and evidence export; auditors receive scoped read-only views.

### F14 — Monitoring, observability and operations

- Dashboard KPIs; per-project, per-run, per-target and per-resource statuses; live or polled progress, step logs and execution timelines.
- Failure categorization, retries, incident correlation, alerts, scheduled job health and history retention.
- Operational views for queue health, runners, stale plans, workspace connectivity, webhook failures, rate limits and credentials nearing expiry.

### F15 — AI-assisted features (feasible, bounded)

AI is **optional and advisory**, never a deployment authority. Implement with Databricks Model Serving/Foundation Model APIs or an approved enterprise LLM endpoint, structured outputs, access-scoped retrieval and human confirmation.

1. **Natural-language asset search and summaries:** Summarize discovered metadata and answer questions grounded in authorized inventory; do not promise exhaustive discovery from prompts alone.
2. **Dependency suggestions:** Suggest possible notebook/SQL/config references from retrieved source text; label confidence and require deterministic verification/user confirmation.
3. **Environment mapping recommendations:** Propose catalog/path/warehouse/identity mappings from approved examples and naming patterns; never apply automatically.
4. **Plan and change summaries:** Explain deterministic diffs, affected assets and missing prerequisites in plain language.
5. **Deployment risk indicators:** Explain rule-based risk factors (production target, destructive change, unresolved dependency, permissions, missing rollback); AI may summarize, not replace policy engine.
6. **Failure diagnosis and remediation suggestions:** Summarize sanitized logs, known error categories and runbooks; suggestions require operator review.
7. **Release notes and audit narrative:** Draft release notes from verified plan/run evidence; retain source links and require review.
8. **Terraform plan explanation:** Explain sanitized plan JSON/output and potential implications; never auto-approve or generate unsupervised `apply` commands.
9. **Model promotion evidence summaries:** Summarize evaluation metrics and gate results without inventing metrics or overriding thresholds.

**Explicit exclusions:** autonomous self-healing deployments, guaranteed AI-generated rollback, fully automatic discovery of hidden dependencies, AI-created privileged grants without review, autonomous production approval, unsupervised Terraform apply, or unsupported claims of predictive accuracy. AI must never receive plaintext credentials or unrestricted customer data. Disable AI gracefully when no approved model endpoint is configured.

### F16 — Templates, administration and usability

- Project templates and environment mapping templates; clone/archive projects, ownership transfer, versioned configuration changes.
- Responsive accessible horizontal navigation, search/filter/pagination, actionable empty/error states, progress feedback and documentation/help.
- Tenant configuration, RBAC, credential/integration setup, workspace capability settings, policy management, notification preferences, retention and feature configuration.
- Export project metadata and audit evidence in approved formats.

## 7. Supported asset boundaries and constraints

| Asset family | Expected handling | Critical caveat |
|---|---|---|
| Workspace notebooks/files | Export, transform references, import/update, verify | Notebook code dependencies may be inferred imperfectly |
| Jobs/Workflows | Definition, task graph, permissions/run-as mapping | Job run history is not migrated |
| Lakeflow pipelines | Definition/config mapping and deployment | Pipeline state/data is not copied automatically |
| SQL queries / AI/BI dashboards | Export/import via supported APIs | Some object types/features have API or cloud limitations |
| SQL warehouses / compute policies | Create/update where authorized | Quotas, pricing, policy restrictions and Terraform ownership |
| Unity Catalog definitions and grants | Controlled metadata/grant operations | Shared metastores, external storage, permissions; **not** table-data migration |
| MLflow/UC models and serving | Version selection, alias promotion, serving config | Artifact access, serving availability and environment compatibility |
| Databricks Apps | Deploy/update when supported | Source packaging and app-specific permissions |
| Secrets | Map secret references and prerequisites | Never copy/display secret values by default |
| Terraform-managed resources | Trigger customer pipeline or isolated Terraform runner | Existing remote state, ownership, locking and approvals mandatory |

Maintain an explicit adapter support matrix for cloud, resource type, API version, deployment mode, verification and rollback support. An unavailable API must be marked **unsupported/manual**, not simulated as a successful deployment.

## 8. Nonfunctional requirements

- **Security:** SSO/OIDC integration as supported, short-lived workload credentials, least privilege, secret redaction, encryption in transit/at rest, secure webhooks and strict tenant isolation.
- **Reliability:** durable queue/execution state, retryable idempotent steps, resumable failures, per-target isolation, timeouts and circuit breakers.
- **Consistency:** stable logical resource keys and target bindings; prevent duplicate resource creation on reruns.
- **Scalability:** bounded parallel discovery/execution, API rate-limit handling, paginated inventory and incremental sync.
- **Performance:** responsive UI for large inventories using async operations and caching; long-running operations never block request threads.
- **Observability:** correlated logs/traces/metrics, structured audit events and external run reconciliation.
- **Portability:** account/cloud/workspace capability checks; no assumptions of a shared metastore or identical identity names.
- **Maintainability:** adapter/plugin interfaces, typed contracts, schema migrations, testable policy engine and feature flags for capability rollout (not product-scope reduction).
- **Accessibility:** keyboard-friendly navigation, clear status labels and readable contrast; blue design theme, no reliance on color alone.
- **Data governance:** configurable retention, privacy-preserving AI prompts, evidence export and controlled deletion.

Numeric SLOs, capacity targets and retention periods are **TBD** and must be set before production readiness; do not fabricate performance guarantees.

## 9. Business rules and acceptance criteria

- Exactly four project types appear in Create Project; ML promotion and Terraform never appear as separate project types.
- A project draft can be saved without deployment; deployment requires a fresh, authorized plan and any mandatory approvals.
- Cross-account deployment works for authorized, reachable targets with appropriate identities and prerequisites.
- Repeat execution of an unchanged project does not create duplicate managed assets.
- Unmanaged resources, Git-owned assets and Terraform-owned assets cannot be silently overwritten.
- Each target records independent execution and verification status; partial success is explicit.
- Release Promotion supports immutable release lineage and Development → Staging → Production ML model promotion with gated checks.
- Rollback generates an approved, resource-aware reverse plan and reports non-reversible steps accurately.
- Terraform can **trigger an existing pipeline** and **execute through a managed runner**, both with plan/approval/monitoring and preserved remote state ownership.
- Sync defaults to non-destructive preview; destructive changes need explicit authorization.
- AI outputs are advisory, evidence-grounded and reviewable; deployment decisions remain deterministic and policy-controlled.
- Every privileged action is attributable and auditable; credentials and secret values never appear in logs or client payloads.
- Unsupported asset capabilities produce actionable blockers rather than silent omissions.

## 10. Delivery and agent implementation instructions

- Implement the **entire requirements catalog** as the target scope. Break into independently testable vertical slices, but maintain a complete requirements-to-code/test traceability matrix.
- Prioritize shared foundations (auth, workspace registry, inventory, bindings, plan engine, worker orchestration, policies) before project-specific flows; do not create four separate execution engines.
- Keep frontend and backend type-safe, modular and independently testable. Do not embed Databricks, GitHub or Terraform credentials in frontend code.
- Page-level UX, exact fields, final API contracts, DDL and provider-specific implementation details are **to be designed collaboratively later**. Do not invent them as immutable requirements.
- When an API/provider limitation makes a feature impossible in a specific environment, surface a capability flag and manual fallback; do not fabricate success or silently drop the feature.
- Every adapter must declare supported `discover`, `export`, `plan`, `deploy`, `verify`, `rollback` capabilities and ownership constraints.
- Add automated tests for tenant isolation, approvals, plan freshness, idempotency, cross-account credentials, Terraform state locking, Git ownership, model promotion and partial rollback.

## 11. Open decisions to resolve during implementation

- Exact supported Databricks clouds/accounts, workspace connectivity model and destination runner strategy.
- Enterprise identity provider, tenant boundaries and credential broker implementation.
- Preferred GitHub App installation model and support for CI/CD systems other than GitHub Actions.
- Terraform runner execution platform, approved providers/modules and existing remote state backends.
- Which resource adapters support full rollback versus restore/recreate/manual intervention.
- Model validation gates and serving rollout patterns; which evaluation metrics are mandatory.
- Target SLAs, inventory limits, job concurrency, retention and compliance requirements.
- AI endpoint choice, prompt/data policy, opt-in behavior and evaluation criteria.

**Source of truth:** This file defines the functional scope; [`PROJECT_ARCHITECTURE.md`](PROJECT_ARCHITECTURE.md) defines the technical design. Future detailed page specifications must remain consistent with both.
