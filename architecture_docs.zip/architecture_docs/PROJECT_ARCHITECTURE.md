# JadeOrbit DeployPactAI — Technical Architecture

> **Status:** Full-product reference architecture · **Version:** 1.0 · **Updated:** 2026-11-23  
> **Audience:** Coding agents, architects, backend/frontend engineers, platform and security engineers.  
> **Companion:** [`PROJECT_REQUIREMENTS.md`](PROJECT_REQUIREMENTS.md). This document is a target architecture; specific provider versions, infrastructure SKUs and API contracts must be verified during implementation.

## 1. Architecture objectives and invariants

Build one secure, centrally hosted, multi-workspace deployment control plane supporting exactly four project types: **Direct Deployment, Git-Enabled Deployment, Release Promotion and Workspace Synchronization**. Reuse a shared discovery/plan/policy/execution platform. **ML model promotion is part of Release Promotion. Terraform is an integrated infrastructure workflow, not a project type.** No automatic execution from project creation, AI suggestions or stale plans.

The default hosting model is a **Databricks App in Workspace A** serving a React UI and FastAPI backend. Deployments target Workspaces A/B/C or more, potentially across Databricks accounts. Destination-side runners are optional for isolated networks. Separate the interactive web application from durable, potentially long-running execution.

## 2. Architecture at a glance

```mermaid
flowchart TB
  U[Enterprise users / browser] --> IDP[Enterprise IdP / Databricks App authentication]
  U --> UI[React + TypeScript SPA]
  UI --> API[FastAPI control plane in Databricks Apps - Workspace A]
  API --> AUTH[Authorization + policy + approvals]
  API --> PROJ[Projects / mappings / releases]
  API --> DISC[Asset discovery + dependency adapters]
  API --> PLAN[Deterministic diff / plan engine]
  API --> AI[Optional AI assistant / approved model endpoint]
  API --> DB[(Lakebase PostgreSQL)]
  API --> ART[(UC Volumes / object artifact store)]
  API --> QUEUE[Durable work dispatch / run ledger]
  QUEUE --> RUN[Isolated deployment workers / Databricks Jobs]
  RUN --> DB
  RUN --> ART
  RUN --> SDK[Databricks SDK + REST adapters]
  RUN --> GIT[GitHub App + Actions + Bundles]
  RUN --> TF[Terraform pipeline or isolated runner]
  SDK --> W1[Workspace A]
  SDK --> W2[Workspace B - same account]
  SDK --> W3[Workspace C - cross account]
  GIT --> W2
  GIT --> W3
  TF --> W2
  TF --> W3
  IDP -. user identity .-> API
```

**Control plane:** UI, API, metadata, plans, approvals, policies and audit. **Execution plane:** durable workers, GitHub Actions, Terraform runner and Databricks workspace APIs. **Data plane:** customer Databricks assets and storage remain in their authorized environments. **AI plane:** optional read-scoped, advisory analysis; cannot bypass execution policies.

## 3. Technology stack

| Layer | Technology / pattern | Responsibility |
|---|---|---|
| Frontend | **React, TypeScript, Vite**, React Router | SPA, horizontal navigation, four project wizards, dashboards and run monitoring |
| Frontend data/forms | TanStack Query, React Hook Form, Zod (recommended) | Server-state caching, async requests, form validation, typed schemas |
| Frontend UI | Accessible component library (e.g., MUI or shadcn/ui; select one), charts/graph visualization (e.g., React Flow) | Blue-theme enterprise UI, dependency DAG, diff/plan tables and status |
| Backend | **Python 3.12+**, **FastAPI**, Pydantic v2, Uvicorn | Authenticated API, project lifecycle, validation, orchestration control |
| Databricks integration | **Databricks SDK for Python**, supported REST APIs, Databricks CLI/Bundles | Workspace access, asset adapters, declarative deployments |
| Database | **Databricks Lakebase PostgreSQL**, SQLAlchemy 2.x, Alembic | Durable transactional metadata, mappings, state, audit and bindings |
| Artifacts | **Unity Catalog Volumes** or approved object storage | Versioned manifests, sanitized plans, exports, deployment evidence |
| Long-running work | **Databricks Jobs** workers plus durable DB-backed dispatcher/run ledger; optional external queue if scale requires | Execution, retries, checkpointing, concurrency and recovery |
| GitOps | **GitHub App, GitHub REST API, GitHub Actions**, Databricks Bundles | Repo authorization, PRs, CI/CD, immutable artifact promotion |
| Terraform | Terraform CLI and Databricks provider, customer-approved modules, remote state backend | Reuse existing IaC; external pipeline or managed isolated execution |
| Authentication | Databricks Apps authentication + enterprise SSO/OIDC as supported; OAuth service principals/workload identity federation | User authentication and target workspace execution identities |
| Secrets | Databricks-supported secret facilities and/or enterprise secret manager | Server-side credentials and rotation, never frontend persistence |
| AI | Approved Databricks Model Serving/Foundation Model endpoint (or enterprise LLM), structured output and constrained retrieval | Optional summaries and recommendations only |
| Telemetry | Structured Python logging, OpenTelemetry where supported, run metrics and audit store | Correlation, alerts, diagnostics and compliance |
| Quality | pytest, mypy/ruff, Vitest, React Testing Library, Playwright, contract tests | Unit, integration, UI and security regression coverage |
| Delivery | GitHub Actions, environment-specific config, IaC, vulnerability scans | Build, test, package and deploy DeployPactAI itself |

**Selection notes:** Technology choices above are recommended baseline, not claims that every library is preinstalled or every Databricks feature is available in all clouds. Pin compatible versions after validation. Prefer managed services where they meet security and durability needs.

## 4. Repository and module layout

```text
jadeorbit-deploypactai/
├── PROJECT_REQUIREMENTS.md
├── PROJECT_ARCHITECTURE.md
├── README.md
├── frontend/
│   ├── src/app/                  # routing, app shell, auth context
│   ├── src/features/             # dashboard, projects, deployments, cicd, workspaces, admin
│   ├── src/components/           # shared UI, diff viewer, DAG viewer
│   ├── src/api/                  # typed API clients
│   └── tests/
├── backend/
│   ├── app/main.py
│   ├── app/api/                 # thin HTTP boundary (details defined later)
│   ├── app/core/                # settings, auth, tenant context, policies
│   ├── app/domain/              # projects, releases, plans, executions
│   ├── app/services/            # orchestration use cases
│   ├── app/adapters/databricks/  # typed asset adapters
│   ├── app/integrations/        # GitHub, Terraform, AI, notifications
│   ├── app/persistence/         # SQLAlchemy repositories, migrations
│   ├── app/workers/             # durable execution entry points
│   └── tests/
├── infrastructure/             # deployment packaging, approved IaC, runner configs
├── workflows/                  # GitHub Actions templates and checks
├── docs/                       # evolving page specs, ADRs, threat model, runbooks
└── scripts/                    # developer tooling and checks
```

**Code architecture:** feature-based frontend; layered/hexagonal backend. Keep provider-specific SDK code behind interfaces, business logic independent of HTTP handlers and persistence. Workers reuse domain services without importing UI/API runtime state.

## 5. Frontend architecture and navigation

A React SPA is served by the Databricks App (static build served by FastAPI or approved static hosting behind the same authenticated origin). Use responsive horizontal parent navigation:

- **Dashboard:** Overview; Deployment Activity; Deployment Analytics.
- **Projects:** All Projects; Create Project; Project Templates.
- **Deployments:** Deploy Now; Deployment Plans; Deployment History; Rollback & Recovery.
- **CI/CD:** Pipelines; GitHub Repositories; Release & Promotions; Pipeline Runs.
- **Workspaces:** Workspace Connections; Asset Explorer; Compare & Sync; Environment Mappings.
- **Administration:** Users & Roles; Approvals; GitHub Integrations; Deployment Policies; Audit Logs; Application Settings.

Project details use Overview, Assets, Targets & Mappings, Deployment Plans, History and Settings, with contextual Git/CI-CD, Terraform, Sync and ML sections. Show exactly four project-type cards in Create Project. Use client-side route guards **only for UX**; enforce all authorization in backend. Async data loading, pagination and cancellation are required for large inventories. No secrets or workspace access tokens in browser local storage.

## 6. Backend domain services

1. **Identity/Tenant/RBAC service:** authenticated principal, role assignments, project/workspace authorization and policy evaluation.
2. **Workspace Registry service:** connection metadata, account/cloud identification, capability checks and credential references.
3. **Asset Inventory service:** paginated discovery, snapshots, normalization and adapter capability registry.
4. **Dependency Graph service:** explicit/inferred edges, cycles, ordering, unresolved references and impact analysis.
5. **Mapping service:** reusable target profiles, transformations and validation.
6. **Project service:** drafts, templates, exactly four project types, versioned configurations and ownership.
7. **Planning service:** deterministic source/target diff, conflicts, ownership and immutable plan hashing.
8. **Approval/Policy service:** separation of duties, production gates, destructive changes, Terraform applies and rollback authorization.
9. **Execution service:** durable queue, per-target orchestration, locks, retries, step checkpoints and verification.
10. **GitOps service:** GitHub App, repositories, PRs, webhooks, bundles, workflow dispatch and status reconciliation.
11. **Release/ML Promotion service:** immutable releases, stage gates, UC model aliases, serving config and evaluation evidence.
12. **Sync/Drift service:** snapshots, comparisons, sync direction/schedules, non-destructive defaults.
13. **Terraform orchestration service:** module/repo references, variable mapping, pipeline dispatch or managed runner, state ownership and plan evidence.
14. **Rollback/Recovery service:** previous manifests, reverse plans, compensating actions and manual-recovery flags.
15. **AI advisory service:** authorized retrieval, redaction, prompt templates, structured results and confidence/evidence.
16. **Audit/Notification/Observability service:** immutable events, correlation IDs, alerts and dashboards.

Each service exposes application-level interfaces; actual HTTP endpoint paths are intentionally deferred until page-by-page design.

## 7. Databricks adapter model and asset support

Define an asset adapter protocol with `capabilities()`, `discover()`, `export()`, `dependencies()`, `transform()`, `plan()`, `deploy()`, `verify()` and optional `rollback()`. Operations declare prerequisites, ownership mode, cloud/workspace support, idempotency key and recovery strategy.

Adapters cover notebooks/workspace files, Jobs/Workflows, Lakeflow pipelines, SQL queries, AI/BI dashboards, SQL warehouses, compute/cluster policies, Unity Catalog metadata/grants, MLflow/UC models, serving endpoints and Databricks Apps **where supported**. Secrets are mapped by reference, not exported as values. The adapter matrix must distinguish deployable definitions from underlying datasets, storage objects, state and run history. Never claim to migrate table contents merely by recreating metadata.

## 8. Authentication and authorization architecture

```mermaid
sequenceDiagram
  participant B as Browser
  participant App as Databricks App / FastAPI
  participant Auth as Identity / policy layer
  participant Broker as Credential broker
  participant W as Target Databricks workspace
  B->>App: Authenticated UI/API request
  App->>Auth: Resolve user, tenant, roles, project permissions
  Auth-->>App: Allow / deny with policy context
  App->>Broker: Request scoped execution identity for approved run
  Broker-->>App: Server-side short-lived token / credential handle
  App->>W: Authorized SDK/API call from worker
  W-->>App: Resource status / error
  App-->>B: Sanitized status, no credential disclosure
```

**Interactive identity:** authenticate users through Databricks Apps and enterprise SSO/OIDC as supported; validate trusted headers/tokens at the server boundary, protect sessions, CSRF-sensitive flows and cross-origin access. Do not infer identity from untrusted browser-supplied claims.

**Execution identity:** use workspace/account-specific OAuth service principals or workload identity federation where supported. A central broker resolves credentials **only for authorized targets**. Prefer short-lived tokens and GitHub Actions OIDC rather than long-lived personal access tokens. Separate the human approver from the executing machine principal; record both in audit. GitHub App credentials and Terraform provider credentials are separately scoped.

**Cross-account:** maintain distinct workspace URL, cloud/account identifiers, credential profiles and role checks. Network egress, private link, IP allowlists and API capabilities may require destination-side runners. Never assume cross-account Unity Catalog sharing or shared identity objects.

## 9. Security and governance architecture

- **Zero-trust boundaries:** browser → API; API → metadata; worker → Databricks/GitHub/Terraform; optional AI → approved endpoint. Validate and authorize at each boundary.
- **Tenant isolation:** tenant IDs on domain records, tenant-scoped repository queries and compound ownership checks; no cross-tenant cache leakage.
- **Least privilege:** per-project/workspace roles, approval separation, time-bound execution permissions, resource-scoped access.
- **Secret handling:** encrypted secret store references, no plaintext tokens in database/logs/AI prompts; redaction of plan and Terraform output.
- **Supply-chain security:** verified GitHub webhooks, allowlisted GitHub Apps/repos/workflows, immutable commit SHAs, pinned Terraform providers, module trust checks, signed or digest-verified artifacts where possible.
- **Deployment safeguards:** read-only plan, approval binding to plan hash, resource locks, explicit adoption, destructive-action policy, revalidation before execution.
- **Network security:** approved workspace host allowlist, TLS, egress restrictions, SSRF defenses, isolated Terraform execution and optional private connectivity.
- **Audit:** append-only event history with request identity, source/target, plan hash, approval, artifact provenance, execution steps and rollback evidence.
- **AI:** opt-in, read-scoped, sanitized inputs, grounded citations/evidence, prompt-injection defenses and no authority to approve or execute.

## 10. Persistence architecture (Lakebase PostgreSQL)

Use SQLAlchemy repositories and Alembic migrations. Core conceptual entities:

| Domain | Tables / records |
|---|---|
| Identity & tenancy | tenants, users, roles, role_assignments, workspace_access |
| Connectivity | workspaces, credential_profiles, workspace_capabilities |
| Inventory | assets, asset_snapshots, asset_dependencies, adapter_capabilities |
| Projects | project_drafts, projects, project_versions, project_targets, project_assets, project_templates |
| Mapping | mapping_profiles, mapping_rules, target_configurations |
| Packages & releases | deployment_packages, package_assets, release_manifests, release_stages, model_promotion_evidence |
| Planning | deployment_plans, plan_operations, conflicts, policy_evaluations |
| Execution | deployment_runs, target_runs, deployment_steps, execution_checkpoints, resource_locks, resource_bindings |
| Governance | approvals, audit_events, notifications, policy_definitions |
| GitOps | github_installations, repositories, pipeline_definitions, pipeline_runs, webhook_receipts |
| Terraform | terraform_configurations, terraform_run_requests, terraform_runs, terraform_state_references, terraform_resource_ownership |
| Sync & recovery | drift_snapshots, sync_runs, rollback_plans, recovery_actions, artifact_versions |
| AI | ai_request_audit, ai_feedback, ai_configuration (metadata only; no sensitive prompts by default) |

**Storage rules:** UUID identifiers, UTC timestamps, JSONB for versioned provider definitions, indexes on tenant/project/run/target, strict uniqueness for stable logical resource keys and target bindings, optimistic concurrency for drafts and plans, encrypted credentials **outside** normal relational columns. Use UC Volumes/object storage for larger artifacts, sanitized logs and immutable release bundles; DB stores digests and locations. Establish retention and deletion policy per tenant.

## 11. Durable execution and state machine

The FastAPI app must **not** execute long-running deployments in request threads or ephemeral `BackgroundTasks`. Requests validate and persist a run; a durable dispatcher schedules a Databricks Job worker or an approved external runner. The worker claims the run with a lease, executes idempotent steps, writes checkpoints and heartbeats, and reconciles external workflow status. Use transactional outbox or equivalent durable dispatch to prevent lost work between DB commit and job trigger.

**Lifecycle:** `DRAFT → VALIDATED → PENDING_APPROVAL → QUEUED → RUNNING → VERIFYING → SUCCEEDED | PARTIAL | FAILED | CANCELLED`. A plan may become `STALE` and require regeneration. Each target has an independent state machine and result; a parent run aggregates without hiding partial outcomes. Use bounded retries for transient errors, explicit locks for shared resources, rate-limit awareness and deterministic recovery after process restart.

**Plan ownership:** a stable logical key plus target workspace identifies a managed resource; `resource_bindings` preserve the actual target ID and owning mechanism (`direct`, `git_bundle`, `terraform`). Changing ownership is an explicit reviewed migration.

## 12. Direct deployment execution flow

```mermaid
flowchart LR
  A[Saved project] --> B[Refresh source + target inventory]
  B --> C[Resolve dependencies + mappings]
  C --> D[Deterministic plan + policy checks]
  D --> E{Approvals satisfied?}
  E -- No --> F[Wait / block]
  E -- Yes --> G[Durable worker]
  G --> H[SDK / REST asset adapters]
  H --> I[Target-specific verification]
  I --> J[Bindings + audit + release evidence]
```

The plan includes create/update/no-op/adopt/conflict/blocked and, for explicitly authorized sync operations, delete. Direct execution can target several workspaces with independent run records. Adapter implementations must avoid updating shared Unity Catalog objects blindly when multiple workspaces use one metastore.

## 13. Git-enabled CI/CD and release architecture

**GitHub App** provides installation-scoped repository access; use webhooks with signature verification, idempotent event processing, least-privilege permissions and branch protections. Generated bundles contain `databricks.yml`, resource definitions, source files and target variables, while preserving existing repository conventions. GitHub Actions validates/test/plans and deploys approved immutable commit SHAs using federated Databricks authentication where supported.

**Source of truth:** for Git-owned resources, Git commits and immutable build artifacts define the release; DeployPactAI stores manifest, mapping and run metadata. Never silently apply SDK changes that Git will later overwrite. Support PR approval, environment gates, workflow status polling/webhooks, artifact integrity and traceability from release → commit → target resources.

## 14. Release Promotion and ML model promotion

A **Release Promotion project** owns an immutable release manifest and an ordered stage graph, e.g. Development → Staging → Production. Each stage has mapping profile, required tests, approvals, rollout window and target workspaces. Promote the same artifact/model version while applying only approved environment-specific configuration.

For **ML models**, integrate Unity Catalog/MLflow model registry and Databricks serving APIs as supported: identify model/version, validate metadata/signature and evaluation evidence, check thresholds, resolve model artifact access, update target environment alias or serving reference, deploy/modify serving endpoint, run smoke tests and record results. Restore the prior alias/endpoint configuration through an approved rollback plan when supported. Do **not** implement ML as a fifth project type; do **not** rely on deprecated registry stage APIs.

## 15. Terraform integration: two supported execution modes

```mermaid
flowchart TB
  P[Project / release Terraform configuration] --> V[Validate repo, module, variables, ownership]
  V --> M{Execution mode}
  M -->|Preferred: existing CI/CD| X[Trigger customer GitHub Actions / supported pipeline]
  M -->|Managed| Y[Isolated Terraform runner]
  X --> PL[Terraform init / validate / plan]
  Y --> PL
  PL --> A[Sanitize plan + policy + human approval]
  A --> AP[Approved terraform apply]
  AP --> S[(Existing remote state + locking)]
  AP --> D[Databricks infrastructure]
  D --> Z[Verification + provenance + downstream asset deployment]
```

**Mode A — existing pipeline (preferred):** reference customer-owned repo/workflow, dispatch it with approved inputs, consume plan evidence/status and enforce an approval handshake before apply. Where the customer workflow cannot separate plan from apply or expose evidence, mark the integration as unsupported until an approved contract is established; do not pretend DeployPactAI controls its gates.

**Mode B — managed execution:** launch isolated worker with Terraform CLI, pinned provider/module versions, restricted filesystem/network, short-lived credentials, remote backend configuration and state locking. Run `init → validate → plan`, preserve the exact reviewed plan artifact, and apply **that approved plan** after rechecking authorization and freshness. Capture sanitized outputs and state metadata, not raw state secrets.

**Safety:** do not replace existing state, auto-import unmanaged resources, auto-destroy or assume Terraform rollback is transactional. Terraform-managed resources retain Terraform ownership. When Terraform provisions prerequisites, enforce dependency ordering before notebook/job/pipeline deployment. State backend support depends on the customer's approved provider and connectivity.

## 16. Workspace synchronization and drift

Inventory snapshots feed a comparison engine with normalized resource definitions and configurable ignore rules for server-generated fields. Distinguish intentional environment differences from drift; support source→target synchronization with explicit direction, scopes and schedules. Generate a plan for every sync run, respect ownership and approval policies, and default to no deletion. Store drift evidence, applied changes and subsequent verification. Prevent overlapping sync runs and cycles between workspace pairs.

## 17. Rollback and recovery architecture

A rollback is a **new controlled deployment**, not a database transaction undo. The system identifies a previous release manifest, computes target-specific reverse diffs, classifies each step as reversible/compensatable/manual/non-reversible, evaluates policy and approval, and executes through the same durable worker framework. Use stored immutable bundle/artifact digests, previous resource definitions and bindings. Model alias/serving reference restoration is supported where API semantics permit; previous pipeline/job/notebook definitions may be restored; Terraform reversal requires a reviewed prior configuration and new plan/apply. Dataset mutations, external side effects and some deleted resources may require manual recovery. Preserve audit trail of both original and recovery runs.

## 18. AI advisory architecture and feasibility limits

```text
Authorized inventory / deterministic plan / sanitized run logs / evaluation metrics
                 ↓ scoped retrieval + redaction
        AI advisory service + prompt templates
                 ↓ approved model endpoint
      Structured suggestions + evidence references
                 ↓ schema validation + human review
     UI recommendations (never direct execution)
```

Supported bounded use cases: natural-language asset search/summaries; dependency hypotheses; mapping recommendations; plain-language plan/risk summaries; error explanation and remediation suggestions; release notes; Terraform plan explanation; ML promotion evidence summaries. Rule-based policy, dependency validation, diff computation and approval checks remain deterministic. Model unavailability must not prevent non-AI deployments. Evaluate hallucination, information leakage, prompt injection, latency and cost before enabling in production.

## 19. Observability, testing and delivery architecture

**Telemetry:** correlate `tenant_id`, `project_id`, `plan_id`, `run_id`, `target_run_id`, `step_id`, external GitHub/Terraform run IDs and Databricks request IDs. Emit structured events for user actions, policy decisions, state transitions, worker heartbeats and verification. Redact credentials and sensitive notebook/SQL content.

**Testing:** adapter contract tests, workspace mock tests, cross-account integration tests, tenant-isolation tests, plan-diff golden cases, idempotency/retry/restart tests, GitHub webhook signature tests, Terraform plan/apply/state-lock tests, ML alias/serving promotion tests, rollback capability tests, end-to-end browser tests, load and security tests. Use nonproduction workspaces and disposable resources for destructive test cases.

**Deployment:** CI validates frontend/backend, type checks, unit tests, vulnerability scans and artifacts. Deploy frontend build + FastAPI as a Databricks App, provision Lakebase and storage, register worker jobs and external integrations, and run database migrations under controlled change management. Separate application deployment from customer asset deployment.

## 20. Implementation sequence without reducing product scope

1. **Foundation:** repository scaffolding, CI, auth/tenant model, Lakebase migrations, audit, horizontal UI shell, workspace registry.
2. **Shared engine:** asset adapters, inventory, dependency graph, mappings, immutable planning, policies and durable execution.
3. **Four project workflows:** Direct, Git-Enabled, Release Promotion (including ML), Workspace Sync; common run history and project templates.
4. **Infrastructure and governance:** Terraform pipeline/runner modes, GitHub integration, approvals, rollback/recovery, drift, monitoring.
5. **AI and hardening:** bounded advisory features, observability, security testing, compatibility matrix, documentation and production readiness.

All stages are part of the **full target product**; sequencing is an engineering dependency plan, not an MVP scope cut.

## 21. Architecture decisions requiring explicit confirmation

- Target cloud(s), Databricks workspace network topology and optional private runner approach.
- Final UI component library and frontend styling system.
- Identity provider, Databricks Apps user identity semantics and service-principal federation capabilities.
- Databricks Jobs worker capacity versus an external queue/worker platform; durable dispatch guarantees.
- GitHub-only CI/CD or additional supported external providers.
- Terraform runner location, state backends, approval handshake and allowed module/provider sources.
- Per-asset API/rollback support matrix, especially dashboards, apps, UC securables and serving.
- AI endpoint, privacy policy, evaluation gates and cost controls.
- SLOs, retention, concurrency and compliance requirements.

**Engineering rule:** Resolve these through ADRs and provider validation; do not silently substitute insecure defaults or invent unsupported Databricks functionality.
