# ADMIN-05 — Audit Logs | Implementation Specification

**Product:** JadeOrbit DeployPactAI | **Navigation:** Administration → Audit Logs | **Scope:** Complete production feature

> **Coding-agent instruction:** Implement a shared, append-only **application audit trail**, not another deployment log table. Reuse existing audit/telemetry/outbox if present. Databricks system audit logs and GitHub audit logs are separate external sources; show them only through explicitly supported integrations and never label application events as authoritative Databricks account audit events.

## 1. Objective

Provide trustworthy tenant-scoped evidence of who performed, requested, approved, configured or executed operations across all four project types, GitHub, Terraform, ML promotion, AI assistance, access control and settings. Enable forensic traceability from project → plan → policy evaluation → approval → execution → verification → rollback. Store events durably with retention and export controls.

## 2. Page composition

- **Event Explorer:** searchable/paginated events with timestamp (UTC and viewer timezone), actor, action, category, outcome, target, project, correlation ID, IP/user agent where available and privacy-approved; structured detail drawer.
- **Security & Access:** sign-in/session events available to application, role changes, denied authorization, credential/integration configuration changes, policy exceptions.
- **Deployment & Release:** plan creation/stale, asset adoption, deployment steps, sync/delete, GitHub workflow dispatch, Terraform plan/apply, release promotion, ML alias/endpoint updates, rollback and recovery.
- **Policy & Approvals:** policy publish/version, simulation vs enforced evaluations, approvals, rejections, expired/invalidated requests, override/exception events.
- **AI Activity:** model/endpoint configuration, AI feature invocation, data classification, output accepted/rejected, fallback and error; **do not persist full prompts or customer asset content by default**.
- **Exports & Retention:** scoped evidence export jobs, saved filters, retention policy view, export history, integrity validation and deletion/legal-hold status.
- **Event Details:** immutable ID, actor/acting service, event time, entity identifiers, request/trace/correlation IDs, plan/policy/artifact digests, redacted before/after diff, linked evidence manifests and verification result.

## 3. Event taxonomy and data contract

Categories `AUTH`, `ACCESS`, `PROJECT`, `WORKSPACE`, `ASSET`, `PLAN`, `POLICY`, `APPROVAL`, `DEPLOYMENT`, `RELEASE`, `SYNC`, `GITHUB`, `TERRAFORM`, `ML`, `AI`, `SETTINGS`, `EXPORT`, `SECURITY`. Outcomes `SUCCESS`, `FAILURE`, `DENIED`, `PENDING`, `PARTIAL`. Examples: `ROLE_ASSIGNED`, `USER_DISABLED`, `POLICY_PUBLISHED`, `APPROVAL_DECIDED`, `PLAN_CREATED`, `PLAN_INVALIDATED`, `DEPLOYMENT_STARTED`, `TARGET_STEP_FAILED`, `GITHUB_WORKFLOW_DISPATCHED`, `TERRAFORM_APPLY_APPROVED`, `MODEL_ALIAS_PROMOTED`, `ROLLBACK_EXECUTED`, `AI_SUGGESTION_ACCEPTED`, `AUDIT_EXPORTED`.

Every event includes immutable `event_id`, `tenant_id`, UTC timestamp, `event_type`, `category`, `outcome`, actor type and identifier, subject type/ID, target workspace/project/environment when applicable, request/trace IDs, structured redacted detail, provenance references and optional previous-event hash. Use allowlisted detail fields; redact tokens, keys, passwords, notebook/SQL contents, PII beyond policy. Client cannot submit arbitrary privileged audit records as authoritative.

## 4. Functional and nonfunctional requirements

1. Server-side filtering by tenant, category, date range, actor, action, target, status, project, request/plan/run ID; cursor pagination and deterministic sort. Default time window configurable.
2. Event detail with related entity deep-links; preserve links even if user/asset deleted (tombstone labels). Enforce permission on linked resources; no IDOR.
3. Export CSV and JSONL, optionally signed evidence bundle with manifest/digests; asynchronous for large ranges, download through short-lived authorized URL. Log export itself.
4. Persist critical audit events **atomically with business transaction** via transactional outbox or same DB transaction. Worker events should use idempotent delivery and sequence/correlation IDs.
5. Append-only behavior: no ordinary UPDATE/DELETE on audit rows; corrections are compensating events. Privileged DB administrators remain a trust boundary—do not claim cryptographic immutability from DB permissions alone.
6. Optional hash chaining and external WORM/object-lock archival for tamper evidence; integrity check reports chain gaps and archive status. Document that hash chain is **tamper-evident**, not inherently tamper-proof.
7. Retention configured per tenant and category within legal constraints; legal hold prevents purging; exports honor tenant data residency and security policy.
8. Avoid making app deployment availability depend on synchronous external log shipping; durable local event + asynchronous archival with alerts.
9. Correlate Databricks job IDs, GitHub workflow IDs, Terraform run IDs, release manifest digests and ML model version/alias events where available; never claim visibility beyond integration permissions.
10. Auditors have scoped read/export; platform admins cannot silently erase audit events through UI. Alert on repeated authorization failures, policy bypass attempts, invalid webhook signatures and export anomalies.

## 5. Backend architecture

Use `audit_event_writer` invoked from all domain services; `audit_outbox_publisher`, `audit_query_service`, `audit_export_worker`, `retention_manager`, `integrity_verifier`. Prefer transactionally inserting event/outbox record alongside change. Use stable event schema version; never let arbitrary frontend data override actor/tenant/time. Worker service identity events include `initiated_by` human and `executed_by` machine. External logs can be linked via source provenance, with source/type clearly labeled.

## 6. Lakebase PostgreSQL reference DDL

```sql
CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE TABLE IF NOT EXISTS audit_events (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id uuid NOT NULL REFERENCES tenants(id),
 occurred_at timestamptz NOT NULL DEFAULT now(), schema_version integer NOT NULL DEFAULT 1,
 category text NOT NULL, event_type text NOT NULL, outcome text NOT NULL,
 actor_type text NOT NULL CHECK(actor_type IN ('USER','SERVICE','SYSTEM','EXTERNAL')),
 actor_id text, initiated_by uuid, subject_type text, subject_id text,
 project_id uuid, target_workspace_id uuid, environment_key text,
 request_id text, trace_id text, correlation_id text,
 plan_digest text, artifact_digest text, source_system text NOT NULL DEFAULT 'DEPLOYPACTAI',
 detail_redacted jsonb NOT NULL DEFAULT '{}'::jsonb,
 previous_hash text, event_hash text,
 ingested_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_audit_tenant_time ON audit_events(tenant_id,occurred_at DESC,id);
CREATE INDEX IF NOT EXISTS ix_audit_correlation ON audit_events(tenant_id,correlation_id,occurred_at);
CREATE INDEX IF NOT EXISTS ix_audit_event_type ON audit_events(tenant_id,event_type,occurred_at DESC);
CREATE TABLE IF NOT EXISTS audit_outbox (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id uuid NOT NULL REFERENCES tenants(id),
 event_id uuid NOT NULL REFERENCES audit_events(id), destination text NOT NULL,
 status text NOT NULL DEFAULT 'PENDING' CHECK(status IN ('PENDING','SENT','FAILED','DEAD_LETTER')),
 attempts integer NOT NULL DEFAULT 0, next_attempt_at timestamptz,
 created_at timestamptz NOT NULL DEFAULT now(), UNIQUE(event_id,destination)
);
CREATE TABLE IF NOT EXISTS audit_exports (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id uuid NOT NULL REFERENCES tenants(id),
 requested_by uuid NOT NULL, filter_snapshot jsonb NOT NULL,
 status text NOT NULL DEFAULT 'QUEUED' CHECK(status IN ('QUEUED','RUNNING','SUCCEEDED','FAILED','EXPIRED')),
 storage_uri text, file_digest text, row_count bigint,
 requested_at timestamptz NOT NULL DEFAULT now(), expires_at timestamptz
);
CREATE TABLE IF NOT EXISTS audit_retention_rules (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id uuid NOT NULL REFERENCES tenants(id),
 category text NOT NULL, retain_days integer NOT NULL CHECK(retain_days > 0),
 legal_hold boolean NOT NULL DEFAULT false,
 archive_enabled boolean NOT NULL DEFAULT true, UNIQUE(tenant_id,category)
);
```

**Migration note:** If existing `audit_events` already exists, extend its columns rather than creating a duplicate. Production hardening: monthly partitioning as volume requires, restricted INSERT-only app role, no UPDATE/DELETE grants, archive verification, tamper-evident hash ordering using a serialized stream/partition sequence (not merely timestamp order). Avoid foreign-key cascades from user/project to audit.

## 7. UI and operational behaviors

Show explicit labels **Application Audit** vs **External Provider Events**. Provide safe JSON viewer with redacted fields, copy correlation ID, time zone toggle, save filter, and export confirmation. Large export is asynchronous and requires fresh authorization at download. Show data freshness and archive lag. Errors: query timeout, export too large, retention restriction, missing linked resource, legal hold, archive unavailable.

## 8. Tests and acceptance

- Event creation for every critical admin and deployment action, failed/denied actions, webhook invalid signatures, AI invocations; no secret leakage.
- Tenant isolation, export scope, idempotent outbox retry, append-only DB permissions, correlation links, pagination at volume, retention/legal hold, integrity gap detection.
- **Done when:** auditors can trace end-to-end actions, exports are controlled and logged, critical events survive failures, and sensitive information is consistently redacted.

## 9. Coding-agent deliverables

Implement event taxonomy/schema, shared audit writer, outbox/retention/export workers, explorer UI, indexes/migrations, audit events in all admin flows, security tests, archive/integrity operational runbook. Do not conflate technical debug logs with audit evidence.
