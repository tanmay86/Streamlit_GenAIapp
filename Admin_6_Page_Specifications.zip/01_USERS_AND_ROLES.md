# ADMIN-01 — Users & Roles | Implementation Specification

**Product:** JadeOrbit DeployPactAI | **Navigation:** Administration → Users & Roles | **Status:** Build specification | **Scope:** Complete production feature

> **Coding-agent instruction:** Inspect the existing React/TypeScript, FastAPI, authentication middleware, Lakebase models/migrations, workspace registry, UI component library, and routing before coding. Extend existing patterns rather than creating a parallel identity system. The DDL is a **reference migration**, not permission to drop or replace existing tables. Reconcile with `PROJECT_REQUIREMENTS.md` and `PROJECT_ARCHITECTURE.md`. Do not fabricate Databricks account identity APIs or silently provision external IdP accounts.

## 1. Outcome and boundaries

Deliver tenant-scoped identity administration, role-based authorization, granular resource scopes, invitations/activation where supported, effective-permission inspection, service identity visibility, and access review. Databricks Apps / corporate SSO authenticates humans; DeployPactAI **authorizes** application operations. App roles do not automatically grant Databricks workspace, Unity Catalog, GitHub or Terraform permissions. Workspace execution credentials are administered separately.

## 2. Page composition and navigation

- **Users** tab: searchable, paginated list with display name, email, identity provider subject, account state, last login, assigned roles, scope summary, MFA/SSO indicator **only if provided by trusted IdP**, and actions View, Edit assignments, Disable, Reactivate, Revoke sessions if technically supported. Never offer password editing for SSO identities.
- **Roles & Permissions** tab: built-in roles, custom roles, permission matrix grouped by module/action, scope, inheritance and immutable system-role flags. Role detail includes members and affected resources.
- **Access Assignments** tab: user/group/service identity → role → tenant/workspace/project/environment scope, grant source, expiration, reviewer, creation reason.
- **Invitations / Pending Access** tab: request access, approve assignment if policy requires, link existing IdP identities; do not imply creating an IdP account unless integrated.
- **Access Reviews** tab: periodic review campaigns, orphaned accounts, expired grants, separation-of-duties conflicts, exportable evidence.
- **Service Identities** tab: read-only metadata for registered workload principals and their authorized workspace/repository scopes; credential secrets never shown.
- Detail panels: effective permissions, audit history, role assignment history, projects/workspaces accessible, active approval eligibility.

## 3. Roles and permissions

Default roles: **Platform Administrator** (tenant platform config), **Workspace Administrator** (assigned workspace registry and mappings), **Project Owner** (assigned projects), **Deployment Engineer** (prepare plans and execute permitted environments), **DevOps / Release Engineer** (GitHub, Terraform, CI/CD, releases), **Approver / Change Manager** (approve eligible changes), **Auditor / Security Reviewer** (scoped read-only), **Viewer** (read-only permitted data). A tenant can define custom roles from granular permission keys; built-ins can be versioned but not silently changed. **No role bypasses server-side policies.**

Permission keys should include `users.read`, `users.manage`, `roles.read`, `roles.manage`, `assignments.manage`, `workspaces.read/manage`, `assets.read`, `projects.read/manage`, `plans.create/read`, `deployments.execute/read/cancel`, `releases.promote/rollback`, `sync.execute`, `terraform.plan/apply`, `github.integrations.manage`, `github.repositories.read`, `approvals.read/decide/administer`, `policies.read/manage/publish`, `audit.read/export`, `settings.read/manage`, `secrets.configure`, `ai.configure`. Use deny-by-default; effective grants are the union of **applicable** roles, constrained by tenant, resource scope, environment and explicit deny/SoD rules. Role assignment must not bypass target Databricks permissions.

## 4. Functional requirements

1. Load only users from active tenant; server-side filtering, sorting and cursor pagination. Resolve current principal by trusted authentication claim `issuer + subject`, not browser-supplied email.
2. Support IdP-backed just-in-time user registration if enabled; optional IdP/group synchronization only when an approved integration exists. External group mappings must be reviewed, not guessed.
3. Assign/revoke multiple roles with `TENANT`, `WORKSPACE`, `PROJECT`, or `ENVIRONMENT` scope. Validate referenced scope belongs to same tenant; optionally set expiry.
4. Protect last active tenant administrator from removal/disable. Prevent self-escalation and self-approval; sensitive grants may require second administrator approval.
5. Invalidate authorization caches on role changes; enforce revocation on **every** privileged API and queued action reauthorization. Do not assume revoking an app role instantly invalidates external Databricks tokens.
6. Disabling user blocks new access; preserve historical authorship/audit, never cascade-delete runs/approvals. Support reinstatement by authorized admin.
7. Show effective permissions with traceable origin (role, scope, inherited group, expiry). Explicitly show external resource authorization is independently checked.
8. Record immutable before/after role/assignment changes in central audit without secret or PII overexposure.
9. Support CSV export of scoped user/access reviews with audit event and sensitive-export permission.
10. Accessible loading, empty, permission-denied and conflict states; confirmation dialog for destructive administration actions; optimistic concurrency for edits.

## 5. Backend and service behavior

Modules: `identity_directory`, `role_catalog`, `permission_evaluator`, `assignment_service`, `access_review_service`. Use existing authenticated request context `{tenant_id, principal_id, issuer, subject, scopes}`; never trust `tenant_id` from request body. Authorization is a reusable dependency/middleware invoked by all administration and deployment services. Maintain a canonical permission registry in code, with migrations for new permissions. Enforce scope-aware checks for multi-target operations **per target**. Read external identity metadata through supported provider adapters; degrade gracefully if unavailable. Use transactions for grant changes and audit outbox/event creation.

**Example contracts (illustrative, not mandatory URL naming):** list users, get user detail, assign/revoke role, list roles/permissions, create/edit custom role, compute effective access, start/complete access review. Responses must be tenant-scoped, paginated, validated and documented in OpenAPI. Use structured errors `UNAUTHORIZED`, `FORBIDDEN`, `LAST_ADMIN`, `SOD_VIOLATION`, `VERSION_CONFLICT`, `SCOPE_NOT_FOUND`.

## 6. Lakebase PostgreSQL reference DDL

Assumes `tenants(id uuid primary key)` and `workspaces(id uuid primary key, tenant_id uuid ...)` exist. Prefer adapting existing `app_users`, `roles`, `role_assignments` over duplicating them. UUIDs generated by app or `pgcrypto`; migrations must be additive. The scope reference is polymorphic and **must be validated in service logic** (or via a tenant-scoped reference table) before writes.

```sql
CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE TABLE IF NOT EXISTS app_users (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id uuid NOT NULL REFERENCES tenants(id),
 issuer text NOT NULL, subject text NOT NULL, email text, display_name text,
 status text NOT NULL DEFAULT 'ACTIVE' CHECK(status IN ('ACTIVE','DISABLED','PENDING')),
 last_login_at timestamptz, created_at timestamptz NOT NULL DEFAULT now(),
 updated_at timestamptz NOT NULL DEFAULT now(), version integer NOT NULL DEFAULT 1,
 UNIQUE(tenant_id,issuer,subject)
);
CREATE INDEX IF NOT EXISTS ix_app_users_tenant_status ON app_users(tenant_id,status);
CREATE TABLE IF NOT EXISTS app_permissions (
 permission_key text PRIMARY KEY, module text NOT NULL, description text NOT NULL
);
CREATE TABLE IF NOT EXISTS app_roles (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id uuid NOT NULL REFERENCES tenants(id),
 code text NOT NULL, name text NOT NULL, description text, is_system boolean NOT NULL DEFAULT false,
 is_active boolean NOT NULL DEFAULT true, version integer NOT NULL DEFAULT 1,
 created_at timestamptz NOT NULL DEFAULT now(), UNIQUE(tenant_id,code), UNIQUE(id,tenant_id)
);
CREATE TABLE IF NOT EXISTS app_role_permissions (
 role_id uuid NOT NULL REFERENCES app_roles(id) ON DELETE CASCADE,
 permission_key text NOT NULL REFERENCES app_permissions(permission_key),
 PRIMARY KEY(role_id,permission_key)
);
CREATE TABLE IF NOT EXISTS app_role_assignments (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id uuid NOT NULL REFERENCES tenants(id),
 user_id uuid NOT NULL, role_id uuid NOT NULL,
 scope_type text NOT NULL CHECK(scope_type IN ('TENANT','WORKSPACE','PROJECT','ENVIRONMENT')),
 scope_id uuid, expires_at timestamptz, granted_by uuid, justification text,
 created_at timestamptz NOT NULL DEFAULT now(), revoked_at timestamptz,
 FOREIGN KEY(role_id,tenant_id) REFERENCES app_roles(id,tenant_id),
 CHECK ((scope_type='TENANT' AND scope_id IS NULL) OR (scope_type<>'TENANT' AND scope_id IS NOT NULL))
);
CREATE INDEX IF NOT EXISTS ix_assignments_lookup ON app_role_assignments(tenant_id,user_id,revoked_at,expires_at);
CREATE TABLE IF NOT EXISTS access_reviews (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id uuid NOT NULL REFERENCES tenants(id),
 title text NOT NULL, status text NOT NULL CHECK(status IN ('OPEN','CLOSED','CANCELLED')),
 reviewer_id uuid NOT NULL, due_at timestamptz, created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS access_review_items (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), review_id uuid NOT NULL REFERENCES access_reviews(id),
 assignment_id uuid NOT NULL REFERENCES app_role_assignments(id),
 decision text CHECK(decision IN ('KEEP','REVOKE','ESCALATE')),
 decided_at timestamptz, notes text, UNIQUE(review_id,assignment_id)
);
```

**Migration hardening:** enforce same-tenant user/assignment references using `(id, tenant_id)` unique keys and composite FKs or service-verified transactional checks; do not accept cross-tenant UUIDs. Create partial unique index for active duplicate grants as appropriate; add migrations for retention, foreign keys, row-level security if platform design supports it. Role changes and access review decisions must emit central audit events.

## 7. Security, audit, testing and acceptance

- Require `users.manage` / `roles.manage`; avoid self-grant and privilege escalation; CSRF/session protections per existing auth architecture; protect against IDOR and cross-tenant enumeration.
- Audit `USER_DISABLED`, `ROLE_CREATED/UPDATED`, `ROLE_ASSIGNED/REVOKED`, `ACCESS_REVIEW_DECIDED`, denied privilege escalation. Store actor, scope, request ID, before/after redacted diff.
- Tests: scoped grants; expired/revoked role; concurrent last-admin removal; cross-tenant UUID injection; SoD; no direct workspace privilege assumption; pagination; cache invalidation; access review evidence.
- **Done when:** authorized admins can manage roles and assignments, effective permissions drive all app actions, unauthorized actions fail server-side, history remains auditable, and no external credential or IdP account is exposed.

## 8. Coding-agent deliverables

Implement navigation page and child tabs, typed frontend API client/state, FastAPI domain service and authorization dependency, additive migrations/seed permissions and roles, audit events, tests (unit/integration/E2E), and concise README. Document any existing-schema differences before migrating. Do not implement unrelated menu pages here.
