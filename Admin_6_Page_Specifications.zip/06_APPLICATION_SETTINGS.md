# ADMIN-06 — Application Settings | Implementation Specification

**Product:** JadeOrbit DeployPactAI | **Navigation:** Administration → Application Settings | **Scope:** Complete production feature

> **Coding-agent instruction:** Settings must control the **existing running Databricks App**, not assume a new deployment. Inspect current FastAPI config, React settings state, Lakebase persistence, Databricks SDK, workspace registry and secret manager. Separate immutable deployment-time environment variables from editable tenant settings. Never store raw credentials or private keys in Lakebase; store approved secret references only. The user has selected **four** project types; ML promotion is a feature inside Release Promotion, not a fifth type.

## 1. Objective

Provide secure, validated configuration for tenant preferences, Databricks connectivity defaults, execution limits, worker/runner configuration, GitHub and Terraform integration defaults, ML release settings, AI assistance, notifications, retention, feature controls, and operational health. Changes must be audited, versioned, tested where appropriate and safe to roll back.

## 2. Page tabs and functional requirements

### A. General & Organization
- Tenant display name, product branding (application name remains JadeOrbit DeployPactAI), timezone, locale, default landing page, support contact, allowed workspace/environment labels, preferred date/time format.
- Tenant ID read-only; show current application version/build and configuration revision.
- Environment-specific values clearly labeled; no setting permits changing authenticated tenant context.

### B. Databricks Defaults
- Default source/target workspace suggestions from **authorized registered workspace list**, default catalog/schema/path/warehouse mappings by environment (references only, not global credentials).
- Workspace connectivity test, capabilities cache refresh, timeout/rate-limit defaults, workspace host allowlist management by privileged admin; cross-account access remains based on registered service principal/federation.
- Read-only status for Databricks Apps host, Lakebase database, UC Volumes/artifact storage and durable Jobs workers. Never silently provision missing infrastructure from settings UI.
- Execution identity policy: approved credential profile references, short-lived OAuth/federation preference, no PAT display or token copying.

### C. Deployment & Release Defaults
- Default plan expiry, verification enabled, retry/backoff bounds, max concurrent runs/targets, per-workspace concurrency, scheduler timezone, default conflict strategy (`FAIL` or `UPDATE_MANAGED`; never overwrite unmanaged), asset discovery TTL, snapshot retention.
- Release stage templates (DEV → QA/STAGING/UAT → PROD), immutable artifact requirement, stage verification and rollback evidence retention.
- ML promotion defaults: approved Unity Catalog model namespace/aliases, required evaluation checks, model serving smoke tests, environment mapping and previous alias/endpoint snapshot retention. No assumption of legacy MLflow stages.
- Approval requirements are **defined in Deployment Policies**; display policy-linked read-only summary here rather than duplicating an independent approval toggle.

### D. Terraform & Execution Runners
- Two supported modes: **Existing customer pipeline (preferred)** and **DeployPactAI-managed isolated runner**. Allow approved runner profiles and GitHub workflow registry references.
- Terraform binary version policy, provider/module source allowlist, secure module download, workspace/environment variable mapping, secret references, plan artifact storage, plan expiry, sanitized output, execution timeout and parallelism.
- Existing remote state backend profile references, encryption/locking verification, state ownership, state isolation per environment, approved import/adoption strategy. Never display full state (may contain secrets), never auto-create/destroy state on connection test.
- Managed runner must be isolated, network-restricted, ephemeral, with audited identity and no unrestricted shell exposure. Terraform `apply` requires approved immutable plan. `destroy` blocked by default and subject to explicit policy.
- Existing pipeline integration requires evidence handshake (plan digest → approval → apply); unsupported workflow cannot claim automated approval enforcement.

### E. GitHub Defaults
- Display connected GitHub App installations (managed in **GitHub Integrations**), default repository selection constraints, workflow dispatch timeout, webhook reconciliation interval, permitted branches/workflows, commit SHA requirement, PR/review defaults.
- Provide links to integration page for secrets, installation authorization and workflow allowlists. Avoid duplicate credential management.

### F. AI Assistance
- Master enable/disable, approved Databricks Model Serving endpoint or other organization-approved model gateway, model identity, per-feature toggles for asset summaries, dependency hypotheses, mapping recommendations, plan/risk explanations, error diagnostics, Terraform plan explanation, release notes and ML promotion evidence summaries.
- Allowed data classes, prompt redaction, data minimization, logging mode (metadata only by default), human review requirement, token/cost budget, timeout, retry and rate limits, fallback behavior.
- **AI is advisory only**; it cannot approve, grant privileges, bypass policies, directly run Terraform/apply/rollback or make autonomous production changes. No customer credentials, raw Terraform state, secrets or unrestricted notebook contents in prompts. Graceful feature disable if endpoint absent.
- Test connection with non-sensitive synthetic prompt; show privacy/latency/cost diagnostics without storing raw prompt/response by default.

### G. Notifications & Integrations
- In-app notification preferences and approved email/webhook destinations where supported; event routing for approvals, deployment failures, release gates, drift alerts, Terraform runs, security incidents.
- Templates, quiet hours, retries, delivery status and test notification; secret headers stored as references, SSRF-safe allowlisted destinations. Per-user preferences override non-mandatory notices only; security-critical alerts cannot be disabled by ordinary users.

### H. Security, Retention & Operations
- Session/idle policy only where controlled by application (do not promise control of upstream SSO), trusted proxy/host settings, allowed CORS origins, export limits, retention defaults for deployment logs, audit and artifact versions, legal-hold links.
- Operational health: DB migrations, Lakebase connection, Databricks worker job health, artifact storage, GitHub webhook/reconciliation, Terraform runners, AI endpoint; display `healthy/degraded/unavailable/unknown` with last checked time.
- Maintenance mode and feature flags require audited privileged actions; security baseline flags cannot be disabled. Read-only runtime information, configuration validation, preview diff and rollback of safe configuration versions.

## 3. Settings lifecycle and permissions

- Levels: **system** (deployment-controlled, read-only), **tenant** (admin-editable), **user preference** (self-service where allowed), and **project override** (only for documented non-security defaults). Precedence: system hard limits > tenant policies > project defaults > user presentation preferences.
- Settings are typed with registry/schema: key, category, value type, validation, sensitivity, editability, default, version, restart requirement, owner and allowed scopes. Unknown keys rejected; never use arbitrary `eval` or executable config.
- Use `GET current`, `PATCH validated changes`, `preview/diff`, `test connection`, `publish`, `revert` operations via typed service; use optimistic concurrency/ETag.
- Sensitive updates require `settings.manage` plus relevant specialized permission (`secrets.configure`, `ai.configure`, `github.integrations.manage`, `policies.manage`) and optionally approval policy.
- Changes to running worker limits take effect at documented safe boundary; immutable environment variables require redeploy and should be displayed read-only.
- All changes record redacted before/after diff and actor in Audit Logs; no raw secret value returned in response. Use feature flags with per-tenant isolation and rollout state.

## 4. Backend architecture

Services: `settings_registry`, `tenant_settings_service`, `settings_validator`, `settings_publish_service`, `secret_reference_service`, `connection_health_service`, `feature_flag_service`, `notification_preferences_service`. Keep sensitive connection material in approved Databricks secret facilities or external secret manager; reference by opaque locator with scoped read permission. Worker config updates are propagated through durable event/reload mechanism; do not mutate process-wide globals per tenant. Health checks must be safe and non-destructive; rate limit expensive checks.

## 5. Lakebase PostgreSQL reference DDL

Assumes `tenants` and `app_users` already exist; do not duplicate global registry if implemented in code. For settings with JSON values, validate against code-defined schema before save; `is_secret_reference` means value is an opaque locator, not secret content.

```sql
CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE TABLE IF NOT EXISTS app_setting_definitions (
 setting_key text PRIMARY KEY, category text NOT NULL,
 value_type text NOT NULL CHECK(value_type IN ('STRING','INTEGER','BOOLEAN','JSON','SECRET_REF')),
 default_value jsonb, validation_schema jsonb NOT NULL DEFAULT '{}'::jsonb,
 is_editable boolean NOT NULL DEFAULT true, is_sensitive boolean NOT NULL DEFAULT false,
 requires_restart boolean NOT NULL DEFAULT false, description text NOT NULL
);
CREATE TABLE IF NOT EXISTS tenant_settings (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id uuid NOT NULL REFERENCES tenants(id),
 setting_key text NOT NULL REFERENCES app_setting_definitions(setting_key),
 value_json jsonb NOT NULL, revision integer NOT NULL DEFAULT 1,
 updated_by uuid NOT NULL, updated_at timestamptz NOT NULL DEFAULT now(),
 UNIQUE(tenant_id,setting_key)
);
CREATE TABLE IF NOT EXISTS tenant_setting_history (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id uuid NOT NULL REFERENCES tenants(id),
 setting_key text NOT NULL REFERENCES app_setting_definitions(setting_key),
 revision integer NOT NULL, previous_value_redacted jsonb,
 new_value_redacted jsonb, changed_by uuid NOT NULL,
 change_reason text, changed_at timestamptz NOT NULL DEFAULT now(),
 UNIQUE(tenant_id,setting_key,revision)
);
CREATE TABLE IF NOT EXISTS runner_profiles (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id uuid NOT NULL REFERENCES tenants(id),
 name text NOT NULL, runner_type text NOT NULL CHECK(runner_type IN ('GITHUB_ACTIONS','ISOLATED_MANAGED')),
 enabled boolean NOT NULL DEFAULT false, configuration jsonb NOT NULL DEFAULT '{}'::jsonb,
 credential_ref text, state_backend_ref text,
 last_health_at timestamptz, created_at timestamptz NOT NULL DEFAULT now(),
 UNIQUE(tenant_id,name)
);
CREATE TABLE IF NOT EXISTS notification_channels (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id uuid NOT NULL REFERENCES tenants(id),
 channel_type text NOT NULL CHECK(channel_type IN ('IN_APP','EMAIL','WEBHOOK')),
 name text NOT NULL, destination_redacted text, secret_ref text,
 enabled boolean NOT NULL DEFAULT false,
 configuration jsonb NOT NULL DEFAULT '{}'::jsonb,
 created_at timestamptz NOT NULL DEFAULT now(), UNIQUE(tenant_id,name)
);
CREATE TABLE IF NOT EXISTS user_preferences (
 user_id uuid NOT NULL, tenant_id uuid NOT NULL REFERENCES tenants(id),
 preference_key text NOT NULL, value_json jsonb NOT NULL,
 updated_at timestamptz NOT NULL DEFAULT now(),
 PRIMARY KEY(tenant_id,user_id,preference_key)
);
CREATE TABLE IF NOT EXISTS settings_health_checks (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id uuid NOT NULL REFERENCES tenants(id),
 component_key text NOT NULL, status text NOT NULL
 CHECK(status IN ('HEALTHY','DEGRADED','UNAVAILABLE','UNKNOWN')),
 details_redacted jsonb NOT NULL DEFAULT '{}'::jsonb,
 checked_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_settings_health ON settings_health_checks(tenant_id,component_key,checked_at DESC);
```

**Schema hardening:** enforce composite tenant FKs for users and referenced runner/repository profiles, reject credential-looking values in non-secret settings, encrypt sensitive non-secret metadata where needed, and prohibit editing system-controlled settings. Do not store Terraform state bytes, GitHub private keys, Databricks OAuth tokens or AI endpoint credentials in `configuration` JSONB.

## 6. User experience and validation

Use tabbed settings layout with `Save Draft`, `Validate`, `Preview Changes`, `Publish` (where controlled), `Cancel`, `Restore Previous Version`, and `Test Connection` only on applicable tabs. Show unsaved-change warning, field-level errors, impact analysis, inherited/read-only badges and required permission explanation. Redact secrets as “Configured / Not configured”; never return masked strings that could be mistaken for usable credentials. Include health last-check timestamps and non-destructive test result. Use existing blue UI theme and horizontal navigation.

## 7. Tests and acceptance

- Config precedence, type/schema validation, tenant isolation, permission enforcement, optimistic concurrency, settings version rollback, audit diffs, secrets never returned/logged.
- GitHub/Terraform/AI connectivity tests non-destructive; invalid runner/state backend; no unsafe webhook destinations; plan expiry and concurrency boundaries; AI off gracefully; security-critical alerts immutable for ordinary users.
- **Done when:** admins can safely manage all operational settings required for four project types, Terraform modes, ML promotion, AI, notifications and retention; configuration is versioned/audited, and hard security controls cannot be bypassed.

## 8. Coding-agent deliverables

Implement settings tabs, typed registry/validation, backend services, migrations, health workers, integration links, secret reference handling, audit events, tests, and operational README. Keep policy authoring in ADMIN-04 and GitHub installation credentials in ADMIN-03; use links rather than duplicating administration.
