# ADMIN-03 — GitHub Integration | Implementation Specification

**Product:** JadeOrbit DeployPactAI | **Navigation:** Administration → GitHub Integrations | **Scope:** Complete production feature

> **Coding-agent instruction:** This page manages GitHub **organization/repository trust and credentials**. The CI/CD → GitHub Repositories / Pipelines pages manage day-to-day project workflows. Reuse existing integration adapters and GitHub App configuration. Do not store PATs or GitHub App private keys in Lakebase plaintext; do not treat a GitHub connection as authorization to deploy to Databricks.

## 1. Goal

Enable secure, tenant-scoped GitHub App installation onboarding and maintenance for Git-Enabled Deployment, Release Promotion, Databricks Bundles, customer-owned GitHub Actions, and Terraform existing-pipeline mode. Provide webhook validation, repository/workflow allowlisting, credential health, branch protection awareness, pipeline dispatch controls and event observability.

## 2. Page tabs and components

- **Connections:** installation list with organization/account, installation ID, app name, permissions, repo coverage, health, created/last checked, owner; actions Connect, Reauthorize, Refresh, Suspend, Disconnect (impact review).
- **Repository Access:** list approved repositories per installation, default branch, selected environments, repo permissions, branch protections, bundle path, allowed workflow IDs, source-of-truth ownership; connect/disconnect repository to project via separate project settings.
- **Workflow Registry:** list approved workflow files/IDs, dispatch inputs schema, environments, approval-handshake compatibility, run visibility, Terraform vs Databricks classification, immutable SHA requirements.
- **Webhooks & Events:** endpoint status, last delivery, verified/invalid/replayed events, retry/dead-letter queue, event→run correlation. Show sanitized payload metadata only.
- **Security & Diagnostics:** installation permissions, missing scopes, token expiry behavior, webhook secret rotation, OIDC/federation readiness, branch protection check, rate-limit/error diagnostics, last health check.
- **Terraform Pipeline Connections:** approved workflows that run existing Terraform code, expected plan/apply separation, plan artifact digest and state-backend ownership; cross-link to Application Settings for runner/state configuration.

## 3. Required workflows

1. Connect GitHub App using verified installation callback/state/nonce; validate callback origin and installation ownership; associate installation with **one authorized tenant**; restrict installation/repo access to explicitly approved repositories.
2. List accessible repositories with GitHub installation token minted server-side; never send installation tokens to browser. Handle pagination, rate limits, revoked installations, renamed repos and suspended accounts.
3. Register repo by stable GitHub repository ID, owner/name as display metadata; discover workflows and branches; enforce branch and workflow allowlists. Do not accept arbitrary workflow URL/host.
4. For Git-Enabled Deployment, generate/reconcile Databricks bundle files, create branch/PR, monitor checks, and dispatch approved GitHub Actions at an immutable commit SHA. Preserve existing repo files unless explicitly reviewed; Git is source of truth for Git-owned resources.
5. For Release Promotion, enforce GitHub environment protections and DeployPactAI approvals; track release manifest → SHA → workflow run → Databricks target. Never claim app approvals override GitHub protection rules.
6. For Terraform **existing-pipeline mode (preferred)**, trigger only registered workflows with reviewed input schema and verifiable plan→approval→apply handshake. Where not supported, allow monitoring/manual handoff but **not** automated apply.
7. Validate `X-Hub-Signature-256` over **raw request body** using constant-time comparison; enforce event allowlist, replay/idempotency via delivery ID, tenant-installation mapping, body-size limits, safe JSON parsing and background processing.
8. Webhook deliveries and workflow statuses are eventually consistent; reconcile via periodic GitHub API polling if webhooks delayed/missed. Retry bounded transient failures; dead-letter and alert permanent failures.
9. Disconnect/revoke: identify affected projects/pipelines, disable future dispatch, preserve historical run provenance and audit; avoid deleting user repositories or workflows.
10. Support GitHub App permissions only as required (typically repository metadata, contents, pull requests, actions/workflows depending on supported operations; verify exact GitHub API permission requirements at implementation). Explain to admins why permissions are needed.

## 4. Backend design

Services: `github_installation_service`, `repository_registry`, `workflow_registry`, `github_token_broker`, `webhook_receiver`, `github_event_worker`, `github_reconciler`, `github_health_service`. Use GitHub App JWT → installation access token with short lifetime, secrets manager for private key/webhook secret, no direct browser GitHub API with privileged credentials. For OIDC Databricks auth, configure trusted federation in each target account/workspace; never assume a GitHub token is a Databricks token. Maintain separate connection records for Databricks OAuth and Terraform runner/state backend.

**Implementation detail:** Webhook endpoint must return promptly after signature and envelope validation, durably enqueue event, then process asynchronously; ensure retries are idempotent. Use GitHub API ETags/caching where safe. Store external installation ID/repository ID as bigint (not UUID).

## 5. Lakebase PostgreSQL reference DDL

```sql
CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE TABLE IF NOT EXISTS github_installations (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id uuid NOT NULL REFERENCES tenants(id),
 github_installation_id bigint NOT NULL, github_account_id bigint NOT NULL,
 account_login text NOT NULL, app_slug text NOT NULL,
 status text NOT NULL DEFAULT 'ACTIVE' CHECK(status IN ('ACTIVE','SUSPENDED','REVOKED','ERROR')),
 permissions_snapshot jsonb NOT NULL DEFAULT '{}'::jsonb,
 secret_ref text, webhook_secret_ref text,
 installed_at timestamptz, last_checked_at timestamptz,
 created_at timestamptz NOT NULL DEFAULT now(), UNIQUE(github_installation_id), UNIQUE(id,tenant_id)
);
CREATE TABLE IF NOT EXISTS github_repositories (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id uuid NOT NULL REFERENCES tenants(id),
 installation_id uuid NOT NULL, github_repository_id bigint NOT NULL,
 full_name text NOT NULL, default_branch text, is_approved boolean NOT NULL DEFAULT false,
 bundle_root text, ownership_mode text NOT NULL DEFAULT 'GIT' CHECK(ownership_mode IN ('GIT','READ_ONLY')),
 created_at timestamptz NOT NULL DEFAULT now(),
 FOREIGN KEY(installation_id,tenant_id) REFERENCES github_installations(id,tenant_id),
 UNIQUE(tenant_id,github_repository_id), UNIQUE(id,tenant_id)
);
CREATE TABLE IF NOT EXISTS github_workflow_registry (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id uuid NOT NULL REFERENCES tenants(id),
 repository_id uuid NOT NULL, workflow_path text NOT NULL, purpose text NOT NULL
 CHECK(purpose IN ('DATABRICKS_DEPLOY','RELEASE_PROMOTION','TERRAFORM_PLAN','TERRAFORM_APPLY','VALIDATION')),
 allowed_refs jsonb NOT NULL DEFAULT '[]'::jsonb,
 input_schema jsonb NOT NULL DEFAULT '{}'::jsonb,
 approval_handshake_verified boolean NOT NULL DEFAULT false,
 enabled boolean NOT NULL DEFAULT false, created_at timestamptz NOT NULL DEFAULT now(),
 FOREIGN KEY(repository_id,tenant_id) REFERENCES github_repositories(id,tenant_id),
 UNIQUE(repository_id,workflow_path,purpose)
);
CREATE TABLE IF NOT EXISTS github_webhook_deliveries (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id uuid NOT NULL REFERENCES tenants(id),
 installation_id uuid, delivery_guid text NOT NULL, event_name text NOT NULL,
 action_name text, received_at timestamptz NOT NULL DEFAULT now(),
 signature_valid boolean NOT NULL, status text NOT NULL DEFAULT 'RECEIVED',
 retry_count integer NOT NULL DEFAULT 0, payload_digest text NOT NULL,
 error_code text, UNIQUE(delivery_guid)
);
CREATE INDEX IF NOT EXISTS ix_github_webhooks_status ON github_webhook_deliveries(status,received_at);
CREATE TABLE IF NOT EXISTS github_workflow_runs (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id uuid NOT NULL REFERENCES tenants(id),
 workflow_registry_id uuid NOT NULL REFERENCES github_workflow_registry(id),
 external_run_id bigint, commit_sha text NOT NULL, environment_key text,
 deployment_run_id uuid, status text NOT NULL, conclusion text,
 html_url text, started_at timestamptz, finished_at timestamptz,
 created_at timestamptz NOT NULL DEFAULT now(), UNIQUE(workflow_registry_id,external_run_id)
);
```

**Security note:** `secret_ref` is a locator to managed secret storage, never raw key material. Validate `html_url` host before rendering; avoid arbitrary URL redirects. Add composite tenant FKs to workflow/run records during migration hardening.

## 6. Error handling and policy

Support missing installation permissions, repo moved/removed, expired token, rate limiting, invalid signature, branch protected, workflow disabled, workflow dispatch not permitted, missing OIDC trust, run timeout, artifact mismatch, untrusted Terraform workflow. Display actionable remediation without leaking secrets. Require `github.integrations.manage` for connection administration and `github.repositories.read` for browsing. High-risk disconnects may require policy approval.

## 7. Tests and acceptance

- GitHub App installation callback nonce, wrong tenant, duplicate install, permissions mismatch, revoked installation.
- Webhook HMAC verification over raw body, malformed signature, replay delivery, duplicate/out-of-order events, oversized payload.
- Workflow allowlist, immutable SHA, branch protection, idempotent dispatch, status reconciliation, rate-limit backoff.
- Terraform external pipeline blocked without approved plan/apply contract; secrets never returned to UI/logs.
- **Done when:** admins can securely connect/maintain GitHub installations and approved repos/workflows, Git-enabled projects can use them, events reconcile, and GitHub/Terraform operations remain gated by DeployPactAI policies and external controls.

## 8. Coding-agent deliverables

Build administration page, GitHub App callback and webhook integration, token broker, registries, migrations, background reconciliation, audit/notification events, tests, configuration/runbook. Avoid duplicating CI/CD operational pages.
