# ADMIN-02 — Approvals | Implementation Specification

**Product:** JadeOrbit DeployPactAI | **Navigation:** Administration → Approvals; top-bar approval inbox shortcut | **Scope:** Complete production feature

> **Coding-agent instruction:** Integrate with existing project, plan, release, GitHub, Terraform and audit models. Inspect existing Lakebase schema first; adapt DDL rather than creating duplicate approval tables. The approval decision is an authorization **gate**, not proof that GitHub, Terraform or Databricks executed successfully.

## 1. Goal and scope

Build a centralized, tenant-scoped approval workflow for **Direct Deployment**, **Git-Enabled Deployment**, **Release Promotion** (including ML model alias/serving promotion), **Workspace Synchronization**, **Terraform plan/apply**, **rollback/recovery**, and privileged configuration changes where required. Each approval is bound to a specific **immutable action and plan/artifact hash**, environment/target, policy version, requester and evidence snapshot. Approvals expire or invalidate when material input changes.

## 2. Page layout and tabs

- **My Inbox:** actionable requests assigned to current user/eligible group; filters by project, type, target environment, risk, due date, status; badges and SLA indicators.
- **All Requests:** scoped searchable table of pending/approved/rejected/expired/cancelled/invalidated requests; multi-target and multi-stage grouping; pagination and export.
- **Request Details:** project, owner/requester, operation type, source/target workspace, target environment, asset list, immutable plan hash, diff summary, risk/policy findings, test evidence, artifact/commit/model version, Terraform sanitized plan, rollback feasibility, requested window, prior decisions and activity timeline.
- **Approval Rules:** *read-only deep-link* to Deployment Policies for authoring rules; show which rule created the gate.
- **Delegations:** temporary scoped delegation with expiry, no privilege escalation, and delegated decision provenance; configurable only if organizational policy permits.
- **Decision History:** searchable decision trail with actor, timestamp, comment, policy version, plan hash, exported evidence.
- Top-bar notifications link to filtered inbox; project/run detail links to same request record.

## 3. Functional rules

1. Deterministic policy engine creates gates from target environment, change class, risk, Terraform action, release stage, ML promotion, delete/sync/rollback and user scope. Frontend cannot bypass gates.
2. Support one-step and multi-step approval chains, **N-of-M quorum**, sequential or parallel steps, group eligibility, distinct approvers, deadlines and escalation routing. Initial configuration may use common policy templates, but engine supports full target scope.
3. Enforce separation of duties: requester cannot approve own request when rule requires it; same user cannot satisfy two distinct-approver slots; no approval of own Terraform apply/production rollback where policy prohibits it.
4. Bind request to `subject_type`, `subject_id`, target scope, `plan_digest`, `artifact_digest/commit_sha` when relevant, `policy_version`, and immutable evidence references. Do not expose raw secret values in evidence.
5. **Recheck** at decision and execution: current identity/role eligibility, policy revision, plan freshness, source version, target state, approval expiry and window. On change, invalidate and request a new approval; never silently reuse old approval.
6. Decision actions: Approve, Reject (comment mandatory), Request Changes (returns to requester/new plan), Cancel (requester/admin), Delegate (if enabled), Escalate, View Evidence. Use optimistic locking to prevent double decisions.
7. Multiple targets have independent approval gates; QA approval must not automatically authorize PROD. Release stage gates cannot be skipped. Terraform **plan approval must be bound to exact plan artifact** used for apply.
8. Notification events for created, assigned, reminded, escalated, decided, invalidated, expired; use existing notification service with idempotency.
9. A denied or expired request blocks execution; already-running work is governed by explicit cancellation/compensation policy, not automatically undone.
10. Support approval evidence exports with audit log; no bulk approve for high-risk/production by default; if enabled, require per-request evaluation.

## 4. State machine

`REQUESTED → PENDING → APPROVED | REJECTED | CHANGES_REQUESTED | EXPIRED | CANCELLED | INVALIDATED`; approval steps: `PENDING → APPROVED | REJECTED | SKIPPED_BY_POLICY | EXPIRED`. A request is `APPROVED` only after all required steps/quorum pass. Any rejection follows configured stop/escalation behavior; default reject request. Transitions must be transactional and idempotent.

## 5. Backend services and integrations

Implement `approval_request_service`, `approval_policy_resolver`, `eligibility_evaluator`, `decision_service`, `expiry_escalation_worker`, `approval_gate_checker`. At deployment execution boundary require a server-side **gate token/reference** tied to immutable plan digest and current policy evaluation; do not rely on frontend `approved=true`. Use durable outbox for notifications. Correlate `request_id`, `plan_id`, `deployment_run_id`, `github_workflow_run_id`, `terraform_run_id` where applicable. When triggering external GitHub Actions or customer Terraform pipeline, ensure a verifiable plan→approval→apply handshake; **if the external pipeline cannot enforce it, disable automated apply for that integration**.

## 6. Lakebase PostgreSQL reference DDL

Assumes `tenants`, `app_users` and project/plan tables already exist; keep polymorphic `subject_id` validated by application and tenant-scoped lookup. Never store credentials or unredacted plan output.

```sql
CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE TABLE IF NOT EXISTS approval_requests (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id uuid NOT NULL REFERENCES tenants(id),
 subject_type text NOT NULL CHECK(subject_type IN
 ('DEPLOYMENT','RELEASE_PROMOTION','WORKSPACE_SYNC','TERRAFORM_APPLY','ROLLBACK','CONFIG_CHANGE')),
 subject_id uuid NOT NULL, project_id uuid, target_workspace_id uuid, environment_key text,
 requester_id uuid NOT NULL, status text NOT NULL DEFAULT 'PENDING' CHECK(status IN
 ('PENDING','APPROVED','REJECTED','CHANGES_REQUESTED','EXPIRED','CANCELLED','INVALIDATED')),
 plan_digest text NOT NULL, artifact_digest text, policy_id uuid, policy_version integer NOT NULL,
 evidence_manifest jsonb NOT NULL DEFAULT '{}'::jsonb,
 requested_at timestamptz NOT NULL DEFAULT now(), expires_at timestamptz,
 decided_at timestamptz, version integer NOT NULL DEFAULT 1,
 UNIQUE(tenant_id,id)
);
CREATE INDEX IF NOT EXISTS ix_approvals_inbox ON approval_requests(tenant_id,status,requested_at DESC);
CREATE TABLE IF NOT EXISTS approval_steps (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), request_id uuid NOT NULL REFERENCES approval_requests(id),
 step_number integer NOT NULL, mode text NOT NULL CHECK(mode IN ('SEQUENTIAL','PARALLEL')),
 required_count integer NOT NULL DEFAULT 1 CHECK(required_count > 0),
 eligible_role_code text, eligible_group_ref text,
 status text NOT NULL DEFAULT 'PENDING' CHECK(status IN ('PENDING','APPROVED','REJECTED','EXPIRED')),
 due_at timestamptz, UNIQUE(request_id,step_number)
);
CREATE TABLE IF NOT EXISTS approval_decisions (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), step_id uuid NOT NULL REFERENCES approval_steps(id),
 approver_id uuid NOT NULL, decision text NOT NULL CHECK(decision IN ('APPROVE','REJECT','REQUEST_CHANGES')),
 comment text, delegated_from uuid, decided_at timestamptz NOT NULL DEFAULT now(),
 idempotency_key text NOT NULL, UNIQUE(step_id,idempotency_key)
);
CREATE TABLE IF NOT EXISTS approval_delegations (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id uuid NOT NULL REFERENCES tenants(id),
 delegator_id uuid NOT NULL, delegate_id uuid NOT NULL,
 scope jsonb NOT NULL DEFAULT '{}'::jsonb,
 starts_at timestamptz NOT NULL, expires_at timestamptz NOT NULL,
 revoked_at timestamptz, CHECK(delegator_id <> delegate_id), CHECK(expires_at > starts_at)
);
```

**DB hardening:** add composite tenant FKs for referenced users/projects/targets where supported, transactional unique-decision/quorum enforcement, indexes on step eligibility, and immutable decision records. Do not update historical decisions; append superseding request on new plan. Plan digests must use canonical normalized serialization and cryptographic hashing.

## 7. Frontend interactions

Use shared table/filter and detail drawer; display actionable buttons **only if server declares current user eligible**, but enforce on backend regardless. Render diff/evidence with sanitized summaries, provenance links, approval step progress and explicit target labels. Require confirmation for PROD, destructive sync, Terraform apply and rollback. Provide rejection reason, concurrency conflict and stale-plan explanations. Accessible keyboard navigation and responsive design.

## 8. Tests and acceptance criteria

- Unit: rule matching, N-of-M, sequential steps, requester conflict, distinct approvers, delegation, expiry, stale digest, policy changes.
- Integration: create approval from deployment plan, approve QA not PROD, Terraform plan hash binding, GitHub gate, ML alias promotion, rollback; event notifications; concurrent double-click; denied cross-tenant request.
- E2E: approver inbox→evidence→approve→execution eligible; reject blocks run; plan mutation invalidates request.
- **Done when:** no protected operation executes without matching current approved request, all decisions are audited, multi-stage approvals work, and external pipeline gates cannot be bypassed by the app.

## 9. Coding-agent deliverables

Build page tabs and approval detail, typed client, services/state transitions, background expiry job, additive migrations, policy integration, notification/audit events, unit/integration/E2E tests, and operational notes. Reuse policy definitions from ADMIN-04; do not invent a second policy engine.
