# ADMIN-04 — Deployment Policies | Implementation Specification

**Product:** JadeOrbit DeployPactAI | **Navigation:** Administration → Deployment Policies | **Scope:** Complete production feature

> **Coding-agent instruction:** Implement **one deterministic, versioned policy engine** reused by all project types, approvals, release promotion, Terraform and rollback. AI may explain policy results but never decide authorization. Inspect current policy code and DB migrations; add compatible schema changes, not duplicate engines. Do not execute arbitrary user-provided Python/JavaScript as a policy expression.

## 1. Objective

Allow administrators to configure enterprise deployment guardrails consistently across **Direct Deployment, Git-Enabled Deployment, Release Promotion (including ML), Workspace Synchronization, Terraform execution, rollback and recovery**. Policies are evaluated at planning, approval and execution, and their exact versions become part of immutable deployment evidence.

## 2. Page tabs

- **Policy Catalog:** searchable policy cards/table with name, category, scope, priority, status, version, owner, last published, applicability, enforcement level and recent violations.
- **Policy Editor:** create draft from template or existing policy; visual conditions and effects, scope selector, exception handling, description, change reason, JSON preview (safe schema, not executable code).
- **Templates:** production approval, four-eyes, destructive sync, Terraform apply, rollback, change window, protected resources, approved target workspaces, Git branch/SHA provenance, model validation and serving gates, credential/secret handling.
- **Simulation / Test:** dry-run policy against sanitized sample/real deployment plan; show rule matches, evidence, deny/warn/approval requirements, conflict resolution and exact policy versions; never execute resources.
- **Versions & Publishing:** draft/publish/retire, version diff, approval for policy changes, scheduled activation if supported, rollback to prior version as a **new** version.
- **Exceptions:** time-bound, scoped exception requests with reason, approver, expiry and evidence; deny exceptions for non-overridable hard controls (tenant isolation, auth, credential leakage).
- **Violations & Evaluations:** history, linked plans/runs, rule outcomes, reviewer and exports.

## 3. Policy model

Policy scope: tenant, project, workspace, environment, project type, asset type and operation. Inheritance: tenant baseline applies to all; narrower scopes may **tighten** but cannot weaken non-overridable tenant controls. Evaluation outputs `ALLOW`, `WARN`, `REQUIRE_APPROVAL`, `DENY`, plus machine-readable obligations (quorum, tests, change window, permitted runner). If multiple rules match, `DENY` wins; otherwise accumulate all approval/test obligations; `WARN` never overrides `DENY`. Policy revisions require explicit publish and are immutable thereafter.

**Supported deterministic condition inputs:** project type, target environment/workspace/account, source/target classification, asset type/count, resource owner (`DIRECT/GIT/TERRAFORM`), create/update/delete, managed/unmanaged, severity/risk flags computed by rules, unresolved dependencies, target mappings, model version/evaluation evidence, branch/commit, Terraform plan actions/state lock/runner trust, rollback reversibility, user roles, planned execution time, approved change window. Use validated JSON schema or restricted declarative AST; no `eval`.

## 4. Core policy requirements

1. **Production controls:** explicit approval, SoD, minimum approver quorum, mandatory smoke/quality checks, allowed change windows, immutable release artifacts.
2. **Direct deployment:** prevent overwriting unmanaged resources without adoption, require fresh target snapshot and plan hash, protect secret values and Unity Catalog permissions.
3. **GitOps:** require approved repo/workflow, branch protections, commit SHA, successful checks, Git ownership; block out-of-band SDK mutation of Git-owned assets unless approved ownership transfer.
4. **Release promotion:** enforce ordered stages and gates, same immutable artifact/version across stages, mapping validation, test thresholds and approval at each environment.
5. **ML promotion:** registered model version is immutable, required evaluation/lineage/validation evidence, alias/endpoint changes subject to environment gate; validate prior serving config and rollback capability. Do not use legacy MLflow stage assumptions.
6. **Workspace sync:** deletion disabled by default; enforce direction/scope, allowlist, drift ignore rules, loop prevention, no implicit Terraform/Git ownership takeover.
7. **Terraform:** only allowlisted provider/module sources, trusted runners, approved remote state and locking, sanitized plan digest, plan→apply binding, explicit apply approval, never `auto-approve` outside approved gated pipeline. Prevent dual ownership.
8. **Rollback:** new plan, reversibility classification, prior artifact integrity, separate PROD approval, manual recovery evidence for irreversible operations.
9. **Security:** cross-tenant deny, workspace host allowlist, secret redaction, permission checks are hard-coded non-overridable controls, not configurable soft policies.
10. **Exceptions:** scoped and expiring, cannot override hard security invariants; every exception has authorizer and audit trail.
11. **Evaluation freshness:** material change to plan, policy, target observation or artifact invalidates earlier decision and approval.
12. **Policy lifecycle:** drafts can be edited; published versions are immutable; support rollback via republish; export/import validated policy JSON with provenance.

## 5. Backend design

Implement `policy_registry`, `policy_schema_validator`, `policy_compiler`, `policy_evaluator`, `policy_simulator`, `policy_publisher`, `exception_service`. Evaluate **server-side** at `plan creation`, `approval creation/decision`, `pre-execution`, and `each sensitive step` (e.g., delete, Terraform apply, PROD model alias update). Persist snapshot of evaluation input hashes, matched policy versions and obligations. Policies must not trust browser risk score. Provide machine-readable denial codes and human-readable explanations. Cache only immutable published versions, invalidate on publish. Failure to load required policies = **fail closed** for protected operations.

## 6. Lakebase PostgreSQL reference DDL

```sql
CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE TABLE IF NOT EXISTS policy_definitions (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id uuid NOT NULL REFERENCES tenants(id),
 code text NOT NULL, name text NOT NULL, category text NOT NULL,
 scope_type text NOT NULL DEFAULT 'TENANT' CHECK(scope_type IN
 ('TENANT','WORKSPACE','PROJECT','ENVIRONMENT')),
 scope_id uuid, is_hard_control boolean NOT NULL DEFAULT false,
 status text NOT NULL DEFAULT 'ACTIVE' CHECK(status IN ('ACTIVE','RETIRED')),
 created_by uuid NOT NULL, created_at timestamptz NOT NULL DEFAULT now(),
 UNIQUE(tenant_id,code), UNIQUE(id,tenant_id),
 CHECK((scope_type='TENANT' AND scope_id IS NULL) OR (scope_type<>'TENANT' AND scope_id IS NOT NULL))
);
CREATE TABLE IF NOT EXISTS policy_versions (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), policy_id uuid NOT NULL REFERENCES policy_definitions(id),
 version integer NOT NULL CHECK(version > 0),
 state text NOT NULL CHECK(state IN ('DRAFT','PUBLISHED','SUPERSEDED','RETIRED')),
 rule_document jsonb NOT NULL, schema_version integer NOT NULL DEFAULT 1,
 rule_digest text NOT NULL, effective_at timestamptz,
 created_by uuid NOT NULL, published_by uuid, published_at timestamptz,
 created_at timestamptz NOT NULL DEFAULT now(), UNIQUE(policy_id,version)
);
CREATE UNIQUE INDEX IF NOT EXISTS ux_policy_published ON policy_versions(policy_id)
 WHERE state='PUBLISHED';
CREATE TABLE IF NOT EXISTS policy_evaluations (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id uuid NOT NULL REFERENCES tenants(id),
 subject_type text NOT NULL, subject_id uuid NOT NULL, phase text NOT NULL
 CHECK(phase IN ('PLAN','APPROVAL','PRE_EXECUTION','SENSITIVE_STEP','SIMULATION')),
 input_digest text NOT NULL, outcome text NOT NULL
 CHECK(outcome IN ('ALLOW','WARN','REQUIRE_APPROVAL','DENY')),
 matched_versions jsonb NOT NULL DEFAULT '[]'::jsonb,
 obligations jsonb NOT NULL DEFAULT '{}'::jsonb,
 findings jsonb NOT NULL DEFAULT '[]'::jsonb,
 evaluated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_policy_evaluations_subject ON policy_evaluations(tenant_id,subject_type,subject_id,evaluated_at DESC);
CREATE TABLE IF NOT EXISTS policy_exceptions (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id uuid NOT NULL REFERENCES tenants(id),
 policy_id uuid NOT NULL REFERENCES policy_definitions(id),
 scope_type text NOT NULL, scope_id uuid NOT NULL,
 justification text NOT NULL, approved_by uuid NOT NULL,
 valid_from timestamptz NOT NULL, valid_until timestamptz NOT NULL,
 revoked_at timestamptz, created_at timestamptz NOT NULL DEFAULT now(),
 CHECK(valid_until > valid_from)
);
```

**Migration note:** published policy version transitions and immutable published JSON must be protected by service transaction and optionally DB triggers; ensure only one effective published version at a time with staged/scheduled activation rules. Validate exception scope ownership and hard-control non-exemptibility server-side.

## 7. Example declarative policy (illustrative)

```json
{
  "schema_version": 1,
  "when": {"all": [
    {"field": "target.environment", "op": "eq", "value": "PROD"},
    {"field": "operation", "op": "in", "value": ["DEPLOY", "PROMOTE", "ROLLBACK", "TERRAFORM_APPLY"]}
  ]},
  "effect": "REQUIRE_APPROVAL",
  "obligations": {"minimum_distinct_approvers": 2, "requester_cannot_approve": true,
    "require_fresh_plan": true, "require_verification": true}
}
```

## 8. Testing and acceptance

- Verify tenant baseline cannot be weakened, deny precedence, multi-policy obligation accumulation, exception expiry, invalid policy schema, simulation without side effects, published-version immutability.
- End-to-end: PROD direct deployment, Git commit protection, ML stage promotion, destructive sync, Terraform apply, rollback; stale approval after policy change; hard control always blocks.
- **Done when:** every sensitive operation has a deterministic policy result and traceable version, admins can simulate/publish/retire safely, and approvals follow the same policy engine.

## 9. Coding-agent deliverables

Build policy catalog/editor/simulator/history/exception UI, typed policy contracts, versioned rule engine, migrations, reusable evaluation middleware, audit events, tests, policy seed templates and operator docs. Avoid arbitrary code execution in policy rules.
