# DEPLOY-04 — Rollback & Recovery | Complete Coding-Agent Specification

**Navigation:** Deployments → Rollback & Recovery

## Coding-agent implementation contract

**Product:** JadeOrbit DeployPactAI. **Module:** Deployments. **Scope:** full enterprise production functionality, not a prototype.

Before writing code, read `PROJECT_REQUIREMENTS.md`, `PROJECT_ARCHITECTURE.md`, and the existing specifications for Projects, Workspaces, Administration and CI/CD. Inspect actual frontend routes, React/TypeScript components, FastAPI modules, Databricks SDK client factory, Lakebase PostgreSQL models, Alembic history, approval/policy/audit services, worker orchestration and artifact storage. **Extend existing infrastructure rather than duplicating it.**

There are exactly **four project types**: Direct Deployment, Git-Enabled Deployment, Release Promotion (including ML model promotion), and Workspace Synchronization. Terraform is an execution/integration capability, not another project type. The application is already connected to Databricks; preserve current behavior and use additive migrations.

Technology baseline: React + TypeScript, FastAPI/Python, Databricks Apps, Databricks SDK/REST APIs, Databricks Jobs or durable background execution, Lakebase PostgreSQL for operational metadata, UC Volumes/approved object storage for immutable manifests and snapshots, GitHub App/GitHub Actions and Databricks Asset Bundles for GitOps, Terraform via existing CI pipelines or isolated approved runners.

**Non-negotiable rules:** tenant-isolated and server-authorized operations; least-privilege source/target credentials; secrets resolved server-side and never returned to browser; policy + approval enforcement at execution time; immutable plan hashes; idempotent dispatch; concurrency/resource ownership locks; per-resource execution evidence; auditable state transitions; safe retries; no assumption that all Databricks resource types are exportable or reversible. A successful API response is not proof that deployment verification succeeded.

All DDL is **reference PostgreSQL**, to be adapted through Alembic after checking existing tables (`projects`, `deployment_plans`, `deployment_runs`, `deployment_steps`, `approvals`, `audit_events`, `resource_bindings`, `workspaces`, `asset_manifests`, `pipeline_runs`). Add composite tenant-consistent FKs, indexes, uniqueness and row-level access controls where consistent with the existing application. Do not execute `CREATE TABLE` blindly.

Deliver functional frontend, typed backend contracts, persistence/migrations, adapters, workers, security checks, observability, automated unit/integration/end-to-end tests, and operational documentation. Implement loading, empty, error, blocked and permission-denied states; avoid mocked success and placeholder-only pages.

## 1. Purpose

Provide a safe, policy-governed control plane for **reversing eligible deployments, restoring known-good configurations, retrying/reconciling failed steps and coordinating manual recovery**. Rollback is a **new, audited change** using the same planner, approval and execution services; it must never pretend every Databricks operation is reversible.

## 2. Page structure

- **Recovery dashboard:** failed/partial deployments, recently changed PROD resources, rollback-ready candidates, active recovery cases, blocked/manual-only cases, current target health and incident alerts.
- **Eligible deployments:** run ID, project, target, execution mode, last known good version, failed resources, rollback feasibility (`FULL`, `PARTIAL`, `MANUAL`, `NOT_SUPPORTED`), pre-change snapshot availability, current drift and ownership.
- **Recovery case detail:** Incident Summary; Impacted Assets; Original Plan & History; Before/After Evidence; Recovery Options; Recovery Plan; Approvals; Execution Timeline; Verification; Audit.
- **Recovery options:** restore previous managed configuration, redeploy previous immutable bundle/commit, restore prior ML alias/serving config, create approved Terraform corrective plan, resume safe failed steps, reconcile state, manually mark external recovery with evidence.
- **Rollback wizard:** choose failed/successful deployment → inspect target current state → choose target restore point → identify dependencies/irreversible changes → generate recovery plan → policy/risk/approval → execute → verify → close case.
- **Emergency controls:** break-glass request (if Administration enables) with justification, limited scope, time-bound privileged approval and enhanced audit; never bypass identity, tenant isolation or provider-side protections.
- **Post-recovery:** outcome report, unresolved resources, follow-up tasks, links to new run and original deployment, notifications, incident notes and evidence export.

## 3. Recovery classification and resource-specific behavior

| Execution/resource | Supported recovery strategy | Critical limitations |
|---|---|---|
| Notebook/workspace files | Reimport previous immutable definition where captured | Does not undo effects of notebook execution |
| Jobs/workflows | Restore previous settings, tasks and schedules via adapter | Job runs and external side effects cannot be undone |
| Lakeflow pipelines | Restore eligible configuration and redeploy | Processed data/state may require manual remediation |
| SQL queries/dashboards | Restore previous supported definitions/config | Sharing/permissions and unsupported APIs may limit restore |
| Unity Catalog metadata/grants | Reapply prior supported metadata/grants under explicit approval | Dropped data, external storage and irreversible operations need separate backup/recovery |
| SQL warehouses/compute policies | Recreate/restore supported configuration | Active sessions and compute runtime state not reversible |
| GitOps/Bundle | Deploy previous verified commit/artifact via pipeline | Must check target drift and current ownership |
| Terraform | Commit/revert desired configuration and run a **new plan/approval/apply** in same remote state backend | Never rewind state file blindly; `destroy` is not generic rollback; partial apply requires reconciliation |
| MLflow models/aliases | Repoint alias to prior verified version or promote previous model artifact | Verify target registry, artifact access and permissions |
| Model serving | Restore prior endpoint/model routing configuration and verify | Live traffic effects cannot be retroactively reversed |
| Workspace Sync | Restore captured target configuration for reversible managed assets | No implicit restoration of table data or deleted secrets |
| Secrets | Re-provision through approved secret system | Secret values must not be backed up/exposed by DeployPactAI |

## 4. Functional requirements

1. Automatically classify rollback feasibility per resource during planning and execution, based on adapter capability, pre-change snapshot, resource ownership, dependency state and irreversible side effects.
2. A rollback **cannot be launched from history by simply repeating the original plan backward**. It requires a fresh target-state read, new impact/diff, risk evaluation, policy and approvals.
3. Store immutable before/after configuration snapshots where supported; encrypt and control access to artifact refs. Never store secret values or raw Terraform state in Lakebase.
4. Offer three distinct actions: **Rollback** (restore prior desired state), **Retry/Resume** (complete safe pending steps with idempotency), **Reconcile** (compare observed target to desired state and propose a plan). Clearly explain differences.
5. If the original deployment changed resources after the snapshot or another owner modified them, block blind overwrite and require explicit conflict resolution/adoption.
6. Enforce same target/resource locks as regular deployment; prevent recovery colliding with active deployment, release promotion or Terraform apply.
7. Require elevated policy/approval for production, destructive actions, privileged grant changes, Terraform corrective apply, model serving cutover and emergency operations. Separation of duties applies.
8. For a partial multi-target release, select specific affected targets and show global release impact; do not rollback successful targets automatically unless user explicitly selects and policy permits.
9. Preserve Git and Terraform ownership. Git-owned resources recover through Git workflow; Terraform-owned resources recover through Terraform pipeline/runner with existing state backend and locks.
10. For Terraform failed/partial apply, first refresh/reconcile actual state and remote lock status; build a new plan against desired prior configuration. A saved stale plan is not reusable for rollback.
11. For ML promotion, capture model version, alias and serving config prior to change. Validate target artifact availability and run smoke/health tests after reverting.
12. Recovery can be partial or manual. Show exact unresolved items, compensating steps and required human actions; do not label `ROLLED_BACK` until verification passes.
13. If backups are missing or the resource is nonreversible, mark `MANUAL`/`NOT_SUPPORTED`; do not offer a misleading one-click button.
14. Support best-effort cancellation of recovery, but reconcile any changes already applied before showing final state.
15. Implement durable recovery jobs with step checkpoints, idempotency, bounded retries, provider reconciliation, timeouts and structured error classification.
16. Emergency break-glass must have a configured policy, authorized initiator, short-lived scope, explicit reason, secondary review or documented exception, alerts and immutable audit.
17. Recovery plans and approvals bind to exact target fingerprint, source restore artifact digest, policy revision and plan hash; changes require replan/reapproval.
18. After recovery, verify each resource state, dependencies, application health where configured and target resource bindings; preserve original deployment and new recovery history.
19. AI can summarize incident causes or suggest recovery options using sanitized evidence; it must not autonomously approve or execute recovery.
20. Allow recovery cases to be created for externally resolved incidents; require evidence, operator identity and clear `EXTERNAL_MANUAL` outcome, not fabricated automated execution.

## 5. Backend workflow and services

`recovery_case_service` → `rollback_eligibility_analyzer` → `prechange_snapshot_resolver` → `current_target_reader` → `ownership_and_drift_guard` → `recovery_plan_builder` → `policy_engine` → `approval_service` → `deployment_executor`/provider pipeline → `recovery_verifier` → `audit_service`.

Recovery state machine:
`OPEN → ASSESSING → PLAN_READY / MANUAL_REQUIRED / BLOCKED → AWAITING_APPROVAL → APPROVED → QUEUED → RUNNING → VERIFYING → RECOVERED / PARTIAL / FAILED`.
Additional `CANCEL_REQUESTED`, `CANCELLED`, `EXTERNAL_MANUAL`, `CLOSED`.

- Recovery executor reuses normal resource adapters and run/step history, with operation-specific compensating actions.
- Rollback to previous Git commit is a **new deployment**. Terraform correction is a **new plan/apply**. ML alias revert and endpoint config restore are separate verified steps.
- Use optimistic state transitions, per-resource distributed locks, outbox dispatch and reconciliation after worker interruption.
- Do not equate rollback eligibility with guaranteed success.

## 6. Reference Lakebase PostgreSQL DDL

```sql
CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE TABLE IF NOT EXISTS deployment_recovery_cases (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 tenant_id uuid NOT NULL REFERENCES tenants(id),
 original_deployment_run_id uuid NOT NULL, -- FK to existing deployment_runs
 project_id uuid NOT NULL, -- FK to existing projects
 target_workspace_id uuid NOT NULL REFERENCES workspaces(id),
 requested_by uuid REFERENCES app_users(id),
 recovery_type text NOT NULL CHECK(recovery_type IN
  ('ROLLBACK','RETRY_RESUME','RECONCILE','EXTERNAL_MANUAL')),
 status text NOT NULL DEFAULT 'OPEN' CHECK(status IN
  ('OPEN','ASSESSING','PLAN_READY','MANUAL_REQUIRED','BLOCKED',
   'AWAITING_APPROVAL','APPROVED','QUEUED','RUNNING','VERIFYING',
   'RECOVERED','PARTIAL','FAILED','CANCEL_REQUESTED','CANCELLED',
   'EXTERNAL_MANUAL','CLOSED')),
 reason text NOT NULL,
 severity text CHECK(severity IN ('LOW','MEDIUM','HIGH','CRITICAL')),
 rollback_eligibility text NOT NULL DEFAULT 'MANUAL'
  CHECK(rollback_eligibility IN ('FULL','PARTIAL','MANUAL','NOT_SUPPORTED')),
 recovery_plan_id uuid, -- FK to existing deployment_plans
 recovery_run_id uuid,  -- FK to existing deployment_runs
 approval_request_id uuid, -- FK to existing approval_requests
 created_at timestamptz NOT NULL DEFAULT now(),
 updated_at timestamptz NOT NULL DEFAULT now(),
 closed_at timestamptz,
 UNIQUE(id,tenant_id)
);
CREATE TABLE IF NOT EXISTS deployment_recovery_items (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 tenant_id uuid NOT NULL REFERENCES tenants(id),
 recovery_case_id uuid NOT NULL,
 asset_type text NOT NULL,
 logical_key text NOT NULL,
 before_snapshot_ref text,
 desired_restore_digest char(64),
 observed_target_digest char(64),
 eligibility text NOT NULL CHECK(eligibility IN
  ('FULL','PARTIAL','MANUAL','NOT_SUPPORTED')),
 proposed_action text NOT NULL,
 status text NOT NULL DEFAULT 'PENDING' CHECK(status IN
  ('PENDING','BLOCKED','RUNNING','RESTORED','PARTIAL','FAILED','MANUAL')),
 limitation_reason text,
 verification jsonb NOT NULL DEFAULT '{}'::jsonb,
 FOREIGN KEY(recovery_case_id,tenant_id)
  REFERENCES deployment_recovery_cases(id,tenant_id),
 UNIQUE(recovery_case_id,asset_type,logical_key)
);
CREATE TABLE IF NOT EXISTS deployment_recovery_evidence (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 tenant_id uuid NOT NULL REFERENCES tenants(id),
 recovery_case_id uuid NOT NULL,
 evidence_type text NOT NULL CHECK(evidence_type IN
  ('SNAPSHOT','PLAN','APPROVAL','LOG','VERIFICATION','MANUAL_ACTION','REPORT')),
 artifact_ref text NOT NULL,
 digest_sha256 char(64),
 created_by uuid REFERENCES app_users(id),
 created_at timestamptz NOT NULL DEFAULT now(),
 FOREIGN KEY(recovery_case_id,tenant_id)
  REFERENCES deployment_recovery_cases(id,tenant_id)
);
CREATE TABLE IF NOT EXISTS deployment_recovery_events (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 tenant_id uuid NOT NULL REFERENCES tenants(id),
 recovery_case_id uuid NOT NULL,
 event_seq bigint NOT NULL CHECK(event_seq > 0),
 event_type text NOT NULL,
 event_data jsonb NOT NULL DEFAULT '{}'::jsonb,
 occurred_at timestamptz NOT NULL DEFAULT now(),
 FOREIGN KEY(recovery_case_id,tenant_id)
  REFERENCES deployment_recovery_cases(id,tenant_id),
 UNIQUE(recovery_case_id,event_seq)
);
CREATE INDEX IF NOT EXISTS ix_recovery_recent
 ON deployment_recovery_cases(tenant_id,status,created_at DESC);
```

**Migration hardening:** attach composite tenant FKs to canonical project/run/plan/approval tables; avoid copying secrets into evidence JSON; enforce append-only recovery events and durable immutable snapshot references.

## 7. Permissions, audit, observability and acceptance

Permissions: `recovery.view`, `recovery.assess`, `recovery.plan`, `recovery.request`, `recovery.approve`, `recovery.execute`, `recovery.emergency`, `recovery.close`, `recovery.export`. Validate source run and target scope.

Audit all assessments, snapshots accessed, options selected, approvals, emergency overrides, execution steps, manual evidence, exports and closure. Metrics: time-to-assess, recovery time, partial/failed recoveries, unavailable snapshots, drift conflicts, approval wait, recovery verification success.

**Acceptance tests:** reversible notebook/job settings restore; nonreversible data change blocks one-click rollback; PROD approval; stale target drift blocks; Terraform correction uses new plan/apply and same state backend; Git rollback uses previous immutable artifact via pipeline; ML alias/serving revert; partial multi-target recovery; retry idempotency; cancellation reconciliation; manual-only case with evidence; immutable original history; cross-tenant denial.
