# DEPLOY-02 — Deployment Plans | Complete Coding-Agent Specification

**Navigation:** Deployments → Deployment Plans

## Coding-agent implementation contract

**Product:** JadeOrbit DeployPactAI. **Module:** Deployments. **Scope:** full enterprise production functionality, not a prototype.

Before writing code, read `PROJECT_REQUIREMENTS.md`, `PROJECT_ARCHITECTURE.md`, and the existing specifications for Projects, Workspaces, Administration and CI/CD. Inspect actual frontend routes, React/TypeScript components, FastAPI modules, Databricks SDK client factory, Lakebase PostgreSQL models, Alembic history, approval/policy/audit services, worker orchestration and artifact storage. **Extend existing infrastructure rather than duplicating it.**

There are exactly **four project types**: Direct Deployment, Git-Enabled Deployment, Release Promotion (including ML model promotion), and Workspace Synchronization. Terraform is an execution/integration capability, not another project type. The application is already connected to Databricks; preserve current behavior and use additive migrations.

Technology baseline: React + TypeScript, FastAPI/Python, Databricks Apps, Databricks SDK/REST APIs, Databricks Jobs or durable background execution, Lakebase PostgreSQL for operational metadata, UC Volumes/approved object storage for immutable manifests and snapshots, GitHub App/GitHub Actions and Databricks Asset Bundles for GitOps, Terraform via existing CI pipelines or isolated approved runners.

**Non-negotiable rules:** tenant-isolated and server-authorized operations; least-privilege source/target credentials; secrets resolved server-side and never returned to browser; policy + approval enforcement at execution time; immutable plan hashes; idempotent dispatch; concurrency/resource ownership locks; per-resource execution evidence; auditable state transitions; safe retries; no assumption that all Databricks resource types are exportable or reversible. A successful API response is not proof that deployment verification succeeded.

All DDL is **reference PostgreSQL**, to be adapted through Alembic after checking existing tables (`projects`, `deployment_plans`, `deployment_runs`, `deployment_steps`, `approvals`, `audit_events`, `resource_bindings`, `workspaces`, `asset_manifests`, `pipeline_runs`). Add composite tenant-consistent FKs, indexes, uniqueness and row-level access controls where consistent with the existing application. Do not execute `CREATE TABLE` blindly.

Deliver functional frontend, typed backend contracts, persistence/migrations, adapters, workers, security checks, observability, automated unit/integration/end-to-end tests, and operational documentation. Implement loading, empty, error, blocked and permission-denied states; avoid mocked success and placeholder-only pages.

## 1. Purpose

Build the authoritative **plan catalog, detailed impact preview, versioned approval gate and execution readiness interface**. A plan is a reproducible, immutable, target-specific declaration of intended changes; it is not an execution record. Every deployment—including Direct, GitOps, Release Promotion and Sync—must have a traceable plan or explicit provider-native plan reference.

## 2. Page sections

- **Plans directory:** plan ID/name, project, type, source version, target workspace/environment, execution mode, change counts, risk, creator, created/expiry time, status, approval status, policy result, latest validation, linked run.
- **Search/filter:** project, environment, target, plan status, approval, risk, execution mode, creator, time range, source commit, expired/stale.
- **Plan details tabs:** Summary; Changes; Dependencies; Environment Mappings; Preconditions; Policies & Approvals; Execution Readiness; Artifact/Evidence; History & Revisions.
- **Change explorer:** hierarchical by target/resource, action `CREATE/UPDATE/NOOP/SKIP/ADOPT/BLOCKED/DELETE_REQUESTED`, before/after sanitized diff, resource owner, dependency edges, rollback eligibility and reasons.
- **Plan actions:** Generate/Replan, Validate, Compare Revisions, Request Approval, Approve/Reject (authorized approvers only), Execute, Clone to new draft, Export redacted report, Archive/Expire; never mutate an approved immutable plan.
- **Plan visualizations:** dependency DAG, target mapping summary, risk matrix, warnings/blockers, execution order, estimated duration only if grounded in historical metrics, no fabricated cost estimate.
- **Terraform view:** plan metadata, sanitized change summary, saved plan artifact digest/reference, state backend/workspace, lock/runner readiness, policy results. Never expose raw Terraform state or secret-bearing plan files.
- **GitOps view:** pinned commit SHA, workflow path, bundle target, validation evidence, protected branch and OIDC readiness.

## 3. Planning requirements

1. Resolve exact project revision, asset manifest or Git SHA, target workspace, mapping revision, dependency closure, execution adapter and policy version.
2. Generate **one immutable plan per target** and group related plans via launch/release ID. Each plan has deterministic canonical JSON and SHA-256 digest; exclude volatile timestamps from digest.
3. Compare source desired state to current target actual state through type-specific adapters. Show create/update/no-op and conflicts; missing permissions or unsupported API yields `UNKNOWN/BLOCKED`, not a guessed action.
4. Resolve target resource IDs through resource bindings; unmanaged target resources require explicit adoption and policy approval. Block cross-owner mutation of Git/Terraform-managed resources.
5. Capture precondition fingerprints, capability snapshots, connection/auth health, target quota and identity checks. Assign validation TTL and expiration.
6. Apply mapping rules to each resource; show unresolved required mappings and unsupported transformations as blockers. Shared UC metastore resources need explicit collision protection.
7. Compute dependency graph and stable execution order. Detect cycles, missing assets, external dependencies and destructive actions; mark manual prerequisites.
8. Support policy evaluation for allowed asset types, source/target environments, production gates, maintenance windows, identity constraints, conflict policies, approval thresholds, model evaluation and Terraform safety.
9. Risk scoring must be deterministic, configurable and explainable; default to high risk for deletions, grants, prod changes, shared UC objects, Terraform destructive plan and serving cutovers.
10. Approvals bind to **plan digest + target + action + policy revision**. A replan creates a new immutable revision and invalidates previous approval if material content changes.
11. `PLAN_READY` is distinct from `APPROVED` and `EXECUTABLE`. Recheck policy, approval validity, target drift, credentials, lock and maintenance window immediately before execution.
12. Plan preview must never mutate destination; only the executor may perform writes. Terraform plan uses isolated runner/approved pipeline, state lock as needed, and approved saved-plan digest; ensure plan cannot be substituted between approval and apply.
13. Preserve old plans and decisions for audit, even after expiration or project archive.
14. GitHub Actions plans may contain provider-native validation artifacts rather than a perfect Databricks resource diff. Label evidence completeness and do not claim unsupported previews.
15. ML model promotion plan includes model/version/alias, target registry/artifact access, serving endpoint configuration and evaluation gates; no unsupported automatic cross-metastore promotion claims.
16. Rollback feasibility is computed per asset, not assumed globally. Non-reversible operations and required backups must be explicit.
17. Plan export contains sanitized manifest/diff, hashes, policy and approval evidence; redact source secrets, notebook credentials and Terraform sensitive outputs.
18. Allow authorized user to mark optional resource exclusions only by creating a **new** plan revision.

## 4. Plan lifecycle and invariants

Suggested states: `DRAFT → GENERATING → READY/WARNINGS/BLOCKED → AWAITING_APPROVAL → APPROVED → QUEUED → EXECUTING → EXECUTED`; also `STALE`, `EXPIRED`, `REJECTED`, `FAILED`, `CANCELLED`. Execution outcome belongs primarily to `deployment_runs`, not overwritten onto historical plan evidence.

- Plan revisions append only. No update to canonical plan JSON after `READY`.
- Approval only on eligible plan and by eligible approver.
- Execution only once per plan/target intent unless explicit new attempt with idempotency and retry rules.
- Plan becomes stale if source, target fingerprint, mapping, policy or relevant capability materially changes.
- Persist plan validation and revalidation results with timestamps and reasons.

## 5. Backend architecture

`plan_builder`, `asset_adapter_registry`, `target_state_reader`, `canonical_diff_engine`, `dependency_resolver`, `mapping_engine`, `resource_binding_service`, `risk_engine`, `policy_engine`, `approval_service`, `plan_digest_service`, `plan_revalidator`, `plan_exporter`.

Pipeline: create request → snapshot source/target → map → diff → dependency order → risk/policy → immutable digest → approval → revalidate → dispatch execution. Use DB transaction/optimistic locking for state transitions and outbox for dispatch.

## 6. Reference Lakebase PostgreSQL DDL

```sql
CREATE EXTENSION IF NOT EXISTS pgcrypto;
-- Extend existing deployment_plans instead of duplicating plan header records.
CREATE TABLE IF NOT EXISTS deployment_plan_revisions (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 tenant_id uuid NOT NULL REFERENCES tenants(id),
 deployment_plan_id uuid NOT NULL, -- FK to existing deployment_plans
 revision integer NOT NULL CHECK(revision > 0),
 canonical_plan jsonb NOT NULL,
 plan_digest char(64) NOT NULL,
 source_digest char(64),
 target_snapshot_digest char(64),
 mapping_revision_ref text,
 policy_revision_ref text,
 risk_level text NOT NULL CHECK(risk_level IN ('LOW','MEDIUM','HIGH','CRITICAL')),
 status text NOT NULL CHECK(status IN
  ('GENERATING','READY','WARNINGS','BLOCKED','STALE','EXPIRED','FAILED')),
 created_by uuid REFERENCES app_users(id),
 created_at timestamptz NOT NULL DEFAULT now(),
 expires_at timestamptz,
 UNIQUE(tenant_id,deployment_plan_id,revision),
 UNIQUE(id,tenant_id)
);
CREATE TABLE IF NOT EXISTS deployment_plan_change_items (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 tenant_id uuid NOT NULL REFERENCES tenants(id),
 plan_revision_id uuid NOT NULL,
 asset_type text NOT NULL,
 logical_key text NOT NULL,
 action text NOT NULL CHECK(action IN
  ('CREATE','UPDATE','NOOP','SKIP','ADOPT','BLOCKED','DELETE_REQUESTED')),
 resource_owner text,
 source_fingerprint char(64),
 target_fingerprint char(64),
 risk_level text,
 diff_summary jsonb NOT NULL DEFAULT '{}'::jsonb,
 rollback_eligibility text,
 execution_order integer,
 FOREIGN KEY(plan_revision_id,tenant_id)
  REFERENCES deployment_plan_revisions(id,tenant_id),
 UNIQUE(plan_revision_id,asset_type,logical_key)
);
CREATE TABLE IF NOT EXISTS deployment_plan_validations (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 tenant_id uuid NOT NULL REFERENCES tenants(id),
 plan_revision_id uuid NOT NULL,
 status text NOT NULL CHECK(status IN ('PASSED','WARNINGS','BLOCKED','FAILED','STALE')),
 checks jsonb NOT NULL DEFAULT '[]'::jsonb,
 observed_target_digest char(64),
 evaluated_at timestamptz NOT NULL DEFAULT now(),
 valid_until timestamptz,
 FOREIGN KEY(plan_revision_id,tenant_id)
  REFERENCES deployment_plan_revisions(id,tenant_id)
);
CREATE TABLE IF NOT EXISTS deployment_plan_approval_links (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 tenant_id uuid NOT NULL REFERENCES tenants(id),
 plan_revision_id uuid NOT NULL,
 approval_request_id uuid NOT NULL, -- FK to existing approval_requests
 approved_plan_digest char(64) NOT NULL,
 FOREIGN KEY(plan_revision_id,tenant_id)
  REFERENCES deployment_plan_revisions(id,tenant_id),
 UNIQUE(tenant_id,plan_revision_id,approval_request_id)
);
CREATE INDEX IF NOT EXISTS ix_plan_revisions_latest
 ON deployment_plan_revisions(tenant_id,deployment_plan_id,revision DESC);
```

**Migration hardening:** add tenant-scoped FKs to `deployment_plans` and approval records; use append-only permissions/triggers for immutable revision content; index status/expiry on existing plan header. Do not store sensitive full Terraform plan JSON in Lakebase.

## 7. Permissions, failures, audit and tests

Permissions: `plan.view`, `plan.create`, `plan.validate`, `plan.request_approval`, `plan.approve`, `plan.execute`, `plan.export`, `plan.archive`. Require target and project scopes.

Audit creation, replan, diff, policy decision, approval, expiry, execution dispatch and export. Metrics: planning duration, blocked reasons, stale plans, approval time, precondition failures, plan-to-run conversion.

**Acceptance tests:** deterministic digest; no destination mutation during preview; required mapping blocks; unauthorized resource blocked; target drift stales plan; plan approval invalid after material revision; Terraform saved plan hash enforced; Git workflow evidence labeled correctly; prod approval; model promotion gate; immutable history; no cross-tenant plan access.
