# DEPLOY-03 — Deployment History | Complete Coding-Agent Specification

**Navigation:** Deployments → Deployment History

## Coding-agent implementation contract

**Product:** JadeOrbit DeployPactAI. **Module:** Deployments. **Scope:** full enterprise production functionality, not a prototype.

Before writing code, read `PROJECT_REQUIREMENTS.md`, `PROJECT_ARCHITECTURE.md`, and the existing specifications for Projects, Workspaces, Administration and CI/CD. Inspect actual frontend routes, React/TypeScript components, FastAPI modules, Databricks SDK client factory, Lakebase PostgreSQL models, Alembic history, approval/policy/audit services, worker orchestration and artifact storage. **Extend existing infrastructure rather than duplicating it.**

There are exactly **four project types**: Direct Deployment, Git-Enabled Deployment, Release Promotion (including ML model promotion), and Workspace Synchronization. Terraform is an execution/integration capability, not another project type. The application is already connected to Databricks; preserve current behavior and use additive migrations.

Technology baseline: React + TypeScript, FastAPI/Python, Databricks Apps, Databricks SDK/REST APIs, Databricks Jobs or durable background execution, Lakebase PostgreSQL for operational metadata, UC Volumes/approved object storage for immutable manifests and snapshots, GitHub App/GitHub Actions and Databricks Asset Bundles for GitOps, Terraform via existing CI pipelines or isolated approved runners.

**Non-negotiable rules:** tenant-isolated and server-authorized operations; least-privilege source/target credentials; secrets resolved server-side and never returned to browser; policy + approval enforcement at execution time; immutable plan hashes; idempotent dispatch; concurrency/resource ownership locks; per-resource execution evidence; auditable state transitions; safe retries; no assumption that all Databricks resource types are exportable or reversible. A successful API response is not proof that deployment verification succeeded.

All DDL is **reference PostgreSQL**, to be adapted through Alembic after checking existing tables (`projects`, `deployment_plans`, `deployment_runs`, `deployment_steps`, `approvals`, `audit_events`, `resource_bindings`, `workspaces`, `asset_manifests`, `pipeline_runs`). Add composite tenant-consistent FKs, indexes, uniqueness and row-level access controls where consistent with the existing application. Do not execute `CREATE TABLE` blindly.

Deliver functional frontend, typed backend contracts, persistence/migrations, adapters, workers, security checks, observability, automated unit/integration/end-to-end tests, and operational documentation. Implement loading, empty, error, blocked and permission-denied states; avoid mocked success and placeholder-only pages.

## 1. Purpose

Implement the authoritative, searchable **historical record of deployment attempts and verified outcomes**, including direct SDK runs, GitHub Actions/Databricks Bundles, Terraform execution, release promotion, sync operations and rollback/recovery runs. This page must provide evidence for incident analysis, compliance and repeatable operations; it is not just a list of success/failure labels.

## 2. Frontend sections

- **History overview:** executions over time, success/failure/partial/cancelled counts, environment distribution, deployment frequency and duration, recent production changes; date filters and definitions for metrics.
- **Runs table:** deployment ID, project/type, launch/release ID, source version/commit, target workspace/environment/account, mode/provider, actor/trigger, status, risk, approvals, start/end/duration, verification result, rollback eligibility, links.
- **Advanced filters:** project, target, environment, asset type, status, mode, actor, date range, approval, GitHub run, release version, correlation ID, rollback-related run, resource logical key; server-side pagination/sort.
- **Run detail tabs:** Overview, Timeline, Resource Changes, Logs & Diagnostics, Plan & Approvals, Verification, Artifacts, Recovery/Rollback, Audit.
- **Resource changes:** before/after fingerprints and redacted diffs, action, asset type, source/target IDs, dependency order, step status, retry attempts, duration, error classification and resource ownership.
- **Timeline:** request → plan → approval → queue → execution steps → provider callbacks → verification → final status, with UTC timestamps and local display.
- **Logs/evidence:** paginated sanitized logs, artifact refs, GitHub Actions link, Terraform plan/apply evidence refs, bundle validation output, verification evidence, approvals and audit correlation.
- **Actions:** view plan, compare to current target, export sanitized report, inspect failed steps, open Pipeline Run, start new deployment using previous config (always replan), request rollback/recovery. Do not offer replay of stale approval or raw execution payload.

## 3. Functional requirements

1. One canonical deployment run ledger spans all execution modes; link to existing `pipeline_runs`, `release_promotions`, `workspace_sync_run_links`, launch requests and rollback attempts instead of duplicating history.
2. Persist append-only status transition events and per-step outcomes; capture start/end times and actor/service principal; distinguish requested vs executed vs verified.
3. Use truthful states: `QUEUED`, `WAITING_APPROVAL`, `RUNNING`, `VERIFYING`, `SUCCEEDED`, `PARTIAL`, `FAILED`, `CANCELLING`, `CANCELLED`, `TIMED_OUT`, `UNKNOWN`. A GitHub dispatch or successful API write is not necessarily a verified success.
4. Multi-target launch creates per-target run records plus a group summary; a successful DEV target does not hide a failed PROD target.
5. Preserve exact immutable source manifest/commit, mapping revision, plan digest, policy revision, approval IDs, target snapshots, credential principal reference and execution adapter version.
6. Capture asset-level actions and results with redacted before/after definitions, fingerprints, target resource IDs, resource binding updates, verification checks and retry attempt IDs.
7. For Terraform, capture state backend/workspace identifier, plan digest, remote pipeline/runner ID, apply result and sanitized changes; **never** store Terraform state or sensitive plan contents as ordinary history JSON.
8. For GitHub Actions, correlate run ID and attempt; reconcile missed webhooks; display provider status separately if different from application verification.
9. For ML promotion, record source/target model/version, alias changes, serving endpoint configuration/traffic references, evaluation evidence and post-deployment checks.
10. Include history for manual and scheduled sync, including drift comparison snapshot and selected changes. Never imply table data was synchronized when only definitions/configuration changed.
11. Support retention policy, immutable audit evidence and archived artifacts. If log bodies expire, retain stable metadata, digest and clear `expired` indicator.
12. All history queries enforce tenant/project/workspace RBAC; sensitive definition/log access requires separate permission. Exports must be redacted, access-controlled and audited.
13. Allow comparison of historical deployment to current target, but label it a **fresh** live-state comparison with timestamp; historical evidence itself is immutable.
14. Re-deploy from history always generates new draft/plan with current target checks and new approvals; do not reuse stale provider tokens or Terraform plans.
15. Provide deterministic, versioned operational metrics (success rate, failure rate, deployment frequency, mean duration) with documented inclusion/exclusion of cancelled/partial runs.
16. Handle missing external provider logs, deleted GitHub repository, expired artifact, unavailable workspace, clock skew, duplicate callbacks and partially recovered jobs gracefully.
17. Audit viewing sensitive logs, exporting history, re-deploy initiation and rollback request.

## 4. Backend and event architecture

`deployment_history_query_service`, `run_event_store`, `execution_step_repository`, `provider_run_linker`, `verification_evidence_index`, `log_redactor`, `retention_service`, `history_exporter`, `deployment_metrics_aggregator`.

Write path: executor emits structured events → transactional event append/outbox → materialized run status/step summary → query endpoints → UI. Events must be idempotent, ordered by monotonic sequence per run, and never rewrite past audit evidence. Reconcile external providers asynchronously.

Read path: paginated tenant-scoped queries, indexed filters, summary aggregates and artifact refs; fetch logs through authorized backend proxy/signed short-lived access only.

## 5. Reference Lakebase PostgreSQL DDL

```sql
CREATE EXTENSION IF NOT EXISTS pgcrypto;
-- Existing deployment_runs remains the canonical run table.
CREATE TABLE IF NOT EXISTS deployment_run_events (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 tenant_id uuid NOT NULL REFERENCES tenants(id),
 deployment_run_id uuid NOT NULL, -- FK to existing deployment_runs
 sequence_no bigint NOT NULL CHECK(sequence_no > 0),
 event_type text NOT NULL,
 status_from text, status_to text,
 actor_user_id uuid REFERENCES app_users(id),
 actor_principal_ref text,
 event_data jsonb NOT NULL DEFAULT '{}'::jsonb,
 correlation_id text,
 occurred_at timestamptz NOT NULL DEFAULT now(),
 UNIQUE(tenant_id,deployment_run_id,sequence_no),
 UNIQUE(id,tenant_id)
);
CREATE TABLE IF NOT EXISTS deployment_resource_change_records (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 tenant_id uuid NOT NULL REFERENCES tenants(id),
 deployment_run_id uuid NOT NULL,
 asset_type text NOT NULL,
 logical_key text NOT NULL,
 source_asset_ref text,
 target_resource_ref text,
 operation text NOT NULL,
 outcome text NOT NULL CHECK(outcome IN
  ('PENDING','RUNNING','SUCCEEDED','SKIPPED','FAILED','PARTIAL','UNKNOWN')),
 before_fingerprint char(64),
 after_fingerprint char(64),
 sanitized_diff jsonb NOT NULL DEFAULT '{}'::jsonb,
 verification jsonb NOT NULL DEFAULT '{}'::jsonb,
 attempt_no integer NOT NULL DEFAULT 1,
 started_at timestamptz, finished_at timestamptz,
 error_code text, error_summary text,
 UNIQUE(tenant_id,deployment_run_id,asset_type,logical_key,attempt_no)
);
CREATE TABLE IF NOT EXISTS deployment_run_artifact_links (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 tenant_id uuid NOT NULL REFERENCES tenants(id),
 deployment_run_id uuid NOT NULL,
 artifact_kind text NOT NULL CHECK(artifact_kind IN
  ('MANIFEST','PLAN','SNAPSHOT','LOG','VERIFICATION','PROVIDER_RUN','REPORT')),
 storage_ref text NOT NULL,
 digest_sha256 char(64),
 sensitivity text NOT NULL DEFAULT 'INTERNAL'
  CHECK(sensitivity IN ('PUBLIC','INTERNAL','RESTRICTED')),
 expires_at timestamptz,
 created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS deployment_run_group_links (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 tenant_id uuid NOT NULL REFERENCES tenants(id),
 group_ref text NOT NULL,
 deployment_run_id uuid NOT NULL,
 target_workspace_id uuid NOT NULL REFERENCES workspaces(id),
 UNIQUE(tenant_id,group_ref,deployment_run_id)
);
CREATE INDEX IF NOT EXISTS ix_run_events
 ON deployment_run_events(tenant_id,deployment_run_id,sequence_no);
CREATE INDEX IF NOT EXISTS ix_resource_change_lookup
 ON deployment_resource_change_records(tenant_id,asset_type,logical_key);
```

**Migration hardening:** enforce composite FKs to `deployment_runs`, `workspaces` and user records; index run date/status/project on canonical table; store append-only events and preserve evidence digests even when retention removes log bodies.

## 6. Security, audit, performance and tests

Permissions: `deployment_history.view`, `deployment_history.view_logs`, `deployment_history.export`, `deployment_history.compare`, `deployment_history.redeploy`, `deployment_history.request_recovery`. Apply row-level project/workspace access and redact sensitive definitions.

Performance: server-side keyset/cursor pagination for large histories, indexed filters, asynchronous exports, aggregation refresh and bounded artifact retrieval. Metrics include event lag, query latency, provider reconciliation staleness and history retention.

**Acceptance tests:** direct/GitHub/Terraform/sync/release/rollback runs appear in one history; accurate per-target and per-step status; immutable evidence; logs redacted; provider callback dedup; partial result correctly represented; historical plan link; fresh re-deploy requires new plan; retention expiration indicated; cross-tenant isolation; export audited.
