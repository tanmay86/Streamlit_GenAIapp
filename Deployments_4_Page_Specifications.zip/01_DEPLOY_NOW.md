# DEPLOY-01 — Deploy Now | Complete Coding-Agent Specification

**Navigation:** Deployments → Deploy Now

## Coding-agent implementation contract

**Product:** JadeOrbit DeployPactAI. **Module:** Deployments. **Scope:** full enterprise production functionality, not a prototype.

Before writing code, read `PROJECT_REQUIREMENTS.md`, `PROJECT_ARCHITECTURE.md`, and the existing specifications for Projects, Workspaces, Administration and CI/CD. Inspect actual frontend routes, React/TypeScript components, FastAPI modules, Databricks SDK client factory, Lakebase PostgreSQL models, Alembic history, approval/policy/audit services, worker orchestration and artifact storage. **Extend existing infrastructure rather than duplicating it.**

There are exactly **four project types**: Direct Deployment, Git-Enabled Deployment, Release Promotion (including ML model promotion), and Workspace Synchronization. Terraform is an execution/integration capability, not another project type. The application is already connected to Databricks; preserve current behavior and use additive migrations.

Technology baseline: React + TypeScript, FastAPI/Python, Databricks Apps, Databricks SDK/REST APIs, Databricks Jobs or durable background execution, Lakebase PostgreSQL for operational metadata, UC Volumes/approved object storage for immutable manifests and snapshots, GitHub App/GitHub Actions and Databricks Asset Bundles for GitOps, Terraform via existing CI pipelines or isolated approved runners.

**Non-negotiable rules:** tenant-isolated and server-authorized operations; least-privilege source/target credentials; secrets resolved server-side and never returned to browser; policy + approval enforcement at execution time; immutable plan hashes; idempotent dispatch; concurrency/resource ownership locks; per-resource execution evidence; auditable state transitions; safe retries; no assumption that all Databricks resource types are exportable or reversible. A successful API response is not proof that deployment verification succeeded.

All DDL is **reference PostgreSQL**, to be adapted through Alembic after checking existing tables (`projects`, `deployment_plans`, `deployment_runs`, `deployment_steps`, `approvals`, `audit_events`, `resource_bindings`, `workspaces`, `asset_manifests`, `pipeline_runs`). Add composite tenant-consistent FKs, indexes, uniqueness and row-level access controls where consistent with the existing application. Do not execute `CREATE TABLE` blindly.

Deliver functional frontend, typed backend contracts, persistence/migrations, adapters, workers, security checks, observability, automated unit/integration/end-to-end tests, and operational documentation. Implement loading, empty, error, blocked and permission-denied states; avoid mocked success and placeholder-only pages.

## 1. Purpose and boundaries

Implement the primary **deployment launch experience**. Users select an existing configured project, an immutable source version/asset manifest, one or more target environments, mapping revisions and execution mode; preview a deterministic plan; satisfy policies/approvals; then submit a durable deployment run. **Creating a project does not deploy it.** This page must use the same planning/execution infrastructure as Deployment Plans, CI/CD Releases and Workspace Compare & Sync.

## 2. Page structure

1. **Launch overview:** eligible projects, recent launches, drafts awaiting review, pending approvals, active target locks, recent failures and relevant alerts.
2. **Select project:** searchable project picker with type, status, owner, source, configured targets, supported execution modes and last deployment. Archived/incomplete/unauthorized projects are not selectable.
3. **Select source/version:** current source workspace snapshot, immutable manifest, Git commit SHA/tag/release artifact or sync comparison snapshot according to project type; show freshness and fingerprint.
4. **Select targets:** environment cards for DEV/QA/UAT/PROD/custom; target workspace, cloud/account, connectivity, credential health, privileges, mapping profile revision, deployment ownership.
5. **Choose execution strategy:** Direct Databricks SDK, Databricks Bundle via approved GitHub Actions, existing Terraform pipeline, or managed Terraform runner if enabled. The strategy must be compatible with project type and resource ownership; never silently convert Terraform to SDK deployment.
6. **Options:** dry run, conflict behavior (fail/skip/update managed/adopt with approval), dependency inclusion, batch/concurrency limits, schedule/maintenance window, notifications, post-deployment verification, rollback snapshot preference; expose only options supported by the selected adapter.
7. **Preflight & plan preview:** change summary by target/resource, create/update/no-op/blocked, dependency graph, source-target mappings, permissions, risk classification, costs/limits where deterministically estimable, drift/ownership conflicts, irreversible changes, required approvals.
8. **Approval and confirmation:** explicit acknowledgement of production impact, exact plan digest, actor, targets, scheduled vs immediate launch, approval status and expiration.
9. **Submission result:** durable run ID, queue status, links to Deployment Plans, Deployment History, Pipeline Runs or Release & Promotions, with no fabricated completion.

## 3. End-to-end functional behavior

- Direct Deployment: select workspace assets → dependency closure → environment mapping → deterministic SDK plan → approval → execute against targets.
- Git-Enabled Deployment: pin repository commit and bundle target → validate workflow/repo/OIDC → GitHub Actions dispatch → correlate run → verify target.
- Release Promotion: select an immutable approved release and next eligible target → verify sequence/quality gates → route to appropriate execution adapter; ML model/serving updates are release steps, not a separate project.
- Workspace Synchronization: select approved comparison snapshot and reviewed change set → validate current drift → sync selected resources; never silently delete target-only assets.
- For mixed asset ownership, split into independently reviewed plans or block incompatible combinations. A single plan must never mix SDK writes with Terraform-owned resources without explicit ownership-transfer workflow.
- Source and target credentials are independent; support cross-account targets only after independent network, authentication, privilege and capability checks.
- Run preflight against current workspace status, asset manifest, target fingerprints, mappings, quota/capability, GitHub access, Terraform state lock/runner availability and policy.
- Plan creation is **side-effect-free** with respect to target resources. Terraform `plan` can access state/backend but must not apply; GitHub bundle validate must not deploy.
- Show target-specific warnings for catalog/metastore mismatch, unprovisioned secrets, missing `run_as`, unsupported asset API, SQL warehouse/cluster policy mapping, serving/model artifact access, shared UC objects and destructive changes.
- Lock exact source digest, target IDs, mapping revisions, policy revision and resource bindings when preparing an approval. Replan/reapprove if any material input changes.
- Approval request is attached to the exact immutable plan digest, target, actor, action and risk. Enforce separation of duties for production when policy requires.
- Manual execution and scheduled execution must follow identical policy checks. A schedule does not bypass approval or maintenance window.
- Support one-to-many targets as **separate target-scoped plans/runs** grouped by one launch request. Partial success is explicitly represented; do not claim global success until all required targets pass.
- Use durable queueing, target/resource locks, idempotency keys, cancellation requests, retries of safe steps and resumable checkpoints.
- Execute in dependency order; do not overwrite unmanaged resources without explicit reviewed adoption; skip unsupported resources only when user approves explicit exclusions.
- After execution, verify target actual state and resource bindings. Persist step results, provider IDs, logs/evidence references and before/after fingerprints.
- Do not promise automatic rollback for irreversible data/schema changes, Terraform state mutations, externally triggered jobs or model-serving traffic effects.
- AI may explain risks or suggest mappings, but may not bypass deterministic validation, policy, approval or human confirmation.

## 4. Frontend validation and UX

- Wizard state survives refresh through server-side draft records; prevent duplicate submissions on double-click.
- Responsive steps, progress indicator, keyboard accessibility, server-side search, explanatory blocked states, and diff preview for sensitive production changes.
- Clearly separate **Validate**, **Create Plan**, **Request Approval**, **Deploy Now**, **Schedule**, **Cancel Request**.
- For GitHub or Terraform, show provider run link and eventual-consistency status; dispatch acknowledgment ≠ deployment success.
- For each target, show status independently; on partial failure offer view history and recovery, not blind retry.

## 5. Backend components and contracts

`launch_draft_service`, `project_eligibility_service`, `manifest_resolver`, `target_selector`, `mapping_resolver`, `preflight_service`, `dependency_planner`, `change_classifier`, `ownership_guard`, `policy_engine`, `approval_service`, `deployment_plan_service`, `deployment_dispatcher`, `execution_router`, `verification_service`, `audit_writer`.

Conceptual operations: list eligible projects; create/update draft; resolve source; validate targets; preflight; generate immutable plan; request approval; submit plan; schedule/cancel; fetch launch status. Reuse existing APIs if present.

Execution routing:
- SDK direct: type-specific adapters on durable worker with idempotency/resource binding.
- Bundle/GitOps: GitHub Actions workflow dispatch with pinned SHA; provider callback/poll reconciliation.
- Terraform existing pipeline: dispatch existing approved workflow; Terraform itself executes plan/apply.
- Managed Terraform: isolated runner with pinned tool/provider versions, remote state locking and approval-bound saved plan; never run Terraform inside FastAPI request.
- Release/sync: invoke same executor through approved project-specific plan.

## 6. Reference Lakebase PostgreSQL DDL

```sql
CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE TABLE IF NOT EXISTS deployment_launch_requests (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 tenant_id uuid NOT NULL REFERENCES tenants(id),
 project_id uuid NOT NULL, -- tenant-consistent FK to existing projects
 created_by uuid REFERENCES app_users(id),
 source_kind text NOT NULL CHECK(source_kind IN
  ('WORKSPACE_MANIFEST','GIT_COMMIT','RELEASE_ARTIFACT','SYNC_SNAPSHOT')),
 source_ref text NOT NULL,
 source_digest char(64),
 execution_mode text NOT NULL CHECK(execution_mode IN
  ('SDK_DIRECT','GITHUB_BUNDLE','TERRAFORM_EXISTING_PIPELINE','TERRAFORM_MANAGED')),
 options jsonb NOT NULL DEFAULT '{}'::jsonb,
 status text NOT NULL DEFAULT 'DRAFT' CHECK(status IN
  ('DRAFT','VALIDATING','PLANNED','AWAITING_APPROVAL','APPROVED',
   'QUEUED','RUNNING','PARTIAL','SUCCEEDED','FAILED','CANCELLED','EXPIRED')),
 idempotency_key text NOT NULL,
 created_at timestamptz NOT NULL DEFAULT now(),
 updated_at timestamptz NOT NULL DEFAULT now(),
 UNIQUE(id,tenant_id), UNIQUE(tenant_id,idempotency_key)
);
CREATE TABLE IF NOT EXISTS deployment_launch_targets (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 tenant_id uuid NOT NULL REFERENCES tenants(id),
 launch_id uuid NOT NULL,
 workspace_id uuid NOT NULL REFERENCES workspaces(id),
 environment_name text NOT NULL,
 mapping_revision_ref text,
 deployment_plan_id uuid, -- FK to existing deployment_plans
 deployment_run_id uuid, -- FK to existing deployment_runs
 status text NOT NULL DEFAULT 'PENDING',
 FOREIGN KEY(launch_id,tenant_id) REFERENCES deployment_launch_requests(id,tenant_id),
 UNIQUE(launch_id,workspace_id,environment_name)
);
CREATE TABLE IF NOT EXISTS deployment_preflight_results (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 tenant_id uuid NOT NULL REFERENCES tenants(id),
 launch_id uuid NOT NULL,
 workspace_id uuid NOT NULL REFERENCES workspaces(id),
 status text NOT NULL CHECK(status IN ('RUNNING','PASSED','WARNINGS','BLOCKED','FAILED')),
 checks jsonb NOT NULL DEFAULT '[]'::jsonb,
 source_digest char(64), target_digest char(64),
 evaluated_at timestamptz NOT NULL DEFAULT now(),
 expires_at timestamptz,
 FOREIGN KEY(launch_id,tenant_id) REFERENCES deployment_launch_requests(id,tenant_id)
);
CREATE INDEX IF NOT EXISTS ix_launch_recent
 ON deployment_launch_requests(tenant_id,created_at DESC);
```

**Migration note:** reuse existing plan/run/approval tables; add composite tenant FKs to project/workspace/plan/run using their actual schemas. Do not duplicate plan contents in `deployment_launch_requests`.

## 7. Security, audit, telemetry and acceptance criteria

Permissions: `deployment.launch`, `deployment.plan`, `deployment.execute`, `deployment.schedule`, `deployment.cancel`, `deployment.override_conflict`, `deployment.use_target`. Check project and workspace grants as well.

Audit launch draft changes, source selection, target/mapping selection, preflight, plan digest, approval request/decision, dispatch, cancellation and final verification. Track preflight duration, plan generation, approval wait, dispatch latency, blocked launches, per-target success/failure.

**Acceptance tests:** source and target in different accounts; source read-only vs target write; disabled target blocked; immutable plan approval; duplicate launch idempotency; target drift invalidates plan; GitHub dispatch not counted as success; Terraform execution routed to Terraform; partial multi-target result; production approval; resource ownership conflict; safe cancellation and complete audit trail.
