# CI/CD-03 — Release & Promotion | Detailed Functional & Technical Requirements

**Navigation:** CI/CD → Release & Promotions

## Implementation contract for coding agent

**Product:** JadeOrbit DeployPactAI. **Module:** CI/CD. **Scope:** complete enterprise product, not MVP.

Before coding, inspect the existing `PROJECT_REQUIREMENTS.md`, `PROJECT_ARCHITECTURE.md`, Administration (especially GitHub Integration, Approvals, Deployment Policies, Audit Logs), Workspaces, and Projects specifications, existing React/TypeScript routes, FastAPI services, Lakebase models, Alembic migrations, SDK client factory, policy engine, audit writer and deployment worker. **Reuse existing services and tables; do not build parallel systems.**

The application is already running in a Databricks workspace. Implement additive, backward-compatible migrations. Preserve the four project types only: **Direct Deployment, Git-Enabled Deployment, Release Promotion, Workspace Synchronization**. ML model promotion is a capability **inside Release Promotion**, not a fifth project type. Terraform is an integration/execution option, **not** a fifth project type.

Technology baseline: React + TypeScript; Python FastAPI; Databricks SDK/REST; Databricks Apps hosting; Lakebase PostgreSQL metadata; Databricks Jobs/durable workers; Unity Catalog Volumes or approved object storage for immutable artifacts; GitHub App + GitHub Actions; Databricks Asset Bundles / Declarative Automation Bundles; Terraform CLI only in isolated approved runners. Use supported Databricks/GitHub APIs; feature-gate unsupported operations.

All mutating operations require server-side tenant isolation, RBAC, policy evaluation, audit, immutable version/plan evidence, idempotency, retries with bounded backoff, observability and safe errors. Do not expose GitHub App private keys, installation tokens, Databricks credentials, Terraform state secrets, OIDC tokens, model artifacts or notebook source to unauthorized users. Do not run arbitrary user-supplied shell commands in the app server.

SQL is **reference PostgreSQL DDL**, not a command to execute unconditionally. Reconcile with existing `projects`, `repositories`, `git_integrations`, `pipeline_runs`, `deployment_plans`, `deployment_runs`, `approvals`, `artifact_versions`, `resource_bindings` and `audit_events`. Apply tenant-consistent foreign keys and Alembic migrations. Every page needs loading/empty/error/permission states, accessibility, pagination, typed backend contracts, automated tests and operational telemetry.

## 1. Goal

Manage **immutable releases, environment promotion DEV → QA/STAGING → UAT → PROD, approvals, verification and release rollback** across Databricks workspaces. This page is the operational home for the **Release Promotion project type** and must also support **ML model version promotion** as an embedded release capability (not a separate project type).

## 2. Frontend sections and workflow

- **Release dashboard:** release ID/version, project, asset package, source commit/artifact digest, current environment, targets, status, owner, last promoted time, risk, approval state, rollback availability.
- **Create release:** choose Release Promotion project → select immutable package/source commit/manifest → select release version and notes → capture dependencies, mappings and target sequence → validate → create immutable candidate.
- **Release detail tabs:** Overview, Artifacts & Models, Environment Timeline, Promotion Plan, Approvals, Verification Evidence, Rollback, Audit.
- **Promotion wizard:** choose next permitted environment → verify immutable artifact and mappings → target diff/plan → preflight tests/policy → approval → execute via Direct SDK/Bundle/GitHub/Terraform owner → verify → publish evidence.
- **Release history:** per-environment deployment state, approval decisions, checks, job/pipeline run links, version fingerprints and exact Databricks target resource bindings.
- **Rollback wizard:** select environment/release → display rollback-eligible resources, previous known-good version, stateful/irreversible changes and risks → generate reverse/restore plan → policy + approval → execute → verify and retain original release record.
- **ML promotion panel:** source model full name and version, alias (if used), artifact digest/location, signature, dependencies, evaluation metrics, test gates, target registered model/version, serving endpoint configuration, canary/traffic configuration where API-supported, rollback alias/endpoint reference.

## 3. Release lifecycle and controls

1. A release is immutable: project revision, manifest, source commit SHA (if Git), dependency graph, mapping revisions, policy revision, identity, artifacts, model version references and hashes are captured.
2. Environment promotion moves **the same approved artifact/version**, not a freshly built mutable branch, unless explicitly defined as a new release.
3. Each target environment gets its own plan, approvals, execution record and verification evidence. Never assume same-account permissions imply cross-account permissions.
4. Allowed promotion sequence is policy-controlled (e.g., DEV → QA → UAT → PROD); exceptions require authorized override with audit.
5. Policy gates can require unit/integration tests, bundle validate, Terraform plan, security scan, data/quality checks, ML evaluation, model signature checks, manual approval and maintenance window.
6. Production deployment must verify source artifact immutability, target permissions, mapping validity, ownership, existing resource bindings, target drift and approval binding to exact plan hash.
7. Model promotion supports MLflow/Unity Catalog model registry concepts and model aliases where supported; do not assume cross-workspace model version references are valid across metastores/accounts. Verify artifact access or explicitly copy/re-register through supported workflow with provenance.
8. Model aliases (e.g., `Champion`/`Candidate`) are not automatically identical to environments. Map model versions and aliases explicitly; staging/production can be separate workspaces or registry namespaces.
9. Serving promotion must verify target endpoint exists or is provisioned, model availability, permissions, quota, serving config and smoke tests. Support gradual rollout only if endpoint/API supports it; otherwise use atomic approved cutover with truthful limitations.
10. ML model evaluation gates: required metrics and thresholds are configured per project/policy; record datasets/metrics lineage references without copying sensitive datasets. Never let AI override evaluation/approval.
11. Release rollback is **resource-specific**: restore previous notebook/job/pipeline settings, redeploy prior bundle/commit, revert model alias/serving config, or run approved Terraform corrective plan. Terraform rollback is **not** simply `terraform apply` of old state or automatic state rewind.
12. State-changing operations (table drops, schema migrations, data deletion, external side effects, job executions) may not be reversible. Show explicit `FULL`, `PARTIAL`, `MANUAL`, `NOT_SUPPORTED` rollback eligibility and backup prerequisites.
13. Capture pre-deployment snapshots and resource bindings where supported. Rollback creates a **new audited deployment event**, not deletion of release history.
14. Support partial release success across targets; do not mark global release complete until required target gates and verification pass.
15. Block promoting a stale plan or altered artifact; if target drift occurs, replan/reapprove.
16. Protect Git/Terraform ownership: invoke the appropriate pipeline and source of truth; do not silently change Terraform-owned resources using Databricks SDK.
17. AI can summarize release risk, diff and failure logs, and suggest rollback steps; recommendations require deterministic verification and human approval.
18. Optional post-release monitoring window with metrics, health checks, drift alerts and operator-triggered rollback; automatic rollback only for explicitly configured, deterministic, low-risk reversible resources and approved policy.

## 4. Backend workflow and components

`release_catalog_service` → `immutable_artifact_store` → `promotion_graph_validator` → `target_mapping_resolver` → `deployment_planner` → `policy_engine` → `approval_service` → `execution_router` (SDK / Bundle GitHub Actions / Terraform runner) → `verification_service` → `release_evidence_writer`.

For ML: `model_registry_adapter` → `model_artifact_access_validator` → `model_evaluation_gate` → `serving_endpoint_adapter` → `model_rollback_snapshot`.

For rollback: `rollback_eligibility_analyzer` → `rollback_plan_builder` → policy/approval → execution router → verification. Persist all transitions durably with optimistic concurrency.

Suggested lifecycle:
`DRAFT → CANDIDATE → VALIDATED → AWAITING_APPROVAL → APPROVED → PROMOTING → VERIFYING → PROMOTED`
with `BLOCKED`, `FAILED`, `PARTIAL`, `CANCELLED` and separate `ROLLBACK_REQUESTED → ROLLING_BACK → ROLLED_BACK/PARTIAL_ROLLBACK/ROLLBACK_FAILED`.

## 5. Reference DDL

```sql
CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE TABLE IF NOT EXISTS cicd_releases (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 tenant_id uuid NOT NULL REFERENCES tenants(id),
 project_id uuid NOT NULL, -- FK to projects with tenant scope
 release_version text NOT NULL,
 manifest_digest char(64) NOT NULL,
 artifact_ref text NOT NULL,
 source_commit_sha char(40),
 project_revision integer NOT NULL,
 created_by uuid REFERENCES app_users(id),
 status text NOT NULL DEFAULT 'DRAFT' CHECK(status IN
  ('DRAFT','CANDIDATE','VALIDATED','BLOCKED','ACTIVE','ARCHIVED')),
 created_at timestamptz NOT NULL DEFAULT now(),
 UNIQUE(id,tenant_id), UNIQUE(tenant_id,project_id,release_version)
);
CREATE TABLE IF NOT EXISTS cicd_release_artifacts (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 tenant_id uuid NOT NULL REFERENCES tenants(id),
 release_id uuid NOT NULL,
 artifact_kind text NOT NULL CHECK(artifact_kind IN
  ('DATABRICKS_ASSET','BUNDLE','TERRAFORM_PLAN_REF','ML_MODEL','SERVING_CONFIG')),
 logical_key text NOT NULL,
 artifact_digest text NOT NULL,
 artifact_metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
 FOREIGN KEY(release_id,tenant_id) REFERENCES cicd_releases(id,tenant_id)
);
CREATE TABLE IF NOT EXISTS cicd_release_promotions (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 tenant_id uuid NOT NULL REFERENCES tenants(id),
 release_id uuid NOT NULL,
 source_environment text,
 target_environment text NOT NULL,
 target_workspace_id uuid NOT NULL REFERENCES workspaces(id),
 plan_id uuid,        -- link existing deployment_plans
 deployment_run_id uuid, -- link existing deployment_runs
 approval_request_id uuid,
 status text NOT NULL DEFAULT 'PENDING' CHECK(status IN
  ('PENDING','VALIDATING','AWAITING_APPROVAL','APPROVED','PROMOTING',
   'VERIFYING','PROMOTED','BLOCKED','FAILED','PARTIAL','CANCELLED')),
 mapping_revision_ref text,
 verification_evidence_ref text,
 started_at timestamptz, completed_at timestamptz,
 FOREIGN KEY(release_id,tenant_id) REFERENCES cicd_releases(id,tenant_id),
 UNIQUE(id,tenant_id)
);
CREATE TABLE IF NOT EXISTS cicd_release_model_versions (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 tenant_id uuid NOT NULL REFERENCES tenants(id),
 release_id uuid NOT NULL,
 source_model_name text NOT NULL,
 source_model_version text NOT NULL,
 target_model_name text,
 target_model_version text,
 source_alias text, target_alias text,
 artifact_digest text,
 evaluation_evidence_ref text,
 serving_config_ref text,
 FOREIGN KEY(release_id,tenant_id) REFERENCES cicd_releases(id,tenant_id)
);
CREATE TABLE IF NOT EXISTS cicd_release_rollbacks (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 tenant_id uuid NOT NULL REFERENCES tenants(id),
 promotion_id uuid NOT NULL,
 target_release_id uuid,
 rollback_plan_id uuid,
 requested_by uuid REFERENCES app_users(id),
 eligibility text NOT NULL CHECK(eligibility IN
  ('FULL','PARTIAL','MANUAL','NOT_SUPPORTED')),
 status text NOT NULL DEFAULT 'REQUESTED' CHECK(status IN
  ('REQUESTED','AWAITING_APPROVAL','APPROVED','RUNNING','VERIFYING',
   'ROLLED_BACK','PARTIAL_ROLLBACK','FAILED','BLOCKED')),
 rationale text,
 result_evidence_ref text,
 created_at timestamptz NOT NULL DEFAULT now(),
 FOREIGN KEY(promotion_id,tenant_id) REFERENCES cicd_release_promotions(id,tenant_id)
);
CREATE INDEX IF NOT EXISTS ix_release_promotions
 ON cicd_release_promotions(tenant_id,target_workspace_id,started_at DESC);
```

**Schema integration:** use existing `artifact_versions`, `approvals`, `deployment_plans`, `deployment_runs`, `resource_bindings`, `projects` and ML metadata if present; enforce tenant-consistent composite FKs, immutable artifacts, and one active promotion lock per target scope.

## 6. Security, auditing and failure cases

- Permissions: `release.view`, `release.create`, `release.validate`, `release.promote`, `release.approve`, `release.rollback`, `release.override_sequence`, `release.manage_model_gates`.
- Enforce separation of duties: requester cannot approve own PROD promotion where policy requires. Every promotion/rollback is tied to immutable digest and policy revision.
- Audit release creation, artifact pinning, model evaluation, promotion attempts, approval, endpoint alias/traffic changes, rollback plans and results.
- Handle missing model artifacts, incompatible target registry/metastore, unverified serving endpoint, insufficient ML evaluation, stale plan, target drift, GitHub failure, Terraform state lock, partial changes and nonreversible operations.
- Tests: DEV→STAGING→PROD sequence; same artifact digest; PROD approval; cross-account model artifact access; alias/serving rollback; nonrollbackable data warning; Terraform ownership; stale plan blocking; per-target partial failure; full audit evidence.
