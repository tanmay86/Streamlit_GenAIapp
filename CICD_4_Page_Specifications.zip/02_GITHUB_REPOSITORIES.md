# CI/CD-02 — GitHub Repositories | Detailed Functional & Technical Requirements

**Navigation:** CI/CD → GitHub Repositories

## Implementation contract for coding agent

**Product:** JadeOrbit DeployPactAI. **Module:** CI/CD. **Scope:** complete enterprise product, not MVP.

Before coding, inspect the existing `PROJECT_REQUIREMENTS.md`, `PROJECT_ARCHITECTURE.md`, Administration (especially GitHub Integration, Approvals, Deployment Policies, Audit Logs), Workspaces, and Projects specifications, existing React/TypeScript routes, FastAPI services, Lakebase models, Alembic migrations, SDK client factory, policy engine, audit writer and deployment worker. **Reuse existing services and tables; do not build parallel systems.**

The application is already running in a Databricks workspace. Implement additive, backward-compatible migrations. Preserve the four project types only: **Direct Deployment, Git-Enabled Deployment, Release Promotion, Workspace Synchronization**. ML model promotion is a capability **inside Release Promotion**, not a fifth project type. Terraform is an integration/execution option, **not** a fifth project type.

Technology baseline: React + TypeScript; Python FastAPI; Databricks SDK/REST; Databricks Apps hosting; Lakebase PostgreSQL metadata; Databricks Jobs/durable workers; Unity Catalog Volumes or approved object storage for immutable artifacts; GitHub App + GitHub Actions; Databricks Asset Bundles / Declarative Automation Bundles; Terraform CLI only in isolated approved runners. Use supported Databricks/GitHub APIs; feature-gate unsupported operations.

All mutating operations require server-side tenant isolation, RBAC, policy evaluation, audit, immutable version/plan evidence, idempotency, retries with bounded backoff, observability and safe errors. Do not expose GitHub App private keys, installation tokens, Databricks credentials, Terraform state secrets, OIDC tokens, model artifacts or notebook source to unauthorized users. Do not run arbitrary user-supplied shell commands in the app server.

SQL is **reference PostgreSQL DDL**, not a command to execute unconditionally. Reconcile with existing `projects`, `repositories`, `git_integrations`, `pipeline_runs`, `deployment_plans`, `deployment_runs`, `approvals`, `artifact_versions`, `resource_bindings` and `audit_events`. Apply tenant-consistent foreign keys and Alembic migrations. Every page needs loading/empty/error/permission states, accessibility, pagination, typed backend contracts, automated tests and operational telemetry.

## 1. Goal

Provide the project-facing interface for **discovering, connecting, inspecting and assigning GitHub repositories** used for Databricks GitOps, CI/CD, release manifests, deployment artifacts and existing Terraform modules/workflows. Administration → GitHub Integration remains the place for **GitHub App installation, trust and credential administration**. This page must not duplicate that administration flow.

## 2. Frontend sections

- **Repository directory:** organization/owner, repository, private/public, installation/account, default branch, linked projects, workflows found, Terraform detected, Bundle detected, connection health, last sync, status.
- **Add repository:** select authorized GitHub App installation → search repositories granted to installation → select repository → choose usage (Databricks Bundle, source notebooks, existing GitHub workflow, Terraform infrastructure, release manifest) → select default branch/path → verify → save.
- **Repository detail tabs:** Overview, Branches & Tags, Workflows, Bundle Files, Terraform Configurations, Project Links, Access & Health, Sync History.
- **Repository file explorer:** read-only, scoped and paginated inspection of allowlisted paths for `databricks.yml`, `resources/*.yml`, `.github/workflows/*.yml`, `.tf`, `.tfvars.example`, module definitions, lockfiles and README. Do not render secret values from `.tfvars`, `.env`, encrypted files or action secrets.
- **Actions:** connect, refresh, validate access, link/unlink project, choose protected deployment ref, view GitHub, create approved export PR, disable/archive connection.
- **Workflow list:** workflow name/path/status, allowed dispatch inputs, environment gates and latest runs; link to CI/CD → Pipelines.
- **Terraform discovery:** show root modules, required variables, provider/version constraints, backend declaration presence (not credentials), module sources and execution mode options; never claim arbitrary Terraform code is safe to execute without review.

## 3. Functional requirements

1. Use GitHub App installation authentication; request minimum repository permissions needed (metadata/content read, actions/workflows write or PR write only for authorized features). Respect per-installation repository scope.
2. Reuse Administration GitHub Integration for installation onboarding, callback verification, webhook secrets, key rotation and permission grants. Repository page links to Admin if installation missing.
3. Maintain distinct installation, repository and project bindings. One repository can support multiple projects with scoped paths/refs, and one project may reference multiple repositories where architecture permits.
4. Support private repositories and enterprise organizations; display permissions accurately. Do not assume app can access repos outside its installation.
5. Validate repository identity by GitHub immutable numeric repository ID and installation ID; handle rename, transfer, archive, deletion, permission revocation and default branch changes.
6. For Git-enabled deployments, discover bundle files, validate supported layout and branch/ref, propose generating a bundle via PR when missing. Generated files must be reviewed and must not overwrite user files without explicit consent.
7. For Terraform reuse, detect `.tf` roots/modules and existing GitHub Actions workflows. The app supports two execution options: dispatch existing Terraform workflow (preferred) or approved isolated Terraform runner. Importing files does **not** mean deploying through the Databricks SDK.
8. Treat Git as source of truth for Git-owned resources and Terraform state as source of truth for Terraform-owned resources. Show ownership and block conflicting direct SDK modifications.
9. Support branch/tag/commit selection; production execution must pin an immutable commit SHA and enforce protected branch/environment rules. Avoid mutable `main` ref as the only release identity.
10. Repository synchronization uses GitHub API with pagination, ETags where useful, bounded concurrency, cache TTL and retry on rate limit. Webhook events trigger refresh but are independently verified.
11. Never expose installation tokens, App private key, action secrets, `.tfvars` secrets, Git credentials or raw webhook signatures. Sanitize repository file previews and limit file size.
12. Repository unlink requires impact analysis: active pipelines, projects, release records, Terraform workflows, pending approvals and historical audit. Archive connection without deleting evidence.
13. Support selecting existing repositories; do not require DeployPactAI to create GitHub repositories.
14. AI can optionally summarize repository structure or recommend candidate bundle/Terraform entry points from approved non-sensitive metadata; never modify repository without explicit PR and review.

## 4. Backend and GitHub flow

`github_installation_service` (existing) → `repository_catalog_service` → `github_api_client` → `repository_inspector` → `bundle_detector` / `terraform_detector` → `project_repository_binding_service` → `repository_health_reconciler`.

- Browser sends repository selection; backend validates installation scope and resolves repository metadata through GitHub API.
- Fetch only authorized file paths, with branch/ref pinned; use GitHub Contents/Tree APIs appropriately and enforce size limits.
- Store file metadata and fingerprints, not full sensitive source, unless explicitly exported to approved artifact storage.
- For workflow dispatch, hand off to Pipelines service; for release, hand off to Release & Promotion service; for Terraform, hand off to approved Terraform orchestration service.

## 5. Reference DDL

```sql
CREATE EXTENSION IF NOT EXISTS pgcrypto;
-- Existing git_integrations/repositories tables should be extended, not duplicated.
CREATE TABLE IF NOT EXISTS github_repository_connections (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 tenant_id uuid NOT NULL REFERENCES tenants(id),
 installation_external_id bigint NOT NULL,
 repository_external_id bigint NOT NULL,
 full_name text NOT NULL,
 default_branch text,
 is_private boolean NOT NULL DEFAULT true,
 status text NOT NULL DEFAULT 'ACTIVE' CHECK(status IN
  ('ACTIVE','DEGRADED','DISABLED','ARCHIVED')),
 usage_types jsonb NOT NULL DEFAULT '[]'::jsonb,
 last_synced_at timestamptz,
 last_verified_at timestamptz,
 created_at timestamptz NOT NULL DEFAULT now(),
 updated_at timestamptz NOT NULL DEFAULT now(),
 UNIQUE(id,tenant_id), UNIQUE(tenant_id,installation_external_id,repository_external_id)
);
CREATE TABLE IF NOT EXISTS github_repository_project_links (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 tenant_id uuid NOT NULL REFERENCES tenants(id),
 repository_connection_id uuid NOT NULL,
 project_id uuid NOT NULL, -- FK to existing projects, tenant-consistent
 usage_kind text NOT NULL CHECK(usage_kind IN
  ('SOURCE','BUNDLE','WORKFLOW','TERRAFORM','RELEASE_MANIFEST')),
 repository_path text NOT NULL DEFAULT '/',
 allowed_ref_pattern text,
 created_at timestamptz NOT NULL DEFAULT now(),
 FOREIGN KEY(repository_connection_id,tenant_id)
  REFERENCES github_repository_connections(id,tenant_id),
 UNIQUE(tenant_id,repository_connection_id,project_id,usage_kind,repository_path)
);
CREATE TABLE IF NOT EXISTS github_repository_inspections (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 tenant_id uuid NOT NULL REFERENCES tenants(id),
 repository_connection_id uuid NOT NULL,
 commit_sha char(40) NOT NULL,
 inspection_status text NOT NULL CHECK(inspection_status IN
  ('QUEUED','RUNNING','SUCCEEDED','PARTIAL','FAILED')),
 bundle_roots jsonb NOT NULL DEFAULT '[]'::jsonb,
 terraform_roots jsonb NOT NULL DEFAULT '[]'::jsonb,
 workflow_paths jsonb NOT NULL DEFAULT '[]'::jsonb,
 warnings jsonb NOT NULL DEFAULT '[]'::jsonb,
 inspected_at timestamptz NOT NULL DEFAULT now(),
 FOREIGN KEY(repository_connection_id,tenant_id)
  REFERENCES github_repository_connections(id,tenant_id)
);
CREATE INDEX IF NOT EXISTS ix_github_repo_inspections
 ON github_repository_inspections(tenant_id,repository_connection_id,inspected_at DESC);
```

**Migration hardening:** map these concepts into existing `repositories`/`git_integrations` if present; use tenant-consistent FKs for projects and installation records. GitHub numeric IDs may be stored as text if existing conventions require.

## 6. Security, errors, audit and acceptance

- Permissions: `repository.view`, `repository.connect`, `repository.inspect`, `repository.link_project`, `repository.export_pr`, `repository.disable`.
- Audit installation/repository linking, permission changes, PR generation, archive, project binding and ref selection.
- Handle repository rename/transfer, missing installation, expired installation access, 403, 404, rate limit, deleted workflow, malformed bundle, unsupported Terraform provider, inaccessible private modules.
- Tests: private repo discovery; least-privilege installation; branch/ref pinning; GitHub App permission revocation; repo rename; Terraform detection; secret file suppression; project link isolation; safe unlink with dependency warnings; no duplicate administration credential store.
