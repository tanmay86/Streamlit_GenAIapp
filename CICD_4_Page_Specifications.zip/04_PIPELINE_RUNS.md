# CI/CD-04 — Pipeline Runs | Detailed Functional & Technical Requirements

**Navigation:** CI/CD → Pipeline Runs

## Implementation contract for coding agent

**Product:** JadeOrbit DeployPactAI. **Module:** CI/CD. **Scope:** complete enterprise product, not MVP.

Before coding, inspect the existing `PROJECT_REQUIREMENTS.md`, `PROJECT_ARCHITECTURE.md`, Administration (especially GitHub Integration, Approvals, Deployment Policies, Audit Logs), Workspaces, and Projects specifications, existing React/TypeScript routes, FastAPI services, Lakebase models, Alembic migrations, SDK client factory, policy engine, audit writer and deployment worker. **Reuse existing services and tables; do not build parallel systems.**

The application is already running in a Databricks workspace. Implement additive, backward-compatible migrations. Preserve the four project types only: **Direct Deployment, Git-Enabled Deployment, Release Promotion, Workspace Synchronization**. ML model promotion is a capability **inside Release Promotion**, not a fifth project type. Terraform is an integration/execution option, **not** a fifth project type.

Technology baseline: React + TypeScript; Python FastAPI; Databricks SDK/REST; Databricks Apps hosting; Lakebase PostgreSQL metadata; Databricks Jobs/durable workers; Unity Catalog Volumes or approved object storage for immutable artifacts; GitHub App + GitHub Actions; Databricks Asset Bundles / Declarative Automation Bundles; Terraform CLI only in isolated approved runners. Use supported Databricks/GitHub APIs; feature-gate unsupported operations.

All mutating operations require server-side tenant isolation, RBAC, policy evaluation, audit, immutable version/plan evidence, idempotency, retries with bounded backoff, observability and safe errors. Do not expose GitHub App private keys, installation tokens, Databricks credentials, Terraform state secrets, OIDC tokens, model artifacts or notebook source to unauthorized users. Do not run arbitrary user-supplied shell commands in the app server.

SQL is **reference PostgreSQL DDL**, not a command to execute unconditionally. Reconcile with existing `projects`, `repositories`, `git_integrations`, `pipeline_runs`, `deployment_plans`, `deployment_runs`, `approvals`, `artifact_versions`, `resource_bindings` and `audit_events`. Apply tenant-consistent foreign keys and Alembic migrations. Every page needs loading/empty/error/permission states, accessibility, pagination, typed backend contracts, automated tests and operational telemetry.

## 1. Goal

Provide a unified, reliable operational view of **all CI/CD executions**—GitHub Actions workflows, generated Databricks Bundle pipelines, Terraform pipeline/runner executions and linked release promotions—with accurate remote status, stage logs, artifacts, policy decisions, approvals, verification and troubleshooting.

## 2. Frontend sections

- **Runs dashboard:** total/running/queued/success/failed/cancelled/partial, trend and recent activity; use real server data and selected time range.
- **Runs table:** run ID, pipeline, project, type, source repo/commit, environment/workspace, initiator, trigger, provider, status, started/ended/duration, approval state, release link; search, filters, sorting and pagination.
- **Run details:** Summary; Stage Timeline; Logs; Inputs & Artifact References; Deployment Changes; Approvals/Policies; Verification; Related Release/Rollback; Audit.
- **Timeline:** queued → dispatched → remote run correlated → stages → approval gates → deployment → verification → terminal result. Show per-target status for multi-environment release.
- **Log viewer:** streamed/paginated with redaction, download only when authorized, log source/time/level, truncation indicators, correlation IDs, GitHub external link.
- **Actions:** refresh, open provider run, retry eligible run, cancel active run, export sanitized evidence, inspect plan, create incident/support note, navigate to rollback if eligible.
- **Failure diagnostics:** failed step, error classification, last successful checkpoint, remediation hints, owner and links. AI can summarize sanitized failures as advisory text only.

## 3. Functional requirements

1. Treat external GitHub Actions/Terraform runner as authoritative for remote job state. Local orchestration status is separate; present both when mismatched.
2. Ingest webhook events only after signature verification and replay defense; correlate by immutable repository ID, workflow ID, run ID, run attempt and trusted installation. Reconcile with provider API because webhooks may be delayed, duplicated or missed.
3. Track `QUEUED`, `DISPATCHING`, `WAITING_FOR_PROVIDER`, `PENDING_APPROVAL`, `RUNNING`, `VERIFYING`, `SUCCEEDED`, `FAILED`, `CANCELLING`, `CANCELLED`, `TIMED_OUT`, `PARTIAL`, `UNKNOWN`. Define legal transitions; never mark success based only on dispatch HTTP response.
4. Track reruns as new attempts linked to original run; preserve old logs/evidence. GitHub run attempts may share run ID but have distinct attempt number.
5. Logs may contain secrets: redact at ingestion and again at display/export; never persist raw secrets. Limit retention and large payloads; store log references in UC Volumes/object storage rather than large Lakebase blobs.
6. Poll remote status with bounded rate and backoff, especially when webhook unavailable. Flag stale/unknown if provider cannot be reached; do not infer success/failure.
7. Capture input schema and non-secret values, pinned SHA, bundle target, Terraform plan digest/reference, mapping revision, deployment plan hash, policy/approval IDs and identity reference for traceability.
8. Support partial successes, especially release with multiple targets or Terraform apply with partial resource creation. Show truthful per-step/per-target outcomes.
9. Cancel request must call provider/runner, then wait for confirmation; cancellation does not guarantee rollback of already applied changes.
10. Retry policy: transient failures can be retried by workers; user rerun requires authorization and may need fresh plan/approval, especially Terraform and PROD.
11. Link runs to deployment history and release promotion records; do not create duplicate competing run status models.
12. Export signed or hash-chained evidence bundle where supported: run summary, stage timestamps, sanitized logs, approval/policy decisions, artifact digests and verification results.
13. Support operational alerts for long-running, failed, stalled, pending approval and missing provider correlation. Respect notification preferences and throttling.
14. Time zones: persist UTC timestamps; render in user preference. Durations derive from actual provider timestamps where available.
15. Provide correlation and trace IDs for end-to-end debugging without leaking credentials or private repository contents.

## 4. Backend flow and architecture

`provider_webhook_ingestor` → `event_deduplicator` → `run_correlator` → `run_state_machine` → `provider_reconciliation_worker` → `stage/log_artifact_indexer` → `notification_service` → `audit_service`.

- Reuse `pipeline_runs` and `deployment_runs` if already implemented; add provider identifiers, attempts, reconciliation timestamps and evidence refs.
- Use outbox/inbox patterns for webhook delivery and state transitions; idempotent processing with unique provider event keys.
- GitHub logs are obtained through authorized provider APIs and may require temporary redirect URLs; backend must validate redirect hosts and not forward credentials to arbitrary URLs.
- Terraform runner produces structured phase events; do not scrape stdout as the only source of truth.
- Persist raw provider event minimal metadata only when needed; retain per compliance policy.

## 5. Reference DDL

```sql
CREATE EXTENSION IF NOT EXISTS pgcrypto;
-- If pipeline_runs exists, extend it with provider_run_id, attempt and reconciliation fields.
CREATE TABLE IF NOT EXISTS cicd_run_provider_links (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 tenant_id uuid NOT NULL REFERENCES tenants(id),
 pipeline_run_id uuid NOT NULL, -- FK to existing pipeline_runs
 provider text NOT NULL CHECK(provider IN ('GITHUB_ACTIONS','MANAGED_TERRAFORM','DATABRICKS_JOB')),
 provider_run_id text NOT NULL,
 provider_attempt integer NOT NULL DEFAULT 1 CHECK(provider_attempt > 0),
 provider_url text,
 provider_status text,
 provider_conclusion text,
 last_reconciled_at timestamptz,
 created_at timestamptz NOT NULL DEFAULT now(),
 UNIQUE(tenant_id,provider,provider_run_id,provider_attempt)
);
CREATE TABLE IF NOT EXISTS cicd_run_stages (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 tenant_id uuid NOT NULL REFERENCES tenants(id),
 pipeline_run_id uuid NOT NULL,
 stage_key text NOT NULL,
 display_name text NOT NULL,
 stage_order integer NOT NULL,
 status text NOT NULL CHECK(status IN
  ('PENDING','WAITING_APPROVAL','RUNNING','SUCCEEDED','FAILED','SKIPPED','CANCELLED','UNKNOWN')),
 external_job_id text,
 started_at timestamptz, finished_at timestamptz,
 error_class text, error_summary text,
 UNIQUE(tenant_id,pipeline_run_id,stage_key)
);
CREATE TABLE IF NOT EXISTS cicd_run_evidence (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 tenant_id uuid NOT NULL REFERENCES tenants(id),
 pipeline_run_id uuid NOT NULL,
 evidence_kind text NOT NULL CHECK(evidence_kind IN
  ('LOG','ARTIFACT','PLAN','APPROVAL','POLICY','VERIFICATION','EXPORT')),
 storage_ref text NOT NULL,
 digest_sha256 char(64),
 is_redacted boolean NOT NULL DEFAULT true,
 retention_until timestamptz,
 created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS cicd_provider_webhook_inbox (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 tenant_id uuid NOT NULL REFERENCES tenants(id),
 provider text NOT NULL,
 installation_external_id text,
 delivery_external_id text NOT NULL,
 event_type text NOT NULL,
 payload_digest char(64) NOT NULL,
 processing_status text NOT NULL DEFAULT 'RECEIVED'
  CHECK(processing_status IN ('RECEIVED','PROCESSING','PROCESSED','IGNORED','FAILED')),
 received_at timestamptz NOT NULL DEFAULT now(),
 processed_at timestamptz,
 UNIQUE(tenant_id,provider,delivery_external_id)
);
CREATE INDEX IF NOT EXISTS ix_cicd_run_stages
 ON cicd_run_stages(tenant_id,pipeline_run_id,stage_order);
CREATE INDEX IF NOT EXISTS ix_cicd_webhook_inbox
 ON cicd_provider_webhook_inbox(tenant_id,processing_status,received_at);
```

**Migration hardening:** attach tenant-consistent FKs to existing `pipeline_runs`, constrain stage uniqueness per run attempt where necessary, add retention indexes and reference existing audit and approval tables rather than copying records.

## 6. Security, operations and acceptance

- Permissions: `pipeline_run.view`, `pipeline_run.view_logs`, `pipeline_run.export_evidence`, `pipeline_run.cancel`, `pipeline_run.retry`, `pipeline_run.view_sensitive_metadata`.
- Audit log access, export, retry, cancellation, provider reconciliation changes and manual interventions.
- Handle missing/duplicated webhook, GitHub API outage, stale remote status, unavailable logs, expired log URL, huge logs, cancelled-but-applied Terraform, multiple run attempts, approval pending and partial release.
- Metrics: provider correlation latency, webhook lag/dedup, reconciliation staleness, stage durations, failure rates, approval wait times, run recovery rate.
- Tests: accurate remote status; dispatch is not success; webhook replay ignored; missing webhook repaired by polling; secret redaction; rerun preserves history; cancellation reconciles; cross-tenant isolation; log retention; export includes evidence and hashes; partial release is not marked successful.
