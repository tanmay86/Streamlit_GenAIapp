# CI/CD-01 — Pipelines | Detailed Functional & Technical Requirements

**Navigation:** CI/CD → Pipelines

## Implementation contract for coding agent

**Product:** JadeOrbit DeployPactAI. **Module:** CI/CD. **Scope:** complete enterprise product, not MVP.

Before coding, inspect the existing `PROJECT_REQUIREMENTS.md`, `PROJECT_ARCHITECTURE.md`, Administration (especially GitHub Integration, Approvals, Deployment Policies, Audit Logs), Workspaces, and Projects specifications, existing React/TypeScript routes, FastAPI services, Lakebase models, Alembic migrations, SDK client factory, policy engine, audit writer and deployment worker. **Reuse existing services and tables; do not build parallel systems.**

The application is already running in a Databricks workspace. Implement additive, backward-compatible migrations. Preserve the four project types only: **Direct Deployment, Git-Enabled Deployment, Release Promotion, Workspace Synchronization**. ML model promotion is a capability **inside Release Promotion**, not a fifth project type. Terraform is an integration/execution option, **not** a fifth project type.

Technology baseline: React + TypeScript; Python FastAPI; Databricks SDK/REST; Databricks Apps hosting; Lakebase PostgreSQL metadata; Databricks Jobs/durable workers; Unity Catalog Volumes or approved object storage for immutable artifacts; GitHub App + GitHub Actions; Databricks Asset Bundles / Declarative Automation Bundles; Terraform CLI only in isolated approved runners. Use supported Databricks/GitHub APIs; feature-gate unsupported operations.

All mutating operations require server-side tenant isolation, RBAC, policy evaluation, audit, immutable version/plan evidence, idempotency, retries with bounded backoff, observability and safe errors. Do not expose GitHub App private keys, installation tokens, Databricks credentials, Terraform state secrets, OIDC tokens, model artifacts or notebook source to unauthorized users. Do not run arbitrary user-supplied shell commands in the app server.

SQL is **reference PostgreSQL DDL**, not a command to execute unconditionally. Reconcile with existing `projects`, `repositories`, `git_integrations`, `pipeline_runs`, `deployment_plans`, `deployment_runs`, `approvals`, `artifact_versions`, `resource_bindings` and `audit_events`. Apply tenant-consistent foreign keys and Alembic migrations. Every page needs loading/empty/error/permission states, accessibility, pagination, typed backend contracts, automated tests and operational telemetry.

## 1. Goal

Provide a no-code control plane to **define, configure, validate, trigger, schedule (where supported), monitor and govern deployment pipelines**. Support GitHub Actions-based GitOps pipelines, Databricks Bundle validation/deployment, and reuse of existing Terraform pipelines. Pipelines link to Git-Enabled Deployment and Release Promotion projects; Direct Deployment and Workspace Synchronization use the shared deployment engine and can expose their execution jobs as linked pipeline runs when appropriate.

## 2. Frontend: page sections and actions

- **Pipeline directory:** name, project, owner, pipeline kind, GitHub repository, branch/ref, workflow file, environments, trigger type, last run/status/duration, enabled/disabled, health, next scheduled run if applicable; search/filter/sort/paginate.
- **Create/Edit pipeline wizard:** pipeline metadata → select linked project/repository → choose `EXISTING_GITHUB_WORKFLOW`, `GENERATED_BUNDLE_WORKFLOW`, or `EXISTING_TERRAFORM_WORKFLOW` (optional `MANAGED_TERRAFORM_RUNNER` when admin enables) → map approved inputs/target environments → trigger settings → policy and approval gates → validation/test → save.
- **Pipeline detail tabs:** Overview, Configuration, Stages & Gates, Environment Targets, Variables & Secret References, Triggers, Runs, Permissions, Audit.
- **Actions:** create, clone, edit draft, validate, enable/disable, manually dispatch, view run, open GitHub workflow, review changes, archive. Never delete active historical evidence.
- **Stage designer:** source/ref resolution → lint/validate → unit/integration tests (when configured) → bundle/Terraform plan → risk/policy evaluation → approval → deploy/apply → verification → release evidence; distinguish native GitHub job stages from DeployPactAI orchestration stages.
- **Input editor:** typed allowlisted workflow_dispatch inputs, environment, bundle target, pinned commit SHA, Terraform workspace/variable references; secret values are never entered/stored in plaintext.
- **Execution controls:** show who may trigger and for which target, run concurrency, environment locks, timeout, retry policy, cancellation and immutable ref/plan hash.
- **Diagnostics:** configuration validation, workflow existence, repository installation permission, branch/ref availability, OIDC federation setup, Databricks target connectivity, policy compliance, Terraform state ownership.

## 3. Functional requirements

1. Discover GitHub workflows from authorized repositories and register existing workflows without rewriting them. For generated workflows, create versioned PRs; never silently push to protected branches.
2. GitHub App is preferred for repository discovery and workflow dispatch; GitHub Actions uses OIDC/federated Databricks identity where supported. Distinguish GitHub App authorization from Databricks deployment identity.
3. Generated Databricks Bundle pipelines must create reproducible repository layout and pinned source commit, validate bundle targets, execute tests, deploy and verify. Do not treat bundle deploy as a universal mechanism for every Databricks asset.
4. Existing Terraform workflow mode: dispatch a known approved GitHub Actions workflow with validated inputs; respect existing remote state, backend locking, plan/apply workflow and ownership. Do not import Terraform state into Lakebase.
5. Managed Terraform mode (only if enabled): queue execution on isolated approved runner; use pinned Terraform/provider versions, verified repository SHA, approved modules/variables, remote state backend, `init -lockfile=readonly`, `validate`, `plan -out`, policy/approval, `apply` exact approved plan; no arbitrary scripts or broad shell access.
6. Pipeline definitions are reusable; runs snapshot definition revision, source commit, target, mapping revision, variable names/references, identity, policy version and approval context.
7. Trigger types: manual, GitHub push/PR/workflow dispatch where repository permissions allow, release promotion, schedule, and upstream event. Incoming webhook signatures verified, deliveries deduplicated, and only approved events accepted.
8. Triggering a workflow does not imply successful execution. Correlate dispatched run to GitHub run ID through trusted API/webhook; handle delayed run discovery and eventual consistency.
9. GitHub-hosted jobs run in GitHub infrastructure, not the FastAPI web process. DeployPactAI persists orchestration and monitors via webhooks plus reconciliation polling.
10. Prevent duplicate concurrent deployment to the same target/resource ownership scope using locks, idempotency and queueing. Use GitHub concurrency controls as an additional—not sole—guard.
11. Pipeline stage promotion to PROD requires policy/approval and protected environment gates; UI cannot bypass branch protection or GitHub environment protections.
12. For failed pipeline runs, offer safe rerun/retry where supported; do not assume idempotent Terraform apply or reusing a stale plan is safe.
13. Cancellation is best effort and must reconcile remote state; show `CANCELLING` until confirmed. Do not label a run cancelled solely because a local request succeeded.
14. Respect Git-owned and Terraform-owned resource boundaries. Explicit adoption/ownership transfer is required before SDK changes to those resources.
15. Support versioned pipeline templates and a clear migration path from existing customer pipelines without copying secrets or changing workflow logic without approval.

## 4. Backend services and workflow

`pipeline_catalog_service` → `repository_access_service` → `workflow_validator` → `pipeline_definition_versioner` → `pipeline_dispatch_service` → `github_runs_correlator` → `policy_engine`/`approval_service` → `pipeline_reconciler` → `audit_service`.

- Define provider adapter interface `validate`, `dispatch`, `get_run`, `cancel`, `get_logs_reference`, `get_artifacts_reference`. Implement GitHub Actions first; do not claim other CI providers are supported unless adapters exist.
- Dispatch requests produce a durable request ID and correlation key. Reconcile asynchronous GitHub run IDs by workflow, commit, actor, inputs and timestamps, with ambiguity handling.
- Use GitHub APIs for workflow metadata and run status; use webhook events as hints, not sole source of truth. Rate-limit and cache.
- Generated workflow modifications go through GitHub PR review. Use verified GitHub App installation permissions and least privilege.
- Record pipeline definition revision and immutable execution metadata for every run.

## 5. Reference DDL

```sql
CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE TABLE IF NOT EXISTS cicd_pipelines (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 tenant_id uuid NOT NULL REFERENCES tenants(id),
 project_id uuid NOT NULL, -- tenant-consistent FK to existing projects
 repository_id uuid,       -- tenant-consistent FK to existing repositories
 name text NOT NULL,
 kind text NOT NULL CHECK (kind IN
  ('EXISTING_GITHUB_WORKFLOW','GENERATED_BUNDLE_WORKFLOW',
   'EXISTING_TERRAFORM_WORKFLOW','MANAGED_TERRAFORM_RUNNER')),
 workflow_path text,
 default_ref text,
 owner_user_id uuid REFERENCES app_users(id),
 status text NOT NULL DEFAULT 'DRAFT'
  CHECK (status IN ('DRAFT','ACTIVE','DISABLED','ARCHIVED')),
 current_revision integer NOT NULL DEFAULT 1,
 created_at timestamptz NOT NULL DEFAULT now(),
 updated_at timestamptz NOT NULL DEFAULT now(),
 UNIQUE(id,tenant_id), UNIQUE(tenant_id,project_id,name)
);
CREATE TABLE IF NOT EXISTS cicd_pipeline_revisions (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 tenant_id uuid NOT NULL REFERENCES tenants(id),
 pipeline_id uuid NOT NULL,
 revision integer NOT NULL,
 config jsonb NOT NULL,
 config_digest char(64) NOT NULL,
 created_by uuid REFERENCES app_users(id),
 created_at timestamptz NOT NULL DEFAULT now(),
 FOREIGN KEY (pipeline_id,tenant_id) REFERENCES cicd_pipelines(id,tenant_id),
 UNIQUE(pipeline_id,revision), UNIQUE(id,tenant_id)
);
CREATE TABLE IF NOT EXISTS cicd_pipeline_triggers (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 tenant_id uuid NOT NULL REFERENCES tenants(id),
 pipeline_id uuid NOT NULL,
 trigger_type text NOT NULL CHECK(trigger_type IN
  ('MANUAL','WEBHOOK','SCHEDULE','PROMOTION','UPSTREAM')),
 trigger_config jsonb NOT NULL DEFAULT '{}'::jsonb,
 enabled boolean NOT NULL DEFAULT true,
 FOREIGN KEY (pipeline_id,tenant_id) REFERENCES cicd_pipelines(id,tenant_id)
);
CREATE TABLE IF NOT EXISTS cicd_dispatch_requests (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 tenant_id uuid NOT NULL REFERENCES tenants(id),
 pipeline_id uuid NOT NULL,
 revision_id uuid NOT NULL,
 idempotency_key text NOT NULL,
 source_commit_sha char(40),
 target_environment text,
 status text NOT NULL DEFAULT 'QUEUED' CHECK(status IN
  ('QUEUED','DISPATCHING','DISPATCHED','CORRELATED','FAILED','CANCELLED')),
 external_run_id text,
 correlation_token uuid NOT NULL DEFAULT gen_random_uuid(),
 requested_by uuid REFERENCES app_users(id),
 created_at timestamptz NOT NULL DEFAULT now(),
 updated_at timestamptz NOT NULL DEFAULT now(),
 FOREIGN KEY(pipeline_id,tenant_id) REFERENCES cicd_pipelines(id,tenant_id),
 FOREIGN KEY(revision_id,tenant_id) REFERENCES cicd_pipeline_revisions(id,tenant_id),
 UNIQUE(tenant_id,pipeline_id,idempotency_key)
);
CREATE INDEX IF NOT EXISTS ix_cicd_dispatch_status
 ON cicd_dispatch_requests(tenant_id,status,created_at);
```

**Integration note:** existing `pipeline_runs` remains authoritative for run tracking; link dispatch requests to it via migration rather than introducing duplicate run ledgers. Ensure repository and project FKs are tenant-consistent.

## 6. Permissions, errors, audit and acceptance

- Permissions: `pipeline.view`, `pipeline.create`, `pipeline.edit`, `pipeline.validate`, `pipeline.dispatch`, `pipeline.cancel`, `pipeline.manage_triggers`, `pipeline.archive`.
- Audit pipeline creation/revisions, repository binding, dispatch, input changes, approval decisions, cancellation and workflow modification PRs.
- Fail safely on missing GitHub installation, disabled workflow, branch protection, missing required input, revoked OIDC trust, inaccessible target, expired approval, stale Terraform plan and ambiguous run correlation.
- Tests: existing workflow dispatch, generated bundle PR flow, Terraform existing-pipeline mode, production approval gate, webhook replay defense, cross-tenant isolation, duplicate dispatch idempotency, run correlation, cancellation reconciliation, history preservation.
