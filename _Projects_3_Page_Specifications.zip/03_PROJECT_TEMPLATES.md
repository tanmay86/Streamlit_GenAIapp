# PROJECTS-03 — Project Templates: Complete Implementation Specification

**Navigation:** Projects → Project Templates. **Purpose:** reusable, governed starting configurations for the four supported project types.

## Coding-agent contract (mandatory)

- Product: **JadeOrbit DeployPactAI**. This is a **full-product** specification, not an MVP. The existing React + TypeScript, FastAPI, Databricks SDK, Lakebase PostgreSQL application already runs; **inspect the repository first** and preserve its established routes, design system, authentication, models, migrations, connection registry, asset inventory, mapping, policies, approval and audit services.
- Read `PROJECT_REQUIREMENTS.md`, `PROJECT_ARCHITECTURE.md`, the six Administration specifications and four Workspace specifications before implementation. Reuse shared services; do not introduce duplicate project, user, workspace, execution or policy tables. Treat the DDL below as **reference/additive**; use Alembic and reconcile existing columns/FKs.
- Exactly **four** project types: `DIRECT`, `GIT_ENABLED`, `RELEASE_PROMOTION`, `WORKSPACE_SYNC`. **ML model promotion is a capability of Release Promotion, never a fifth project type.** Terraform reuse is an optional integration/execution mode within suitable projects, never a fifth project type.
- A **project is reusable configuration**, not an execution. Project creation does not deploy. Every execution uses a fresh immutable plan, validation, policy evaluation, required approvals, durable workers and verification. Git-owned/Terraform-owned resources cannot be silently mutated by direct SDK execution.
- All reads/writes are tenant-scoped, server-authorized, audited, versioned where appropriate, and resilient to retries. Secrets live only in an approved secret manager; Lakebase stores secret references, never token/private-key values. No browser-side Databricks credentials.
- Provide complete frontend page(s), typed frontend/backend contracts, FastAPI domain services, additive migrations, asynchronous job integrations, error/loading/empty states, accessible UX, observability, automated unit/integration/security tests, and user documentation. No fake actions or placeholder-only implementation.
- Feature support is capability-driven per cloud/workspace/API. Do not claim automatic table-data migration, secret-value copying, universal asset portability, atomic multi-workspace deployment, or guaranteed rollback of stateful resources.

## 1. Functional scope and user personas

A template is a **versioned configuration blueprint** that prepopulates Create Project; it is not an active project, runnable pipeline, stored credential or deployment plan. Template catalog supports platform-curated, organization/team-shared and private templates. Authors can create, validate, publish, deprecate, clone, export and manage revisions; consumers can preview and instantiate authorized templates. Admins moderate organization-wide publication.

## 2. Page structure

1. **Template catalog:** featured/recommended, search, filter by four project types, ownership/visibility, cloud compatibility, asset families, integration requirements, status, author and updated date. Grid/list toggle and sorting.
2. **Template card:** name, short description, project type, supported environments, prerequisites, version, author, usage count (accurate), visibility, `Verified` only if validated against stated schema/policies, action Preview/Use Template.
3. **Template detail:** purpose, included settings, variables to fill, source/target assumptions, supported Databricks resource types, GitHub/Terraform/ML dependencies, permissions, policy requirements, example topology, revision history and change log; no secrets or customer-sensitive workspace identifiers.
4. **Template editor:** Create from scratch, from existing project (sanitized), clone template, import approved JSON/YAML. Sections: metadata, type-specific configuration blueprint, parameter definitions, validation rules, allowed defaults, documentation, tags, compatibility, visibility.
5. **Publish workflow:** Draft → Validation → optional Review/Approval → Published; later Deprecated/Archived. Published revision immutable; editing creates new draft revision.
6. **Use Template:** preview prefilled values, collect missing required inputs in Create Project wizard, resolve real workspace/repo/mapping references, validate tenant-specific policies, finalize a **new** project. Never auto-deploy.
7. **Management:** My Templates, Shared Templates, Organization Templates, Recently Used; version compare, rollback *template definition* to earlier revision via new revision, usage/dependency impact before deprecating.

## 3. Required template categories and examples

| Project type | Built-in template examples | Key variables |
|---|---|---|
| Direct Deployment | Notebook + Job promotion; Lakeflow pipeline deployment; multi-target workspace rollout | source, targets, selected assets, mapping profiles, conflict policy |
| Git-Enabled Deployment | Existing GitHub bundle repository; export selected assets to new bundle; GitHub Actions gated deployment | GitHub installation/repo, workflow, branch, bundle target, environment |
| Release Promotion | DEV→QA→PROD gated release; MLflow model DEV→STAGING→PROD with model evaluation/serving switch; multi-stage release rollback | stage order, release manifest, model version, evaluation thresholds, approvals, rollback settings |
| Workspace Synchronization | Workspace folder sync; Job definition drift monitoring; selective configuration sync | source/target, scope, mapping, schedule, sync policy |

**Terraform integration template options:** `EXISTING_PIPELINE` for existing `.tf` repo/workflow and `MANAGED_RUNNER` for approved Terraform runner, module path, state backend reference and allowed variable schema. These are **options within a project template**, not a fifth project type. Do not bundle actual `.tfstate`, credentials or secret values.

## 4. Template schema and parameterization

- Template has `schema_version`, `project_type`, `metadata`, `supported_capabilities`, `configuration_blueprint`, `parameters`, `validation_rules`, `compatibility`, `documentation` and optional `integration_requirements`.
- Parameter types: string, integer, boolean, enum, workspace reference, asset selector, environment mapping revision, repository/workflow reference, model/version reference, secret **reference**, approved Terraform variable; support required/optional, allowed values, safe defaults and dependency conditions.
- Placeholders use strict declarative syntax (e.g. `${target_workspace}`) with explicit allowlist; **no arbitrary expression execution, embedded scripts, unsafe YAML tags, dynamic code or runtime eval**.
- Template cannot embed actual OAuth tokens, PATs, SSH private keys, webhook secrets, plaintext credentials, sensitive notebook code, customer model artifacts or Terraform state. Sanitization when converting project to template is mandatory.
- Tenant-scoped resources cannot be hard-coded into globally published templates; replace with parameters and resolve during instantiation.
- Version and hash every published template; a project stores source template ID/revision for traceability but is not auto-mutated when template changes.
- Validate schema compatibility, available resource adapters, policies, required integrations and workspace capabilities before project creation. Template preview may be offline; final project validation is always online/authoritative.

## 5. Lifecycle and governance

- `DRAFT`, `IN_REVIEW`, `PUBLISHED`, `DEPRECATED`, `ARCHIVED`. Only `PUBLISHED` templates can be used by non-author consumers; deprecated templates remain readable for existing project provenance but cannot start new projects unless admin explicitly permits.
- Visibility: `PRIVATE`, `TEAM`, `TENANT`. Publication to tenant scope requires `template.publish` and possibly approval. No cross-tenant visibility unless a separate curated global catalog with strict sanitization is explicitly implemented.
- Versioning: semantic version label plus immutable revision integer/hash. Edits to published templates always create new revision; usage stats and provenance reference exact revision.
- Project-from-template requires same Create Project wizard, RBAC, fresh mapping/credential/capability checks and server policy. Template settings never bypass approvals.
- Support template import/export with size limit, schema validation, content sanitization, signing/checksum where feasible, provenance and malware scanning for uploaded attachments. No executable Terraform modules are uploaded through template JSON itself; link to approved repository/path.
- AI-assisted description/tag/parameter suggestions are optional and feasible using metadata only; all output reviewed and validated before publish. No autonomous template publication or execution.

## 6. Backend services and integration flow

`TemplateCatalogService` (list/filter/visibility) → `TemplateAuthoringService` (draft and revisions) → `TemplateValidator` (schema/policy/capability checks) → `TemplatePublishingService` (approval and immutable publish) → `TemplateInstantiationService` (parameter substitution and draft creation) → `ProjectWizardValidator` (full validation) → `ProjectFinalizer` (new project).

Integrate Administration RBAC, policies, approvals, audit, Workspace Registry, Asset Explorer, Environment Mappings, GitHub Integration, Terraform runner registry and Release Promotion ML settings. Keep templates declarative and execution-free.

## 7. Reference Lakebase PostgreSQL DDL (adapt to existing schema)

```sql
CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE TABLE IF NOT EXISTS project_templates (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 tenant_id uuid NOT NULL REFERENCES tenants(id),
 name text NOT NULL,
 slug text NOT NULL,
 project_type text NOT NULL CHECK(project_type IN ('DIRECT','GIT_ENABLED','RELEASE_PROMOTION','WORKSPACE_SYNC')),
 visibility text NOT NULL DEFAULT 'PRIVATE' CHECK(visibility IN ('PRIVATE','TEAM','TENANT')),
 owner_user_id uuid NOT NULL REFERENCES app_users(id),
 description text,
 lifecycle_status text NOT NULL DEFAULT 'DRAFT'
   CHECK(lifecycle_status IN ('DRAFT','IN_REVIEW','PUBLISHED','DEPRECATED','ARCHIVED')),
 latest_revision integer NOT NULL DEFAULT 1,
 created_at timestamptz NOT NULL DEFAULT now(),
 updated_at timestamptz NOT NULL DEFAULT now(),
 UNIQUE(tenant_id,slug), UNIQUE(id,tenant_id)
);
CREATE TABLE IF NOT EXISTS project_template_revisions (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 tenant_id uuid NOT NULL REFERENCES tenants(id),
 template_id uuid NOT NULL,
 revision_number integer NOT NULL,
 semantic_version text,
 schema_version integer NOT NULL DEFAULT 1,
 blueprint jsonb NOT NULL,
 parameters jsonb NOT NULL DEFAULT '[]'::jsonb,
 compatibility jsonb NOT NULL DEFAULT '{}'::jsonb,
 content_sha256 char(64) NOT NULL,
 validation_result jsonb NOT NULL DEFAULT '{}'::jsonb,
 published_at timestamptz,
 created_by uuid REFERENCES app_users(id),
 created_at timestamptz NOT NULL DEFAULT now(),
 FOREIGN KEY(template_id,tenant_id) REFERENCES project_templates(id,tenant_id),
 UNIQUE(template_id,revision_number), UNIQUE(id,tenant_id)
);
CREATE TABLE IF NOT EXISTS project_template_usage (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 tenant_id uuid NOT NULL REFERENCES tenants(id),
 template_revision_id uuid NOT NULL,
 created_project_id uuid NOT NULL REFERENCES projects(id),
 instantiated_by uuid NOT NULL REFERENCES app_users(id),
 created_at timestamptz NOT NULL DEFAULT now(),
 FOREIGN KEY(template_revision_id,tenant_id) REFERENCES project_template_revisions(id,tenant_id),
 UNIQUE(tenant_id,created_project_id)
);
CREATE INDEX IF NOT EXISTS ix_template_catalog
 ON project_templates(tenant_id,project_type,lifecycle_status,visibility,updated_at DESC);
```

**Schema reconciliation:** reuse existing `project_templates` if present. Add tenant-consistent foreign keys, team visibility relation where teams exist, approval reference and provenance. Template revision rows are immutable after publication (enforce via service/DB trigger as appropriate). Do not store secret values in JSONB.

## 8. Permissions, auditing, UX and errors

- Permissions: `template.view`, `template.create`, `template.edit`, `template.publish`, `template.deprecate`, `template.archive`, `template.instantiate`, `template.import`, `template.export` with tenant/team/owner scope.
- Record create/edit/publish/deprecate/instantiate/import/export and policy denials in immutable audit service; redact parameter values when sensitive.
- Provide accessible template cards, preview diffs, publish validation errors, incompatible-version warnings, missing integration/permission guidance, and explicit status when template requires an unavailable resource family.
- Import rejects malformed JSON/YAML, oversized payloads, unsafe keys/tags, unsupported schema versions, cross-tenant references and secret-like values; do not execute imported content.

## 9. Acceptance criteria

1. Catalog supports all four project types with correct filters and visibility; ML/Terraform are not extra types.
2. Create/clone/edit/version/publish/deprecate/archive lifecycle works with immutable published revisions.
3. Template from project removes credentials, sensitive paths and tenant-specific references as configured.
4. Template instantiation opens Create Project with values prefilled but still requires validation and creates no deployment.
5. ML promotion template correctly configures model evaluation, stage gates, serving and rollback within Release Promotion.
6. Terraform template references existing pipeline or managed runner safely without importing state or running apply.
7. Role and tenant isolation, version provenance, validation errors, audit logs and concurrency protections are tested.
