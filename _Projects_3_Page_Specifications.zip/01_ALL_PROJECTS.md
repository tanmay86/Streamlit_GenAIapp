# PROJECTS-01 — All Projects: Complete Implementation Specification

**Navigation:** Projects → All Projects. **Purpose:** central searchable management surface for all four deployment project types.

## Coding-agent contract (mandatory)

- Product: **JadeOrbit DeployPactAI**. This is a **full-product** specification, not an MVP. The existing React + TypeScript, FastAPI, Databricks SDK, Lakebase PostgreSQL application already runs; **inspect the repository first** and preserve its established routes, design system, authentication, models, migrations, connection registry, asset inventory, mapping, policies, approval and audit services.
- Read `PROJECT_REQUIREMENTS.md`, `PROJECT_ARCHITECTURE.md`, the six Administration specifications and four Workspace specifications before implementation. Reuse shared services; do not introduce duplicate project, user, workspace, execution or policy tables. Treat the DDL below as **reference/additive**; use Alembic and reconcile existing columns/FKs.
- Exactly **four** project types: `DIRECT`, `GIT_ENABLED`, `RELEASE_PROMOTION`, `WORKSPACE_SYNC`. **ML model promotion is a capability of Release Promotion, never a fifth project type.** Terraform reuse is an optional integration/execution mode within suitable projects, never a fifth project type.
- A **project is reusable configuration**, not an execution. Project creation does not deploy. Every execution uses a fresh immutable plan, validation, policy evaluation, required approvals, durable workers and verification. Git-owned/Terraform-owned resources cannot be silently mutated by direct SDK execution.
- All reads/writes are tenant-scoped, server-authorized, audited, versioned where appropriate, and resilient to retries. Secrets live only in an approved secret manager; Lakebase stores secret references, never token/private-key values. No browser-side Databricks credentials.
- Provide complete frontend page(s), typed frontend/backend contracts, FastAPI domain services, additive migrations, asynchronous job integrations, error/loading/empty states, accessible UX, observability, automated unit/integration/security tests, and user documentation. No fake actions or placeholder-only implementation.
- Feature support is capability-driven per cloud/workspace/API. Do not claim automatic table-data migration, secret-value copying, universal asset portability, atomic multi-workspace deployment, or guaranteed rollback of stateful resources.

## 1. User roles and outcomes

Project viewer sees authorized projects; project owner/editor manages configuration; deployment operator can plan/execute subject to policy; approver approves without self-approval where SoD applies; platform admin manages policy and access. Permissions include `project.list`, `project.view`, `project.create`, `project.edit`, `project.clone`, `project.archive`, `project.manage_members`, `project.plan`, `project.execute`, `project.export`. Tenant and project scope must be checked on every backend query and mutation.

## 2. Main page sections

1. **Header/primary actions:** All Projects title, Create Project, Import Project Configuration (validated, sanitized manifest only), Refresh, saved views.
2. **Portfolio KPIs:** total active projects, projects by type, healthy/attention/blocked, pending approvals, last-30-day deployment successes/failures. Clearly label time window and refresh time; avoid misleading aggregations.
3. **Filter/search toolbar:** full-text project name/description/tags; type; owner/team; status; source workspace; target workspace/environment; Git/Terraform integration; schedule enabled; last deployment result/date; created/updated date. Server-side pagination, sort, URL-query persistence.
4. **Projects table/cards:** project name/link, type, owner, source, targets (count and names), status, configuration revision, last deployment and outcome, pending approval count, Git/Terraform ownership indicators, updated at, actions menu. Hide unauthorized projects.
5. **Row actions:** View, Edit, Clone, Create Deployment Plan, View History, Pause/Resume automation, Archive/Restore (when allowed), Export Sanitized Configuration. Never expose a direct unreviewed production Deploy action.
6. **Bulk actions:** assign owner/team, export metadata, archive eligible drafts, update tags; block unsafe bulk deployment or cross-tenant actions. Show per-item failures.
7. **Project detail route:** Overview; Assets/Scope; Targets & Mappings; Workflow/Pipeline (type-dependent); Plans; Releases & Rollback; Activity/History; Settings & Access. Contextual actions must reflect type and permissions.

## 3. Project states and behaviors

- `DRAFT` incomplete; `READY` valid and usable; `NEEDS_ATTENTION` stale connection, missing mapping, missing repo/pipeline, unsupported asset or policy conflict; `PAUSED` scheduled actions disabled; `ARCHIVED` read-only historical retention. **Project state is separate from deployment-run state** (`QUEUED/RUNNING/SUCCEEDED/PARTIAL/FAILED/...`).
- A project can have many target workspaces and many deployment runs. A run is target-scoped or has distinct child target executions; never report a partial multi-target run as fully successful.
- Status is derived from last validation, enabled status and current dependencies; stale inventory/credentials cannot be treated as verified.
- Source, target, owner and resource ownership must be checked before edit, plan, clone, archive and restore.
- Editing creates a new configuration revision. Existing approved plans remain pinned to old revision and become stale if policy requires; executing always revalidates source/target state.
- Archive is soft-delete, preserving approvals, releases, bindings, history and audit. Block archive while active deployments or noncancellable pipeline operations exist. Restore revalidates.
- Clone copies configuration and references but not approvals, deployment runs, immutable release versions, credentials, Terraform state, secret contents or GitHub tokens. Require target review.
- Support project type badges and contextual detail tabs, not separate top-level menus for each type.

## 4. Type-specific list and detail behavior

| Type | Project detail emphasis | Key action |
|---|---|---|
| Direct Deployment | source asset package, target mappings, conflict policy, SDK adapters | Generate fresh direct deployment plan |
| Git-Enabled Deployment | repository, branch, bundle target, workflow, ownership, commit SHA | Validate/export/PR/trigger approved pipeline |
| Release Promotion | DEV→STAGING/QA/UAT→PROD stages, immutable release, approval gates, ML model versions/aliases and serving endpoints | Promote approved release to next stage; rollback eligible release |
| Workspace Sync | source/target scope, diff snapshot, drift, sync schedule, resource ownership | Compare, review diff and create sync plan |

**Terraform:** display optional `EXISTING_PIPELINE` or `MANAGED_RUNNER` integration and last Terraform plan/apply state on relevant projects. Terraform remains source of truth for Terraform-managed infrastructure. No silent takeover by SDK.

## 5. Backend flow and integrations

- `ProjectQueryService` combines project metadata, latest validation, latest run summary, target counts, release state, pending approvals, scheduled sync status and integration health without N+1 queries.
- `ProjectCommandService` handles clone, archive/restore, membership and versioned edits with optimistic concurrency (`revision`/ETag), idempotency keys and audit.
- `ProjectHealthEvaluator` checks workspace connection/capabilities, asset freshness, mapping revision, repository and Terraform runner availability, policy version and pending approvals; heavy checks run asynchronously.
- Reuse workspace registry, Asset Explorer inventory, environment mappings, deployment planner, approvals, policies, audit logs, GitHub, Terraform, durable Jobs workers and notification service.
- Summary widgets must be based on real persisted events; store snapshot timestamps, not synthetic sample data.

## 6. Reference PostgreSQL DDL — only if absent

```sql
CREATE EXTENSION IF NOT EXISTS pgcrypto;
-- Prefer existing projects table. Extend it via Alembic if needed.
ALTER TABLE projects ADD COLUMN IF NOT EXISTS project_type text;
ALTER TABLE projects ADD COLUMN IF NOT EXISTS lifecycle_status text DEFAULT 'DRAFT';
ALTER TABLE projects ADD COLUMN IF NOT EXISTS config_revision integer DEFAULT 1;
ALTER TABLE projects ADD COLUMN IF NOT EXISTS archived_at timestamptz;
-- Validate/backfill old rows, then add NOT NULL/CHECK constraints in a separate migration.
CREATE TABLE IF NOT EXISTS project_memberships (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 tenant_id uuid NOT NULL REFERENCES tenants(id),
 project_id uuid NOT NULL REFERENCES projects(id),
 user_id uuid NOT NULL REFERENCES app_users(id),
 membership_role text NOT NULL CHECK (membership_role IN ('OWNER','EDITOR','OPERATOR','VIEWER')),
 created_at timestamptz NOT NULL DEFAULT now(),
 UNIQUE (tenant_id,project_id,user_id)
);
CREATE TABLE IF NOT EXISTS project_configuration_revisions (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 tenant_id uuid NOT NULL REFERENCES tenants(id),
 project_id uuid NOT NULL REFERENCES projects(id),
 revision_number integer NOT NULL,
 config_snapshot jsonb NOT NULL,
 config_sha256 char(64) NOT NULL,
 created_by uuid REFERENCES app_users(id),
 created_at timestamptz NOT NULL DEFAULT now(),
 UNIQUE (tenant_id,project_id,revision_number)
);
CREATE INDEX IF NOT EXISTS ix_projects_portfolio
 ON projects(tenant_id,project_type,lifecycle_status,updated_at DESC);
```

**Tenant-integrity requirement:** use composite `(id, tenant_id)` foreign keys where existing schema supports them, or enforce tenant consistency in service and DB constraints. Add check constraints for the exact four types only after backfill. Avoid migration assumptions about existing `projects` columns.

## 7. UX, safety and error handling

- Empty state invites Create Project; no-access state differs from no projects. Skeleton loaders, pagination, accessible tables, keyboard actions, responsive layout and timezone-aware dates.
- Display validation warnings, blocked plan creation, stale Git branch, missing Terraform runner, invalid workspace credentials, missing mapping, policy violations and partial deployment clearly.
- Confirm archive/restore/clone with impact summary. No secret values or sensitive asset source in exports.
- Audit list exports, project create/edit/clone/archive/restore, membership changes, plan requests and denied actions; metrics for project counts and health evaluations.

## 8. Acceptance criteria

1. All four project types appear and filter correctly; ML promotion never appears as a fifth type.
2. List and detail honor tenant/project RBAC; unauthorized project ID returns no information.
3. Search/filter/sort/pagination are server-side and consistent; KPIs match persisted data.
4. Clone retains safe configuration but not approvals, credentials or execution state.
5. Archive blocks active runs, preserves audit/history and restores safely.
6. Configuration revisions are immutable and concurrency conflicts are detected.
7. Every project links to type-appropriate planning, releases, GitHub/Terraform and mapping features.
