# PROJECTS-02 — Create Project: Complete Wizard and Backend Specification

**Navigation:** Projects → Create Project. **Purpose:** build and save a reusable, validated project for one of exactly four deployment workflows.

## Coding-agent contract (mandatory)

- Product: **JadeOrbit DeployPactAI**. This is a **full-product** specification, not an MVP. The existing React + TypeScript, FastAPI, Databricks SDK, Lakebase PostgreSQL application already runs; **inspect the repository first** and preserve its established routes, design system, authentication, models, migrations, connection registry, asset inventory, mapping, policies, approval and audit services.
- Read `PROJECT_REQUIREMENTS.md`, `PROJECT_ARCHITECTURE.md`, the six Administration specifications and four Workspace specifications before implementation. Reuse shared services; do not introduce duplicate project, user, workspace, execution or policy tables. Treat the DDL below as **reference/additive**; use Alembic and reconcile existing columns/FKs.
- Exactly **four** project types: `DIRECT`, `GIT_ENABLED`, `RELEASE_PROMOTION`, `WORKSPACE_SYNC`. **ML model promotion is a capability of Release Promotion, never a fifth project type.** Terraform reuse is an optional integration/execution mode within suitable projects, never a fifth project type.
- A **project is reusable configuration**, not an execution. Project creation does not deploy. Every execution uses a fresh immutable plan, validation, policy evaluation, required approvals, durable workers and verification. Git-owned/Terraform-owned resources cannot be silently mutated by direct SDK execution.
- All reads/writes are tenant-scoped, server-authorized, audited, versioned where appropriate, and resilient to retries. Secrets live only in an approved secret manager; Lakebase stores secret references, never token/private-key values. No browser-side Databricks credentials.
- Provide complete frontend page(s), typed frontend/backend contracts, FastAPI domain services, additive migrations, asynchronous job integrations, error/loading/empty states, accessible UX, observability, automated unit/integration/security tests, and user documentation. No fake actions or placeholder-only implementation.
- Feature support is capability-driven per cloud/workspace/API. Do not claim automatic table-data migration, secret-value copying, universal asset portability, atomic multi-workspace deployment, or guaranteed rollback of stateful resources.

## 1. Project selection landing page

Show four selectable cards, each with what it does, prerequisites, expected result and supported execution modes:

1. **Direct Deployment:** source workspace assets → one or more target workspaces via SDK/REST adapters, with dependency closure, environment mapping, plan/approve/execute/verify.
2. **Git-Enabled Deployment:** select source assets or existing repository; prepare/export Databricks Asset/Declarative Automation Bundle configuration, link GitHub repo and GitHub Actions, promote approved immutable commits; Git is source of truth.
3. **Release Promotion:** move immutable release versions across ordered environments (DEV→QA/STAGING→UAT→PROD) with gates, verification, release rollback and optional MLflow model-version/alias and serving-endpoint promotion. **ML promotion is part of this type.**
4. **Workspace Synchronization:** compare source and target configurations, choose allowed sync actions, plan/approve/execute, optionally schedule drift checks. Sync is directional and does not copy underlying data by default.

Show Terraform as a **configuration/infrastructure execution option** where appropriate: reuse existing `.tf` repositories/modules and either trigger an existing CI/CD Terraform pipeline (preferred) or run `init → plan → approval → apply` in an isolated managed runner. Terraform is not a project type. Never import/overwrite state implicitly.

## 2. Shared wizard flow (7 stages)

**Stage 1 — Project Basics:** type (locked after creation unless explicit migration), name, description, business owner/team, tags, environment strategy, project visibility/access, optional template source. Unique name within tenant or defined scope. Save draft.

**Stage 2 — Workspace & Environment Topology:** source workspace (where applicable), one or more target workspaces, same-account/cross-account detection, ordered stages for promotion, role/capability/connectivity verification. Distinguish hosting workspace from sources/targets. For Git-only release source, allow repository/artifact reference rather than assuming live source workspace. Require at least one valid target.

**Stage 3 — Asset / Release / Repository Scope:** Direct: searchable Asset Explorer and actual selected resources; Git: repo/branch/commit and bundle resources or export selection; Promotion: release manifest/artifact digest and stage-specific asset/model/serving scope; Sync: asset families, paths and comparison scope. Support inclusion/exclusion, asset capability status and stable identifiers. Never assume that metadata discovery grants permission to deploy.

**Stage 4 — Dependencies & Ownership:** dependency graph, explicit vs inferred edges, unresolved references, selected dependency closure; resource owner mode (`SDK_MANAGED`, `GIT_MANAGED`, `TERRAFORM_MANAGED`, `EXTERNAL`) and adoption/conflict checks. Warn about shared UC metastore and cross-cloud incompatibilities. Block unresolved mandatory dependencies.

**Stage 5 — Environment Mapping:** choose or create per-target mapping profile revision; catalogs/schemas, workspace/Volume paths, compute/warehouses, identities/grants, secrets **references only**, pipeline/job refs, MLflow models/versions/aliases, serving endpoints, bundle targets and approved Terraform input variables. Validate against each target. No silent creation or secret copying.

**Stage 6 — Workflow & Deployment Controls:** per-type options: create/update/skip/adopt conflict policy; GitHub repo/workflow/PR/branch protection; release stages, test gates, ML evaluation and rollback strategy; sync comparison frequency and safe schedule; optional Terraform mode and runner/pipeline connection; preflight, post-deploy verification, retries, concurrency, time windows, notifications, dry-run, approval preference. **Server policies override preferences.** Do not allow unsafe deletion or automatic PROD deployment via UI toggle.

**Stage 7 — Review, Validate & Create:** show all selected resources, targets, stage order, mappings, dependency warnings, ownership, expected permissions, Git/Terraform prerequisites, ML checks, policy gates, cost/impact hints where deterministically available, validation evidence and errors. Save `READY` only if mandatory validations pass; otherwise allow `DRAFT`/`NEEDS_ATTENTION` with clearly marked blockers. Create project and redirect to project detail; **do not execute deployment**.

Each step has Back/Next/Save Draft/Cancel; autosave with versioned draft, progress indicators, validation messages, reload/resume, discard confirmation, and role checks. Steps can vary by type but share consistent shell. Never silently drop a user's draft when switching types; confirm and revalidate.

## 3. Type-specific configuration details

### A. Direct Deployment
- Select one source and multiple targets; source selection via Asset Explorer; dependencies and mapping per target; existing resource policy create/update managed/skip/fail, explicit adoption for unmanaged.
- Source remains read-only. A target-specific immutable deployment plan is generated **after** project creation and refreshed for each run.
- Resource-specific verification, partial success, rollback feasibility and bindings tracked in deployment history.

### B. Git-Enabled Deployment
- GitHub App installation/repo permissions, repository/branch/path, ownership mode, approved workflow, environment, bundle target and immutable commit SHA; generate/export source and bundle resources only when user authorizes.
- Existing repo mode vs generated bundle mode. PR review and protected branch controls; OIDC federation where available; webhook signature validation and run correlation.
- Distinguish `GIT_MANAGED` resources from SDK-managed; no competing writes. Existing Terraform files can be referenced without changing their state.

### C. Release Promotion
- Ordered stage topology, immutable release manifest/version and artifact digests; promotion eligibility, test/evaluation evidence, stage-specific mapping, approvals and environment protection.
- ML model promotion: explicit model/version, registered model namespace, aliases (e.g., champion/challenger if used), artifact access/transfer plan, model signature/dependencies, test metrics/thresholds, serving endpoint update, smoke test, traffic/alias switch and rollback to previous verified model/serving config. Databricks model registry semantics and alias availability are capability-checked; do not assume moving a version across registries is just changing an alias.
- Rollback: create new audited rollback operation from previous release manifest, evaluate drift/compatibility, approvals and resource-level reversibility; no guarantee of transactional rollback for data/stateful resources.

### D. Workspace Synchronization
- Select source, target(s), scope, mapping revision, compare mode and schedule. Capture immutable comparison snapshots, classify `IN_SYNC/SOURCE_ONLY/TARGET_ONLY/DIFFERENT/CONFLICT/MAPPING_REQUIRED/UNSUPPORTED`.
- Source→target only; target-only resources are **never deleted by default**. Sync execution uses shared planner and approvals. Drift monitoring can notify; auto-execute only when policy explicitly permits low-risk changes.

### E. Terraform option (not a fifth type)
- Connect approved GitHub repo/branch/module path; choose `EXISTING_PIPELINE` or `MANAGED_RUNNER` with allowed provider/runner versions and workspace credentials. Configure variables using secure secret references; validate plan and remote state backend/locking.
- Existing pipeline: trigger registered workflow with allowlisted inputs and track status/artifacts; managed runner: isolated, ephemeral, restricted network, `terraform init/validate/plan`, store immutable plan and digest, approve, then apply exactly approved plan. No Terraform commands in FastAPI web process.
- Terraform-managed resources are excluded from direct SDK writes absent explicit controlled ownership transfer. No silent `terraform import`, state rewrite or destroy.

## 4. Cross-cutting validations and backend services

- `ProjectDraftService`: create/update/resume/discard draft with optimistic concurrency, TTL and tenant scope.
- `ProjectWizardValidator`: validate each step and final configuration, with structured `errors`, `warnings`, `capability_gaps` and actionable remediation.
- `WorkspaceRegistry`, `AssetInventory`, `DependencyEngine`, `MappingProfileService`, `PolicyEngine`, `ApprovalService`, `GitHubIntegration`, `TerraformOrchestrator`, `MLPromotionValidator`, `AuditService` reused from shared modules.
- `ProjectFinalizer`: single DB transaction creates project, type-specific config, targets, selected asset/release references, mapping revision pins, owner/members, immutable initial configuration revision and audit event. Use idempotency key to prevent double submission.
- `ProjectHealthEvaluator`: after creation, check asynchronous external dependencies; mark project `NEEDS_ATTENTION` if credentials, repo or mappings become stale.
- Never call deployment executor or Terraform apply during creation. No long-running SDK scans in synchronous request; queue durable jobs and return progress IDs.

## 5. Reference Lakebase PostgreSQL DDL (adapt to existing schema)

```sql
CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE TABLE IF NOT EXISTS project_drafts (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 tenant_id uuid NOT NULL REFERENCES tenants(id),
 created_by uuid NOT NULL REFERENCES app_users(id),
 project_type text NOT NULL CHECK(project_type IN ('DIRECT','GIT_ENABLED','RELEASE_PROMOTION','WORKSPACE_SYNC')),
 current_step integer NOT NULL DEFAULT 1 CHECK(current_step BETWEEN 1 AND 7),
 draft_data jsonb NOT NULL DEFAULT '{}'::jsonb,
 revision integer NOT NULL DEFAULT 1,
 status text NOT NULL DEFAULT 'IN_PROGRESS' CHECK(status IN ('IN_PROGRESS','VALIDATING','FINALIZED','DISCARDED')),
 finalized_project_id uuid REFERENCES projects(id),
 expires_at timestamptz,
 created_at timestamptz NOT NULL DEFAULT now(),
 updated_at timestamptz NOT NULL DEFAULT now(),
 UNIQUE(id,tenant_id)
);
CREATE TABLE IF NOT EXISTS project_targets (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 tenant_id uuid NOT NULL REFERENCES tenants(id),
 project_id uuid NOT NULL REFERENCES projects(id),
 workspace_id uuid NOT NULL REFERENCES workspaces(id),
 environment_name text NOT NULL,
 stage_order integer,
 mapping_profile_revision_id uuid,
 enabled boolean NOT NULL DEFAULT true,
 UNIQUE(tenant_id,project_id,workspace_id,environment_name)
);
CREATE TABLE IF NOT EXISTS project_asset_selections (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 tenant_id uuid NOT NULL REFERENCES tenants(id),
 project_id uuid NOT NULL REFERENCES projects(id),
 source_asset_id uuid NOT NULL,
 selection_mode text NOT NULL DEFAULT 'EXPLICIT' CHECK(selection_mode IN ('EXPLICIT','DEPENDENCY')),
 ownership_mode text NOT NULL CHECK(ownership_mode IN ('SDK_MANAGED','GIT_MANAGED','TERRAFORM_MANAGED','EXTERNAL')),
 UNIQUE(tenant_id,project_id,source_asset_id)
);
CREATE TABLE IF NOT EXISTS project_workflow_configurations (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 tenant_id uuid NOT NULL REFERENCES tenants(id),
 project_id uuid NOT NULL REFERENCES projects(id),
 configuration jsonb NOT NULL DEFAULT '{}'::jsonb,
 config_schema_version integer NOT NULL DEFAULT 1,
 created_at timestamptz NOT NULL DEFAULT now(),
 UNIQUE(tenant_id,project_id)
);
CREATE TABLE IF NOT EXISTS project_validation_results (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 tenant_id uuid NOT NULL REFERENCES tenants(id),
 draft_id uuid REFERENCES project_drafts(id),
 project_id uuid REFERENCES projects(id),
 validation_status text NOT NULL CHECK(validation_status IN ('PASSED','WARNINGS','FAILED')),
 findings jsonb NOT NULL DEFAULT '[]'::jsonb,
 evidence_digest char(64),
 validated_at timestamptz NOT NULL DEFAULT now(),
 CHECK(draft_id IS NOT NULL OR project_id IS NOT NULL)
);
CREATE INDEX IF NOT EXISTS ix_project_drafts_owner ON project_drafts(tenant_id,created_by,updated_at DESC);
```

**DDL integration:** Existing `projects`, `mapping_profiles`, `assets`, `deployment_packages`, `release_manifests` and Git/Terraform integration tables may already cover these concepts. Reuse them. Add composite tenant FKs/unique constraints and `ON DELETE` rules appropriate for immutable history; avoid storing credentials in `configuration` JSONB. Apply JSON schema validation to type-specific configs.

## 6. Error states and safeguards

- Missing permission, unsupported Databricks capability, expired connection, stale inventory, unmapped required reference, dependency cycle, invalid branch/workflow, blocked Terraform backend, incompatible ML model signature, shared metastore collision, policy rejection and simultaneous draft edit.
- Mark exact step and field responsible; retain draft and validation evidence. Re-run final validation on server even if each frontend step was previously green.
- Require explicit confirmations for resource adoption, schedule activation and Git/Terraform execution modes. Default new schedules disabled and production automation restricted.
- Audit draft finalization, template use, policy overrides (if permitted), integration selection and rejected creation attempts. Avoid logging notebook content, secrets and model artifacts.

## 7. Acceptance criteria

1. All four types can be configured and saved; no ML/Terraform fifth type.
2. Direct wizard selects real workspace assets and independent target mappings.
3. Git wizard links authorized GitHub repo/workflow and immutable commit strategy.
4. Promotion wizard supports ML DEV→STAGING→PROD, gates and rollback strategy.
5. Sync wizard supports safe directional diff/scheduling without implicit deletes.
6. Terraform option supports both existing pipeline and managed runner, with ownership and state safeguards.
7. Draft resume, concurrent-edit conflict, final validation, idempotent finalize and tenant RBAC work.
8. Create Project never triggers a deployment; new project opens on detail page and can generate a fresh plan separately.
